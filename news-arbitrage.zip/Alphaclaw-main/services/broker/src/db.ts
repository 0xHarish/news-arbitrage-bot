import pg from "pg";
import { config } from "./config.js";

let pool: pg.Pool | null = null;

export async function initDb(): Promise<void> {
  pool = new pg.Pool({
    connectionString: config.TIMESCALE_URL,
    min: 2,
    max: 10,
  });
  // Verify connectivity
  const client = await pool.connect();
  client.release();
  console.log("[broker] Database pool initialized");
}

export async function closeDb(): Promise<void> {
  if (pool) {
    await pool.end();
    pool = null;
    console.log("[broker] Database pool closed");
  }
}

export function getPool(): pg.Pool {
  if (!pool) {
    throw new Error("Database pool not initialized. Call initDb() first.");
  }
  return pool;
}
