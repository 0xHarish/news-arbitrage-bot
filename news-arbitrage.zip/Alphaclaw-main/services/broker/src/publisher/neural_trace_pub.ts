import Redis from "ioredis";
import { config } from "../config.js";

let pub: Redis | null = null;

const SENSITIVE_FIELDS = [
  "raw_text",
  "canonical_tokens",
  "opus_raw_reasoning",
  "fast_match_score",
  "opus_confidence",
  "signal_id",
  "verdict_id",
];

const EVENT_TYPE_MAP: Record<string, string> = {
  TRADE_EXECUTED: "STRIKE",
  SIGNAL_REJECTED: "SHIELD",
  DAILY_RESET: "SHIELD",
};

function getPublisher(): Redis {
  if (!pub) {
    pub = new Redis(config.REDIS_URL, { lazyConnect: false });
  }
  return pub;
}

export async function publishRaw(
  eventType: string,
  payload: Record<string, unknown>
): Promise<void> {
  const redis = getPublisher();
  const message = JSON.stringify({
    schema_version: "1.0",
    event_type: eventType,
    event_id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    payload,
  });

  await redis.publish("neural_trace_raw", message);
  await redis.lpush("neural_trace_raw:history", message);
  await redis.ltrim("neural_trace_raw:history", 0, 499);
}

export async function publishPublic(
  eventType: string,
  payload: Record<string, unknown>
): Promise<void> {
  const redis = getPublisher();
  const mappedEventType = EVENT_TYPE_MAP[eventType] ?? eventType;

  // Sanitize: remove sensitive fields
  const sanitized: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(payload)) {
    if (!SENSITIVE_FIELDS.includes(key)) {
      sanitized[key] = value;
    }
  }

  const message = JSON.stringify({
    schema_version: "1.0",
    event_type: mappedEventType,
    event_id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    payload: sanitized,
  });

  await redis.publish("neural_trace_public", message);
  await redis.lpush("neural_trace_public:history", message);
  await redis.ltrim("neural_trace_public:history", 0, 99);
}

export async function closePublisher(): Promise<void> {
  if (pub) {
    await pub.quit();
    pub = null;
  }
}
