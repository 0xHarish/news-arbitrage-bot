import { config } from "../config.js";
import { getPool } from "../db.js";
import { publishRaw, publishPublic } from "../publisher/neural_trace_pub.js";
import { ClobClient, type OrderBook } from "./clob_client.js";
import type { TradeSignal } from "../shadow/shadow_executor.js";

// ---------------------------------------------------------------------------
// LiveExecutor — places real orders on Polymarket CLOB when DRY_RUN=false
// ---------------------------------------------------------------------------

export class LiveExecutor {
  private clob: ClobClient;

  constructor() {
    if (config.DRY_RUN === "true") {
      throw new Error(
        "LiveExecutor cannot be used when DRY_RUN=true. " +
          `Current DRY_RUN=${config.DRY_RUN}`
      );
    }

    if (
      !config.POLYMARKET_API_KEY ||
      !config.POLYMARKET_API_SECRET ||
      !config.POLYMARKET_API_PASSPHRASE
    ) {
      throw new Error(
        "LiveExecutor requires POLYMARKET_API_KEY, POLYMARKET_API_SECRET, " +
          "and POLYMARKET_API_PASSPHRASE to be set"
      );
    }

    if (!config.HOT_WALLET_PRIVATE_KEY || !config.HOT_WALLET_ADDRESS) {
      throw new Error(
        "LiveExecutor requires HOT_WALLET_PRIVATE_KEY and HOT_WALLET_ADDRESS"
      );
    }

    this.clob = new ClobClient();
    console.log("[broker] LiveExecutor initialized (DRY_RUN=false)");
  }

  async executeLiveTrade(signal: TradeSignal): Promise<void> {
    const tag = `[broker] LiveExecutor [${signal.signal_id}]`;

    // 1. Fetch order book
    console.log(
      `${tag}: fetching order book for ${signal.clob_token_id} ` +
        `(market=${signal.market_id}, side=${signal.side})`
    );

    const book = await this.clob.getOrderBook(signal.clob_token_id);
    if (!book) {
      console.error(`${tag}: failed to fetch order book, skipping trade`);
      return;
    }

    // 2. Extract best bid/ask
    const bestAsk = getBestAsk(book);
    const bestBid = getBestBid(book);

    if (bestAsk === null) {
      console.error(`${tag}: no asks in order book, skipping trade`);
      return;
    }

    // We always BUY the outcome token specified by the signal
    const limitPrice = bestAsk;
    console.log(
      `${tag}: bestBid=${bestBid ?? "none"} bestAsk=${bestAsk} limitPrice=${limitPrice}`
    );

    // 3. Slippage protection
    const slippageBps =
      (Math.abs(bestAsk - signal.market_price_at_signal) /
        signal.market_price_at_signal) *
      10_000;

    if (slippageBps > config.MAX_SLIPPAGE_BPS) {
      console.log(
        `${tag}: slippage ${slippageBps.toFixed(1)}bps > ` +
          `MAX_SLIPPAGE_BPS=${config.MAX_SLIPPAGE_BPS}, skipping trade`
      );
      await publishSkipEvent(signal, `SLIPPAGE_EXCEEDED: ${slippageBps.toFixed(1)}bps`);
      return;
    }

    // 4. Order book depth check
    const askDepthUsdc = calcAskDepthUsdc(book);
    if (askDepthUsdc < config.MIN_BOOK_DEPTH_USDC) {
      console.log(
        `${tag}: ask depth $${askDepthUsdc.toFixed(2)} < ` +
          `MIN_BOOK_DEPTH_USDC=$${config.MIN_BOOK_DEPTH_USDC}, skipping trade`
      );
      await publishSkipEvent(
        signal,
        `INSUFFICIENT_DEPTH: $${askDepthUsdc.toFixed(2)}`
      );
      return;
    }

    // 5. Max position size guard — never exceed signal's position_usdc
    const totalUsdc = signal.position_usdc;
    console.log(`${tag}: total position_usdc=$${totalUsdc.toFixed(2)}`);

    // 6. TWAP execution — split into slices across the time window
    const sliceUsdc = totalUsdc / config.TWAP_SLICES;
    const sliceDelayMs =
      (config.TWAP_WINDOW_SECONDS * 1000) / config.TWAP_SLICES;
    const orderIds: string[] = [];
    let totalFilledTokens = 0;

    for (let i = 0; i < config.TWAP_SLICES; i++) {
      if (i > 0) {
        console.log(
          `${tag}: waiting ${(sliceDelayMs / 1000).toFixed(0)}s before slice ${i + 1}`
        );
        await sleep(sliceDelayMs);
      }

      const sliceTokens = sliceUsdc / limitPrice;
      console.log(
        `${tag}: TWAP slice ${i + 1}/${config.TWAP_SLICES} — ` +
          `$${sliceUsdc.toFixed(2)} USDC → ${sliceTokens.toFixed(4)} tokens @ ${limitPrice}`
      );

      try {
        const signedOrder = await this.clob.createSignedOrder({
          tokenId: signal.clob_token_id,
          price: limitPrice,
          sizeTokens: sliceTokens,
          side: "BUY",
        });

        const result = await this.clob.postOrder(signedOrder, "GTC");
        const orderId = result.orderID ?? "UNKNOWN";
        orderIds.push(orderId);
        totalFilledTokens += sliceTokens;

        console.log(
          `${tag}: slice ${i + 1} order placed — ` +
            `orderID=${orderId} status=${result.status ?? "n/a"}`
        );

        if (result.errorMsg) {
          console.error(
            `${tag}: slice ${i + 1} API error: ${result.errorMsg}`
          );
        }
      } catch (err) {
        console.error(`${tag}: slice ${i + 1} failed:`, err);
        orderIds.push("FAILED");
      }
    }

    // 7. Write to live_trades table
    const pool = getPool();
    const dbResult = await pool.query(
      `INSERT INTO live_trades (
        signal_id, verdict_id, market_id, clob_token_id, side,
        limit_price, composite_p, kelly_fraction, position_usdc,
        order_ids, filled_amount, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'PENDING')
      RETURNING id`,
      [
        signal.signal_id,
        signal.verdict_id,
        signal.market_id,
        signal.clob_token_id,
        signal.side,
        limitPrice,
        signal.composite_p,
        signal.kelly_fraction,
        signal.position_usdc,
        orderIds,
        totalFilledTokens,
      ]
    );

    const liveTradeId = dbResult.rows[0]?.id;
    console.log(
      `${tag}: live trade recorded — id=${liveTradeId} ` +
        `market=${signal.market_id} ${signal.side} @ ${limitPrice} ` +
        `orders=[${orderIds.join(", ")}]`
    );

    // 8. Publish STRIKE event to neural trace channels
    const tracePayload = {
      live_trade_id: liveTradeId,
      market_id: signal.market_id,
      side: signal.side,
      limit_price: limitPrice,
      composite_p: signal.composite_p,
      kelly_fraction: signal.kelly_fraction,
      position_usdc: signal.position_usdc,
      reasoning_summary: signal.reasoning_summary,
      primary_source_url: signal.primary_source_url,
      order_ids: orderIds,
      twap_slices: config.TWAP_SLICES,
      shadow: false,
      signal_id: signal.signal_id,
      verdict_id: signal.verdict_id,
    };

    await publishRaw("TRADE_EXECUTED", tracePayload);
    await publishPublic("TRADE_EXECUTED", tracePayload);
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function getBestAsk(book: OrderBook): number | null {
  if (!book.asks || book.asks.length === 0) return null;
  let best = Infinity;
  for (const ask of book.asks) {
    const p = parseFloat(ask.price);
    if (p < best) best = p;
  }
  return best === Infinity ? null : best;
}

function getBestBid(book: OrderBook): number | null {
  if (!book.bids || book.bids.length === 0) return null;
  let best = -Infinity;
  for (const bid of book.bids) {
    const p = parseFloat(bid.price);
    if (p > best) best = p;
  }
  return best === -Infinity ? null : best;
}

function calcAskDepthUsdc(book: OrderBook): number {
  if (!book.asks) return 0;
  return book.asks.reduce((sum, ask) => {
    return sum + parseFloat(ask.price) * parseFloat(ask.size);
  }, 0);
}

async function publishSkipEvent(
  signal: TradeSignal,
  reason: string
): Promise<void> {
  console.log(
    `[broker] LiveExecutor: publishing skip — signal=${signal.signal_id} reason=${reason}`
  );
  await publishRaw("SIGNAL_REJECTED", {
    signal_id: signal.signal_id,
    market_id: signal.market_id,
    reason,
  });
  await publishPublic("SIGNAL_REJECTED", {
    market_id: signal.market_id,
    reason,
  });
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
