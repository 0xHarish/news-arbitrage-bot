import { createHmac } from "crypto";
import { ethers } from "ethers";
import { config } from "../config.js";

// ---------------------------------------------------------------------------
// Polymarket contract addresses (Polygon mainnet)
// ---------------------------------------------------------------------------

const CTF_EXCHANGE = "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E";
const NEG_RISK_CTF_EXCHANGE = "0xC5d563A36AE78145C45a50134d48A1215220f80a";
const POLYGON_CHAIN_ID = 137;
const COLLATERAL_DECIMALS = 6; // USDC.e on Polygon

// ---------------------------------------------------------------------------
// EIP-712 types for CTF Exchange order signing
// ---------------------------------------------------------------------------

const ORDER_TYPES = {
  Order: [
    { name: "salt", type: "uint256" },
    { name: "maker", type: "address" },
    { name: "signer", type: "address" },
    { name: "taker", type: "address" },
    { name: "tokenId", type: "uint256" },
    { name: "makerAmount", type: "uint256" },
    { name: "takerAmount", type: "uint256" },
    { name: "expiration", type: "uint256" },
    { name: "nonce", type: "uint256" },
    { name: "feeRateBps", type: "uint256" },
    { name: "side", type: "uint8" },
    { name: "signatureType", type: "uint8" },
  ],
};

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface OrderBookEntry {
  price: string;
  size: string;
}

export interface OrderBook {
  market: string;
  asset_id: string;
  bids: OrderBookEntry[];
  asks: OrderBookEntry[];
  timestamp?: string;
  hash?: string;
}

export interface SignedOrder {
  salt: string;
  maker: string;
  signer: string;
  taker: string;
  tokenId: string;
  makerAmount: string;
  takerAmount: string;
  expiration: string;
  nonce: string;
  feeRateBps: string;
  side: number;
  signatureType: number;
  signature: string;
}

export interface OrderResponse {
  orderID?: string;
  success?: boolean;
  errorMsg?: string;
  status?: string;
}

// ---------------------------------------------------------------------------
// Polymarket CLOB REST client
// ---------------------------------------------------------------------------

export class ClobClient {
  private wallet: ethers.Wallet;
  private apiKey: string;
  private apiSecret: string;
  private apiPassphrase: string;
  private baseUrl: string;

  constructor() {
    this.baseUrl = config.POLYMARKET_CLOB_BASE_URL;
    this.apiKey = config.POLYMARKET_API_KEY;
    this.apiSecret = config.POLYMARKET_API_SECRET;
    this.apiPassphrase = config.POLYMARKET_API_PASSPHRASE;
    this.wallet = new ethers.Wallet(config.HOT_WALLET_PRIVATE_KEY);

    console.log(
      `[clob] Client initialized — wallet=${this.wallet.address} base=${this.baseUrl}`
    );
  }

  // ---- HMAC-SHA256 L2 Auth ------------------------------------------------

  private buildHmacSignature(
    timestamp: string,
    method: string,
    requestPath: string,
    body: string = ""
  ): string {
    const message = timestamp + method + requestPath + body;
    const secretBuffer = Buffer.from(this.apiSecret, "base64");
    const sig = createHmac("sha256", secretBuffer)
      .update(message)
      .digest("base64");
    // URL-safe base64: + → -, / → _
    return sig.replace(/\+/g, "-").replace(/\//g, "_");
  }

  private getL2Headers(
    method: string,
    requestPath: string,
    body: string = ""
  ): Record<string, string> {
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const signature = this.buildHmacSignature(
      timestamp,
      method,
      requestPath,
      body
    );
    return {
      POLY_ADDRESS: config.HOT_WALLET_ADDRESS,
      POLY_API_KEY: this.apiKey,
      POLY_PASSPHRASE: this.apiPassphrase,
      POLY_TIMESTAMP: timestamp,
      POLY_SIGNATURE: signature,
    };
  }

  // ---- Public API ----------------------------------------------------------

  async getOrderBook(tokenId: string): Promise<OrderBook | null> {
    const requestPath = `/book?token_id=${encodeURIComponent(tokenId)}`;
    try {
      const headers = this.getL2Headers("GET", requestPath);
      const resp = await fetch(`${this.baseUrl}${requestPath}`, {
        method: "GET",
        headers,
        signal: AbortSignal.timeout(10_000),
      });
      if (!resp.ok) {
        console.error(
          `[clob] getOrderBook: HTTP ${resp.status} for token ${tokenId}`
        );
        return null;
      }
      return (await resp.json()) as OrderBook;
    } catch (err) {
      console.error(`[clob] getOrderBook error for ${tokenId}:`, err);
      return null;
    }
  }

  async postOrder(
    signedOrder: SignedOrder,
    orderType: "GTC" | "FOK" | "GTD" = "GTC"
  ): Promise<OrderResponse> {
    const requestPath = "/order";
    const body = JSON.stringify({
      order: signedOrder,
      owner: signedOrder.maker,
      orderType,
    });

    const headers = this.getL2Headers("POST", requestPath, body);
    console.log(
      `[clob] postOrder: ${signedOrder.side === 0 ? "BUY" : "SELL"} ` +
        `tokenId=${signedOrder.tokenId} ` +
        `maker=${signedOrder.makerAmount} taker=${signedOrder.takerAmount}`
    );

    const resp = await fetch(`${this.baseUrl}${requestPath}`, {
      method: "POST",
      headers: {
        ...headers,
        "Content-Type": "application/json",
      },
      body,
      signal: AbortSignal.timeout(15_000),
    });

    const data = (await resp.json()) as OrderResponse;
    if (!resp.ok) {
      console.error(
        `[clob] postOrder: HTTP ${resp.status} — ${JSON.stringify(data)}`
      );
    }
    return data;
  }

  // ---- EIP-712 Order Signing -----------------------------------------------

  async createSignedOrder(params: {
    tokenId: string;
    price: number;
    sizeTokens: number;
    side: "BUY" | "SELL";
    negRisk?: boolean;
  }): Promise<SignedOrder> {
    const { tokenId, price, sizeTokens, side, negRisk = false } = params;

    const sideNum = side === "BUY" ? 0 : 1;
    const scale = 10 ** COLLATERAL_DECIMALS;

    let makerAmount: string;
    let takerAmount: string;

    if (side === "BUY") {
      // Give USDC, receive outcome tokens
      makerAmount = Math.round(price * sizeTokens * scale).toString();
      takerAmount = Math.round(sizeTokens * scale).toString();
    } else {
      // Give outcome tokens, receive USDC
      makerAmount = Math.round(sizeTokens * scale).toString();
      takerAmount = Math.round(price * sizeTokens * scale).toString();
    }

    const salt = ethers.BigNumber.from(
      ethers.utils.randomBytes(32)
    ).toString();
    const signerAddress = await this.wallet.getAddress();

    const exchangeAddress = negRisk ? NEG_RISK_CTF_EXCHANGE : CTF_EXCHANGE;
    const domainName = negRisk
      ? "Polymarket Neg Risk CTF Exchange"
      : "Polymarket CTF Exchange";

    const domain: ethers.TypedDataDomain = {
      name: domainName,
      version: "1",
      chainId: POLYGON_CHAIN_ID,
      verifyingContract: exchangeAddress,
    };

    const orderData = {
      salt,
      maker: config.HOT_WALLET_ADDRESS,
      signer: signerAddress,
      taker: ethers.constants.AddressZero,
      tokenId,
      makerAmount,
      takerAmount,
      expiration: "0",
      nonce: "0",
      feeRateBps: "0",
      side: sideNum,
      signatureType: 0, // EOA
    };

    const signature = await this.wallet._signTypedData(
      domain,
      ORDER_TYPES,
      orderData
    );

    return { ...orderData, signature };
  }
}
