import Redis from "ioredis";
import { z } from "zod";
import { config } from "./config.js";
import { ShadowExecutor, type TradeSignal } from "./shadow/shadow_executor.js";
import { LiveExecutor } from "./live/live_executor.js";
import { publishRaw, publishPublic } from "./publisher/neural_trace_pub.js";

// ---------------------------------------------------------------------------
// Zod schema for trade_signals messages
// ---------------------------------------------------------------------------

const TradeSignalSchema = z.object({
  schema_version: z.string(),
  event: z.literal("TRADE_SIGNAL"),
  signal_id: z.string().uuid(),
  verdict_id: z.string().uuid(),
  trade_signal_id: z.string().uuid(),
  market_id: z.string(),
  clob_token_id: z.string(),
  side: z.enum(["YES", "NO"]),
  composite_p: z.number(),
  kelly_fraction: z.number(),
  position_usdc: z.number(),
  wallet_exposure: z.number(),
  market_price_at_signal: z.number(),
  reasoning_summary: z.string(),
  primary_source_url: z.string(),
  expires_at: z.string(),
  timestamp: z.string(),
});

type TradeSignalMessage = z.infer<typeof TradeSignalSchema>;

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

let sub: Redis | null = null;
let circuitBreakerState: "ACTIVE" | "HIBERNATION" = "ACTIVE";
let shadowExecutor: ShadowExecutor | null = null;
let liveExecutor: LiveExecutor | null = null;

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

async function handleTradeSignal(raw: string): Promise<void> {
  // 1. Parse JSON
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    console.error("[broker] redis_sub: malformed JSON received, dropping");
    return;
  }

  // 2. Validate with zod
  const result = TradeSignalSchema.safeParse(parsed);
  if (!result.success) {
    console.error(
      "[broker] redis_sub: schema validation failed:",
      result.error.issues
    );
    return;
  }

  const msg = result.data;

  // 3. Check circuit breaker state
  if (circuitBreakerState === "HIBERNATION") {
    console.log(
      `[broker] redis_sub: signal ${msg.signal_id} rejected — circuit breaker in HIBERNATION`
    );
    await publishRaw("SIGNAL_REJECTED", {
      signal_id: msg.signal_id,
      market_id: msg.market_id,
      reason: "CIRCUIT_BREAKER_HIBERNATION",
    });
    await publishPublic("SIGNAL_REJECTED", {
      market_id: msg.market_id,
      reason: "Circuit breaker active",
    });
    return;
  }

  // 4. Check signal expiry
  const expiresAt = new Date(msg.expires_at);
  if (expiresAt <= new Date()) {
    console.log(
      `[broker] redis_sub: signal ${msg.signal_id} expired at ${msg.expires_at}, dropping`
    );
    return;
  }

  // 5. Build TradeSignal from validated message
  const signal: TradeSignal = {
    signal_id: msg.signal_id,
    verdict_id: msg.verdict_id,
    market_id: msg.market_id,
    clob_token_id: msg.clob_token_id,
    side: msg.side,
    composite_p: msg.composite_p,
    kelly_fraction: msg.kelly_fraction,
    position_usdc: msg.position_usdc,
    wallet_exposure: msg.wallet_exposure,
    market_price_at_signal: msg.market_price_at_signal,
    reasoning_summary: msg.reasoning_summary,
    primary_source_url: msg.primary_source_url,
  };

  // 6. Route based on DRY_RUN — this is the ONLY switch between shadow and live
  if (config.DRY_RUN === "true") {
    if (!shadowExecutor) {
      shadowExecutor = new ShadowExecutor();
    }
    try {
      await shadowExecutor.executeShadowTrade(signal);
    } catch (err) {
      console.error(
        `[broker] redis_sub: error executing shadow trade for ${msg.signal_id}:`,
        err
      );
    }
  } else {
    if (!liveExecutor) {
      liveExecutor = new LiveExecutor();
    }
    try {
      await liveExecutor.executeLiveTrade(signal);
    } catch (err) {
      console.error(
        `[broker] redis_sub: error executing live trade for ${msg.signal_id}:`,
        err
      );
    }
  }
}

function handleCircuitBreakerState(raw: string): void {
  try {
    const data = JSON.parse(raw) as { to_state?: string };
    if (data.to_state === "HIBERNATION" || data.to_state === "ACTIVE") {
      circuitBreakerState = data.to_state;
      console.log(
        `[broker] redis_sub: circuit breaker state updated to ${circuitBreakerState}`
      );
    }
  } catch {
    console.error(
      "[broker] redis_sub: malformed circuit_breaker_state message"
    );
  }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export async function startSubscriber(): Promise<void> {
  sub = new Redis(config.REDIS_URL, { lazyConnect: false });

  sub.on("message", (channel: string, message: string) => {
    if (channel === "trade_signals") {
      handleTradeSignal(message).catch((err) =>
        console.error("[broker] redis_sub: unhandled error in trade handler:", err)
      );
    } else if (channel === "circuit_breaker_state") {
      handleCircuitBreakerState(message);
    }
  });

  await sub.subscribe("trade_signals", "circuit_breaker_state");
  console.log(
    "[broker] Redis subscriber started — listening on trade_signals, circuit_breaker_state"
  );
}

export async function stopSubscriber(): Promise<void> {
  if (sub) {
    await sub.unsubscribe();
    await sub.quit();
    sub = null;
    console.log("[broker] Redis subscriber stopped");
  }
}

export function getCircuitBreakerState(): "ACTIVE" | "HIBERNATION" {
  return circuitBreakerState;
}
