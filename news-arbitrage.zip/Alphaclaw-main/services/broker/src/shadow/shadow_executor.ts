import { config } from "../config.js";
import { getPool } from "../db.js";
import { publishRaw, publishPublic } from "../publisher/neural_trace_pub.js";

export interface TradeSignal {
  signal_id: string;
  verdict_id: string;
  market_id: string;
  clob_token_id: string;
  side: "YES" | "NO";
  composite_p: number;
  kelly_fraction: number;
  position_usdc: number;
  wallet_exposure: number;
  market_price_at_signal: number;
  reasoning_summary: string;
  primary_source_url: string;
}

export class ShadowExecutor {
  constructor() {
    if (config.DRY_RUN !== "true") {
      throw new Error(
        "ShadowExecutor can only be used when DRY_RUN=true. " +
          `Current DRY_RUN=${config.DRY_RUN}`
      );
    }
    console.log("[broker] ShadowExecutor initialized (DRY_RUN=true)");
  }

  async executeShadowTrade(signal: TradeSignal): Promise<void> {
    // 1. Fetch top-of-book mid-price from CLOB API
    const entryPrice = await this.fetchMidPrice(signal.clob_token_id);
    if (entryPrice === null) {
      console.error(
        `[broker] ShadowExecutor: failed to fetch mid-price for ${signal.market_id}, skipping`
      );
      return;
    }

    // 2. Write shadow_trades row to TimescaleDB
    const pool = getPool();
    const result = await pool.query(
      `INSERT INTO shadow_trades (
        signal_id, verdict_id, market_id, clob_token_id, side, entry_price,
        composite_p, kelly_fraction, position_usdc, tracking_status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'PENDING')
      RETURNING id`,
      [
        signal.signal_id,
        signal.verdict_id,
        signal.market_id,
        signal.clob_token_id,
        signal.side,
        entryPrice,
        signal.composite_p,
        signal.kelly_fraction,
        signal.position_usdc,
      ]
    );

    const shadowTradeId = result.rows[0]?.id;
    console.log(
      `[broker] Shadow trade created: ${shadowTradeId} | ${signal.market_id} ${signal.side} @ ${entryPrice}`
    );

    // 3. Publish shadow STRIKE event to neural trace channels
    const tracePayload = {
      shadow_trade_id: shadowTradeId,
      market_id: signal.market_id,
      side: signal.side,
      entry_price: entryPrice,
      composite_p: signal.composite_p,
      kelly_fraction: signal.kelly_fraction,
      position_usdc: signal.position_usdc,
      reasoning_summary: signal.reasoning_summary,
      primary_source_url: signal.primary_source_url,
      shadow: true,
      signal_id: signal.signal_id,
      verdict_id: signal.verdict_id,
    };

    await publishRaw("TRADE_EXECUTED", tracePayload);
    await publishPublic("TRADE_EXECUTED", tracePayload);
  }

  private async fetchMidPrice(marketId: string): Promise<number | null> {
    try {
      const url = `${config.POLYMARKET_CLOB_BASE_URL}/midpoint?token_id=${encodeURIComponent(marketId)}`;
      const resp = await fetch(url, { signal: AbortSignal.timeout(10_000) });
      if (!resp.ok) {
        console.error(
          `[broker] fetchMidPrice: HTTP ${resp.status} for ${marketId}`
        );
        return null;
      }
      const data = (await resp.json()) as { mid?: string | number };
      if (data.mid === undefined || data.mid === null) {
        console.error(
          `[broker] fetchMidPrice: no 'mid' key in response for ${marketId}`
        );
        return null;
      }
      return parseFloat(String(data.mid));
    } catch (err) {
      console.error(`[broker] fetchMidPrice error for ${marketId}:`, err);
      return null;
    }
  }
}
