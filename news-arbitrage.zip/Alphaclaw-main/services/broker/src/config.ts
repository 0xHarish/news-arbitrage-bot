export const config = {
  // Infrastructure
  REDIS_URL: process.env.REDIS_URL ?? "redis://localhost:6379",
  TIMESCALE_URL:
    process.env.TIMESCALE_URL ??
    "postgresql://alphaclaw:password@localhost:5432/alphaclaw",

  // Polymarket
  POLYMARKET_CLOB_BASE_URL:
    process.env.POLYMARKET_CLOB_BASE_URL ?? "https://clob.polymarket.com",
  POLYMARKET_API_KEY: process.env.POLYMARKET_API_KEY ?? "",
  POLYMARKET_API_SECRET: process.env.POLYMARKET_API_SECRET ?? "",
  POLYMARKET_API_PASSPHRASE: process.env.POLYMARKET_API_PASSPHRASE ?? "",
  HOT_WALLET_PRIVATE_KEY: process.env.HOT_WALLET_PRIVATE_KEY ?? "",
  HOT_WALLET_ADDRESS: process.env.HOT_WALLET_ADDRESS ?? "",

  // Execution
  TWAP_SLICES: parseInt(process.env.TWAP_SLICES ?? "3", 10),
  TWAP_WINDOW_SECONDS: parseInt(process.env.TWAP_WINDOW_SECONDS ?? "90", 10),
  MAX_SLIPPAGE_BPS: parseInt(process.env.MAX_SLIPPAGE_BPS ?? "150", 10),
  MIN_BOOK_DEPTH_USDC: parseFloat(process.env.MIN_BOOK_DEPTH_USDC ?? "500"),

  // Shadow mode
  DRY_RUN: process.env.DRY_RUN ?? "true",

  // Circuit Breaker
  DAILY_LOSS_LIMIT_PCT: parseFloat(
    process.env.DAILY_LOSS_LIMIT_PCT ?? "15.0"
  ),

  // Twitter
  TWITTER_API_KEY: process.env.TWITTER_API_KEY ?? "",
  TWITTER_API_SECRET: process.env.TWITTER_API_SECRET ?? "",
  TWITTER_ACCESS_TOKEN: process.env.TWITTER_ACCESS_TOKEN ?? "",
  TWITTER_ACCESS_SECRET: process.env.TWITTER_ACCESS_SECRET ?? "",
  TWITTER_ENABLED: process.env.TWITTER_ENABLED === "true",
} as const;
