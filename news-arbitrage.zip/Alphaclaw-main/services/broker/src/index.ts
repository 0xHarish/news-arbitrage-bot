import { initDb, closeDb } from "./db.js";
import { startSubscriber, stopSubscriber } from "./redis_sub.js";
import { closePublisher } from "./publisher/neural_trace_pub.js";
import { config } from "./config.js";

async function main(): Promise<void> {
  console.log("[broker] AlphaClaw Broker starting...");
  console.log(`[broker] DRY_RUN=${config.DRY_RUN}`);

  // Initialize database pool
  await initDb();

  // Start Redis subscriber
  await startSubscriber();

  console.log("[broker] Broker is running. Press Ctrl+C to stop.");
}

async function shutdown(): Promise<void> {
  console.log("\n[broker] Shutting down gracefully...");
  await stopSubscriber();
  await closePublisher();
  await closeDb();
  console.log("[broker] Shutdown complete.");
  process.exit(0);
}

// Graceful shutdown handlers
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

main().catch((err) => {
  console.error("[broker] Fatal startup error:", err);
  process.exit(1);
});
