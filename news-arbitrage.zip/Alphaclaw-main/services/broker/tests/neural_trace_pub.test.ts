import { describe, test, expect, mock, beforeEach } from "bun:test";

// ---------------------------------------------------------------------------
// Mock ioredis
// ---------------------------------------------------------------------------

const mockPublish = mock(() => Promise.resolve(1));
const mockLpush = mock(() => Promise.resolve(1));
const mockLtrim = mock(() => Promise.resolve("OK"));
const mockQuit = mock(() => Promise.resolve());

mock.module("ioredis", () => ({
  default: class MockRedis {
    publish = mockPublish;
    lpush = mockLpush;
    ltrim = mockLtrim;
    quit = mockQuit;
  },
}));

mock.module("../src/config.js", () => ({
  config: {
    REDIS_URL: "redis://localhost:6379",
  },
}));

import { publishRaw, publishPublic } from "../src/publisher/neural_trace_pub.js";

describe("neural_trace_pub", () => {
  beforeEach(() => {
    mockPublish.mockClear();
    mockLpush.mockClear();
    mockLtrim.mockClear();
  });

  test("publishRaw sends to channel and history list", async () => {
    await publishRaw("SIGNAL_EVALUATED", { market_id: "0xabc" });

    expect(mockPublish).toHaveBeenCalledTimes(1);
    const publishArgs = mockPublish.mock.calls[0];
    expect(publishArgs[0]).toBe("neural_trace_raw");

    expect(mockLpush).toHaveBeenCalledTimes(1);
    const lpushArgs = mockLpush.mock.calls[0];
    expect(lpushArgs[0]).toBe("neural_trace_raw:history");

    expect(mockLtrim).toHaveBeenCalledTimes(1);
    const ltrimArgs = mockLtrim.mock.calls[0];
    expect(ltrimArgs[0]).toBe("neural_trace_raw:history");
    expect(ltrimArgs[1]).toBe(0);
    expect(ltrimArgs[2]).toBe(499);
  });

  test("publishPublic sends to channel and history list with 100 trim", async () => {
    await publishPublic("STRIKE", { market_title: "Test Market" });

    expect(mockPublish).toHaveBeenCalledTimes(1);
    const publishArgs = mockPublish.mock.calls[0];
    expect(publishArgs[0]).toBe("neural_trace_public");

    expect(mockLtrim).toHaveBeenCalledTimes(1);
    const ltrimArgs = mockLtrim.mock.calls[0];
    expect(ltrimArgs[2]).toBe(99);
  });

  test("publishPublic sanitizes sensitive fields", async () => {
    const payload = {
      market_title: "Test Market",
      raw_text: "SECRET TEXT",
      canonical_tokens: ["secret", "tokens"],
      opus_raw_reasoning: "internal reasoning",
      fast_match_score: 0.92,
      opus_confidence: 0.95,
      signal_id: "should-be-removed",
      verdict_id: "should-be-removed",
      safe_field: "should-remain",
    };

    await publishPublic("STRIKE", payload);

    const lpushArgs = mockLpush.mock.calls[0];
    const published = JSON.parse(lpushArgs[1] as string);

    expect(published.payload.market_title).toBe("Test Market");
    expect(published.payload.safe_field).toBe("should-remain");
    expect(published.payload.raw_text).toBeUndefined();
    expect(published.payload.canonical_tokens).toBeUndefined();
    expect(published.payload.opus_raw_reasoning).toBeUndefined();
    expect(published.payload.fast_match_score).toBeUndefined();
    expect(published.payload.opus_confidence).toBeUndefined();
    expect(published.payload.signal_id).toBeUndefined();
    expect(published.payload.verdict_id).toBeUndefined();
  });

  test("publishPublic maps event types correctly", async () => {
    await publishPublic("TRADE_EXECUTED", { market_title: "Test" });

    const publishArgs = mockPublish.mock.calls[0];
    const published = JSON.parse(publishArgs[1] as string);
    expect(published.event_type).toBe("STRIKE");
  });
});
