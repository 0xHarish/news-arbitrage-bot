import { describe, test, expect, mock, beforeEach } from "bun:test";

// ---------------------------------------------------------------------------
// Mock ioredis before importing the module under test
// ---------------------------------------------------------------------------

const mockSubscribe = mock(() => Promise.resolve());
const mockUnsubscribe = mock(() => Promise.resolve());
const mockQuit = mock(() => Promise.resolve());
const mockOn = mock((_event: string, _handler: Function) => {});

mock.module("ioredis", () => ({
  default: class MockRedis {
    subscribe = mockSubscribe;
    unsubscribe = mockUnsubscribe;
    quit = mockQuit;
    on = mockOn;
  },
}));

// Mock neural_trace_pub
const mockPublishRaw = mock(() => Promise.resolve());
const mockPublishPublic = mock(() => Promise.resolve());
mock.module("../src/publisher/neural_trace_pub.js", () => ({
  publishRaw: mockPublishRaw,
  publishPublic: mockPublishPublic,
  closePublisher: mock(() => Promise.resolve()),
}));

// Mock shadow executor
const mockExecuteShadowTrade = mock(() => Promise.resolve());
mock.module("../src/shadow/shadow_executor.js", () => ({
  ShadowExecutor: class {
    constructor() {}
    executeShadowTrade = mockExecuteShadowTrade;
  },
}));

// Mock db
mock.module("../src/db.js", () => ({
  getPool: () => ({ query: mock(() => Promise.resolve({ rows: [{ id: "test-id" }] })) }),
  initDb: mock(() => Promise.resolve()),
  closeDb: mock(() => Promise.resolve()),
}));

// ---------------------------------------------------------------------------
// Test data
// ---------------------------------------------------------------------------

const validSignal = {
  schema_version: "1.0",
  event: "TRADE_SIGNAL" as const,
  signal_id: "550e8400-e29b-41d4-a716-446655440000",
  verdict_id: "550e8400-e29b-41d4-a716-446655440001",
  trade_signal_id: "550e8400-e29b-41d4-a716-446655440002",
  market_id: "0xabc123",
  side: "YES" as const,
  composite_p: 0.87,
  kelly_fraction: 0.043,
  position_usdc: 43.0,
  wallet_exposure: 0.043,
  market_price_at_signal: 0.31,
  reasoning_summary: "AP called the race.",
  primary_source_url: "https://apnews.com/article/test",
  expires_at: new Date(Date.now() + 60_000).toISOString(), // 1 min in future
  timestamp: new Date().toISOString(),
};

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

import { z } from "zod";

const TradeSignalSchema = z.object({
  schema_version: z.string(),
  event: z.literal("TRADE_SIGNAL"),
  signal_id: z.string().uuid(),
  verdict_id: z.string().uuid(),
  trade_signal_id: z.string().uuid(),
  market_id: z.string(),
  side: z.enum(["YES", "NO"]),
  composite_p: z.number(),
  kelly_fraction: z.number(),
  position_usdc: z.number(),
  wallet_exposure: z.number(),
  market_price_at_signal: z.number(),
  reasoning_summary: z.string(),
  primary_source_url: z.string(),
  expires_at: z.string(),
  timestamp: z.string(),
});

describe("redis_sub — message validation", () => {
  test("valid message passes zod schema", () => {
    const result = TradeSignalSchema.safeParse(validSignal);
    expect(result.success).toBe(true);
  });

  test("malformed JSON is rejected", () => {
    const result = TradeSignalSchema.safeParse("not json");
    expect(result.success).toBe(false);
  });

  test("missing required fields are rejected", () => {
    const incomplete = { ...validSignal, market_id: undefined };
    const result = TradeSignalSchema.safeParse(incomplete);
    expect(result.success).toBe(false);
  });

  test("invalid side value is rejected", () => {
    const badSide = { ...validSignal, side: "MAYBE" };
    const result = TradeSignalSchema.safeParse(badSide);
    expect(result.success).toBe(false);
  });

  test("invalid event type is rejected", () => {
    const badEvent = { ...validSignal, event: "NOT_A_SIGNAL" };
    const result = TradeSignalSchema.safeParse(badEvent);
    expect(result.success).toBe(false);
  });
});

describe("redis_sub — expiry check", () => {
  test("expired signal is detected", () => {
    const expired = new Date(Date.now() - 60_000); // 1 min in past
    expect(expired <= new Date()).toBe(true);
  });

  test("future signal passes expiry check", () => {
    const future = new Date(Date.now() + 60_000);
    expect(future <= new Date()).toBe(false);
  });
});

describe("redis_sub — circuit breaker", () => {
  test("HIBERNATION state parsing", () => {
    const msg = JSON.stringify({ to_state: "HIBERNATION" });
    const data = JSON.parse(msg) as { to_state?: string };
    expect(data.to_state).toBe("HIBERNATION");
  });

  test("ACTIVE state parsing", () => {
    const msg = JSON.stringify({ to_state: "ACTIVE" });
    const data = JSON.parse(msg) as { to_state?: string };
    expect(data.to_state).toBe("ACTIVE");
  });
});
