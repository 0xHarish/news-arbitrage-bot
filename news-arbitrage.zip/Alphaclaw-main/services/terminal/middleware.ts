import { NextRequest, NextResponse } from "next/server";

const ADMIN_ALLOWED_IPS = (process.env.ADMIN_ALLOWED_IPS ?? "127.0.0.1")
  .split(",")
  .map((ip) => ip.trim());

export function middleware(request: NextRequest) {
  const { pathname, searchParams } = request.nextUrl;

  // Only gate admin routes and raw WebSocket feed
  const isAdminRoute = pathname.startsWith("/admin");
  const isRawWsFeed =
    pathname.startsWith("/api/ws") && searchParams.get("feed") === "raw";

  if (!isAdminRoute && !isRawWsFeed) {
    return NextResponse.next();
  }

  // Get client IP
  const clientIp =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    request.headers.get("x-real-ip") ??
    "unknown";

  // Return 404 (not 403) to hide admin route existence
  if (!ADMIN_ALLOWED_IPS.includes(clientIp)) {
    return new NextResponse("Not Found", { status: 404 });
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/api/ws/:path*"],
};
