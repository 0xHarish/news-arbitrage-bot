import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Do not log full URLs (security requirement per spec §17.6)
  logging: {
    fetches: {
      fullUrl: false,
    },
  },
};

export default nextConfig;
