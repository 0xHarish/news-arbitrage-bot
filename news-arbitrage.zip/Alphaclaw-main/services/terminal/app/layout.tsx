import type { Metadata } from "next";
import { JetBrains_Mono } from "next/font/google";
import "./globals.css";
import CircuitBreakerPill from "./components/CircuitBreakerPill";

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
});

export const metadata: Metadata = {
  title: "ALPHACLAW | Neural Trace Terminal",
  description: "Autonomous AI trading agent — live neural trace feed",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body
        className={`${jetbrainsMono.variable} font-mono bg-bg text-primary min-h-screen flex flex-col`}
      >
        {/* Fixed header */}
        <header className="sticky top-0 z-50 flex items-center justify-between px-6 py-3 border-b border-border bg-bg/95 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold tracking-widest text-primary">
              ALPHACLAW
            </h1>
            <span className="text-xs text-gray">v0.1.0</span>
          </div>
          <CircuitBreakerPill />
        </header>

        {/* Main content */}
        <main className="flex-1 flex">{children}</main>
      </body>
    </html>
  );
}
