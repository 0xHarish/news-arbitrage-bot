import NeuralTrace from "./components/NeuralTrace";
import PnLDisplay from "./components/PnLDisplay";

export default function Home() {
  return (
    <div className="flex w-full h-[calc(100vh-57px)]">
      {/* Left panel: Neural Trace feed (60%) */}
      <div className="w-[60%] border-r border-border overflow-hidden">
        <NeuralTrace feed="public" />
      </div>

      {/* Right panel: PnL + Stats sidebar (40%) */}
      <div className="w-[40%] p-6 overflow-y-auto">
        <PnLDisplay />

        {/* Stats section */}
        <div className="mt-8 space-y-4">
          <h2 className="text-sm font-bold text-gray uppercase tracking-wider">
            System Status
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-surface border border-border rounded-lg p-4">
              <div className="text-xs text-gray">Mode</div>
              <div className="text-amber text-sm font-bold mt-1">
                [SHADOW]
              </div>
            </div>
            <div className="bg-surface border border-border rounded-lg p-4">
              <div className="text-xs text-gray">Phase</div>
              <div className="text-primary text-sm font-bold mt-1">2</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
