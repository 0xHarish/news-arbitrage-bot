"use client";

import NeuralTrace from "../components/NeuralTrace";

export default function AdminPage() {
  // In production, token would come from a login flow or cookie
  const token =
    typeof window !== "undefined"
      ? new URLSearchParams(window.location.search).get("token") ?? ""
      : "";

  return (
    <div className="flex flex-col w-full h-[calc(100vh-57px)]">
      {/* Header */}
      <div className="px-6 py-3 border-b border-border bg-surface">
        <div className="flex items-center gap-3">
          <h2 className="text-sm font-bold text-red uppercase tracking-wider">
            ADMIN RAW FEED
          </h2>
          <span className="text-xs text-gray">
            neural_trace_raw — unfiltered
          </span>
        </div>
      </div>

      {/* Raw neural trace feed */}
      <div className="flex-1 overflow-hidden">
        <NeuralTrace feed="raw" token={token} />
      </div>
    </div>
  );
}
