import { NextRequest } from "next/server";
import Redis from "ioredis";

const REDIS_URL = process.env.REDIS_URL ?? "redis://localhost:6379";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest) {
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      const sub = new Redis(REDIS_URL, { lazyConnect: false });

      // Send initial keepalive comment
      controller.enqueue(encoder.encode(": connected\n\n"));

      // Subscribe to pnl_updates channel
      sub.subscribe("pnl_updates").catch((err: Error) => {
        console.error("[terminal] pnl SSE: subscribe error:", err);
      });

      sub.on("message", (_channel: string, message: string) => {
        try {
          // Format as SSE
          const sseData = `data: ${message}\n\n`;
          controller.enqueue(encoder.encode(sseData));
        } catch {
          // Client may have disconnected
        }
      });

      // Send keepalive comment every 15 seconds
      const keepalive = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(": keepalive\n\n"));
        } catch {
          clearInterval(keepalive);
        }
      }, 15_000);

      // Cleanup when the stream is cancelled
      const cleanup = async () => {
        clearInterval(keepalive);
        try {
          await sub.unsubscribe();
          await sub.quit();
        } catch {
          // Suppress cleanup errors
        }
      };

      // Handle client disconnect
      _req.signal.addEventListener("abort", () => {
        cleanup();
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
