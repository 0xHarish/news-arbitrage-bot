import { NextRequest } from "next/server";
import crypto from "crypto";
import Redis from "ioredis";

const REDIS_URL = process.env.REDIS_URL ?? "redis://localhost:6379";
const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET ?? "";
const ADMIN_ALLOWED_IPS = (process.env.ADMIN_ALLOWED_IPS ?? "127.0.0.1")
  .split(",")
  .map((ip) => ip.trim());

const PING_INTERVAL_MS = 30_000;

// ---------------------------------------------------------------------------
// WebSocket upgrade handler
// ---------------------------------------------------------------------------

export async function GET(req: NextRequest) {
  // Check if the runtime supports WebSocket upgrades
  const upgradeHeader = req.headers.get("upgrade");
  if (upgradeHeader !== "websocket") {
    return new Response("Expected WebSocket upgrade", { status: 426 });
  }

  const { searchParams } = new URL(req.url);
  const feed = searchParams.get("feed") ?? "public";
  const token = searchParams.get("token") ?? "";

  // Determine channel and history key
  const isRaw = feed === "raw";
  const channel = isRaw ? "neural_trace_raw" : "neural_trace_public";
  const historyKey = `${channel}:history`;

  // For raw feed: validate IP and token
  if (isRaw) {
    const clientIp =
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      req.headers.get("x-real-ip") ??
      "unknown";

    if (!ADMIN_ALLOWED_IPS.includes(clientIp)) {
      return new Response("Not Found", { status: 404 });
    }

    if (!token || !validateToken(token)) {
      return new Response("Not Found", { status: 404 });
    }
  }

  // Upgrade to WebSocket using the server's upgrade mechanism
  // @ts-expect-error - WebSocket upgrade API varies by runtime
  const { socket, response } = Deno?.upgradeWebSocket?.(req) ??
    upgradeWebSocket(req);

  // Handle WebSocket lifecycle
  handleWebSocket(socket, channel, historyKey);

  return response;
}

// ---------------------------------------------------------------------------
// Token validation using timing-safe comparison
// ---------------------------------------------------------------------------

function validateToken(token: string): boolean {
  try {
    // Simple JWT structure validation
    const parts = token.split(".");
    if (parts.length !== 3) return false;

    // Verify signature using timing-safe comparison
    const [header, payload, signature] = parts;
    const expectedSig = crypto
      .createHmac("sha256", ADMIN_JWT_SECRET)
      .update(`${header}.${payload}`)
      .digest("base64url");

    const sigBuffer = Buffer.from(signature, "base64url");
    const expectedBuffer = Buffer.from(expectedSig, "base64url");

    if (sigBuffer.length !== expectedBuffer.length) return false;
    return crypto.timingSafeEqual(sigBuffer, expectedBuffer);
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// WebSocket handler
// ---------------------------------------------------------------------------

function handleWebSocket(
  socket: WebSocket,
  channel: string,
  historyKey: string
) {
  let sub: Redis | null = null;
  let pingTimer: ReturnType<typeof setInterval> | null = null;
  let pongReceived = true;

  socket.onopen = async () => {
    // Create a dedicated Redis subscriber
    sub = new Redis(REDIS_URL, { lazyConnect: false });

    // Send snapshot of last 20 events
    try {
      const pubRedis = new Redis(REDIS_URL);
      const history = await pubRedis.lrange(historyKey, 0, 19);
      await pubRedis.quit();

      socket.send(
        JSON.stringify({
          type: "SNAPSHOT",
          data: history.map((h) => JSON.parse(h)),
        })
      );
    } catch (err) {
      console.error("[terminal] ws: snapshot error:", err);
    }

    // Subscribe to channel and forward events
    sub.on("message", (_ch: string, message: string) => {
      try {
        socket.send(
          JSON.stringify({
            type: "EVENT",
            data: JSON.parse(message),
          })
        );
      } catch {
        // Client may have disconnected
      }
    });

    await sub.subscribe(channel);

    // Start PING/PONG keepalive
    pingTimer = setInterval(() => {
      if (!pongReceived) {
        socket.close(1001, "PONG timeout");
        return;
      }
      pongReceived = false;
      try {
        socket.send(JSON.stringify({ type: "PING" }));
      } catch {
        // Socket may be closing
      }
    }, PING_INTERVAL_MS);
  };

  socket.onmessage = (event: MessageEvent) => {
    try {
      const msg = JSON.parse(String(event.data));
      if (msg.type === "PONG") {
        pongReceived = true;
      }
    } catch {
      // Ignore malformed messages
    }
  };

  socket.onclose = async () => {
    // Cleanup
    if (pingTimer) clearInterval(pingTimer);
    if (sub) {
      try {
        await sub.unsubscribe();
        await sub.quit();
      } catch {
        // Suppress cleanup errors
      }
      sub = null;
    }
  };
}

// ---------------------------------------------------------------------------
// Fallback WebSocket upgrade for Node.js / Next.js runtime
// ---------------------------------------------------------------------------

function upgradeWebSocket(req: NextRequest) {
  // This is a placeholder — actual WebSocket upgrade depends on the
  // deployment runtime (Node.js custom server, Bun, Deno, etc.)
  // Next.js App Router doesn't natively support WS in all runtimes.
  // For production, use a custom server (e.g., Node.js with ws library).
  throw new Error(
    "WebSocket upgrade not supported in this runtime. " +
      "Use a custom Node.js server or deploy on a WS-compatible runtime."
  );
}
