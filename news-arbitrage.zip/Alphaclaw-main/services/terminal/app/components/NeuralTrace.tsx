"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import TradeCard from "./TradeCard";
import { getWsUrl } from "@/lib/ws";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface TraceEvent {
  event_type: string;
  event_id: string;
  timestamp: string;
  payload: Record<string, any>;
}

interface NeuralTraceProps {
  feed: "public" | "raw";
  token?: string;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const EVENT_COLORS: Record<string, string> = {
  HUNT: "text-amber bg-amber/15 border-amber/30",
  STRIKE: "text-primary bg-primary/15 border-primary/30",
  PASS: "text-gray bg-gray/15 border-gray/30",
  SHIELD: "text-red bg-red/15 border-red/30",
};

const EVENT_BADGE_COLORS: Record<string, string> = {
  HUNT: "bg-amber/20 text-amber border border-amber/40",
  STRIKE: "bg-primary/20 text-primary border border-primary/40",
  PASS: "bg-gray/20 text-gray border border-gray/40",
  SHIELD: "bg-red/20 text-red border border-red/40",
};

const MAX_EVENTS = 200;

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export default function NeuralTrace({ feed, token }: NeuralTraceProps) {
  const [events, setEvents] = useState<TraceEvent[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<TraceEvent | null>(null);
  const [connected, setConnected] = useState(false);

  const feedRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reconnectDelayRef = useRef(1000);

  // Auto-scroll when not paused
  useEffect(() => {
    if (!isPaused && bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [events, isPaused]);

  // WebSocket connection with auto-reconnect
  const connect = useCallback(() => {
    let url = getWsUrl(feed);
    if (feed === "raw" && token) {
      url += `&token=${encodeURIComponent(token)}`;
    }

    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => {
      setConnected(true);
      reconnectDelayRef.current = 1000; // Reset backoff on success
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);

        if (msg.type === "PING") {
          ws.send(JSON.stringify({ type: "PONG" }));
          return;
        }

        if (msg.type === "SNAPSHOT" && Array.isArray(msg.data)) {
          setEvents(msg.data.reverse()); // Oldest first
          return;
        }

        if (msg.type === "EVENT" && msg.data) {
          setEvents((prev) => {
            const next = [...prev, msg.data];
            return next.length > MAX_EVENTS ? next.slice(-MAX_EVENTS) : next;
          });
        }
      } catch {
        // Ignore malformed messages
      }
    };

    ws.onclose = () => {
      setConnected(false);
      wsRef.current = null;

      // Exponential backoff reconnect (max 30s)
      const delay = reconnectDelayRef.current;
      reconnectTimeoutRef.current = setTimeout(() => {
        reconnectDelayRef.current = Math.min(delay * 2, 30_000);
        connect();
      }, delay);
    };

    ws.onerror = () => {
      ws.close();
    };
  }, [feed, token]);

  useEffect(() => {
    connect();

    return () => {
      if (wsRef.current) wsRef.current.close();
      if (reconnectTimeoutRef.current)
        clearTimeout(reconnectTimeoutRef.current);
    };
  }, [connect]);

  // Pause on hover
  const handleMouseEnter = () => setIsPaused(true);
  const handleMouseLeave = () => setIsPaused(false);

  // Format timestamp
  const formatTime = (ts: string) => {
    try {
      return new Date(ts).toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });
    } catch {
      return "??:??:??";
    }
  };

  // Truncate text
  const truncate = (text: string, max: number) =>
    text.length > max ? text.slice(0, max) + "..." : text;

  return (
    <div className="flex flex-col h-full">
      {/* Feed header */}
      <div className="px-4 py-2 border-b border-border flex items-center justify-between bg-surface">
        <div className="flex items-center gap-2">
          <div
            className={`w-2 h-2 rounded-full ${connected ? "bg-primary" : "bg-red animate-pulse"}`}
          />
          <span className="text-xs text-gray uppercase tracking-wider">
            Neural Trace
          </span>
          <span className="text-xs text-gray">
            ({feed === "raw" ? "RAW" : "PUBLIC"})
          </span>
        </div>
        <span className="text-xs text-gray">{events.length} events</span>
      </div>

      {/* Event feed */}
      <div
        ref={feedRef}
        className="flex-1 overflow-y-auto px-2 py-1"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        {events.length === 0 && (
          <div className="flex items-center justify-center h-full text-gray text-sm">
            Waiting for signals...
          </div>
        )}

        {events.map((event, i) => {
          const eventType = event.event_type ?? "UNKNOWN";
          const badgeClass =
            EVENT_BADGE_COLORS[eventType] ?? EVENT_BADGE_COLORS.PASS;
          const marketTitle =
            event.payload?.market_title ?? event.payload?.market_id ?? "";
          const action = event.payload?.action ?? "";
          const delta15m = event.payload?.delta_15m;
          const delta1h = event.payload?.delta_1h;

          return (
            <div
              key={event.event_id ?? i}
              className="flex items-start gap-3 py-2 px-2 border-b border-border/50 hover:bg-surface/50 cursor-pointer transition-colors"
              onClick={() =>
                eventType === "STRIKE" ? setSelectedEvent(event) : null
              }
            >
              {/* Timestamp */}
              <span className="text-xs text-gray whitespace-nowrap mt-0.5">
                {formatTime(event.timestamp)}
              </span>

              {/* Event type badge */}
              <span
                className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${badgeClass}`}
              >
                {eventType}
              </span>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="text-sm">
                  {truncate(marketTitle, 60)}
                  {action && (
                    <span className="ml-2 text-xs text-gray">{action}</span>
                  )}
                </div>

                {/* Progressive reveal: deltas */}
                <div className="flex gap-4 mt-1 text-xs">
                  <span className="text-gray">
                    15m:{" "}
                    <span
                      className={
                        delta15m != null
                          ? delta15m >= 0
                            ? "text-primary"
                            : "text-red"
                          : "text-gray"
                      }
                    >
                      {delta15m != null
                        ? `${delta15m >= 0 ? "+" : ""}${(delta15m * 100).toFixed(1)}%`
                        : "\u2014"}
                    </span>
                  </span>
                  <span className="text-gray">
                    1h:{" "}
                    <span
                      className={
                        delta1h != null
                          ? delta1h >= 0
                            ? "text-primary"
                            : "text-red"
                          : "text-gray"
                      }
                    >
                      {delta1h != null
                        ? `${delta1h >= 0 ? "+" : ""}${(delta1h * 100).toFixed(1)}%`
                        : "\u2014"}
                    </span>
                  </span>
                </div>
              </div>

              {/* Shadow badge */}
              <span className="text-xs text-amber italic whitespace-nowrap mt-0.5">
                [SHADOW]
              </span>
            </div>
          );
        })}

        <div ref={bottomRef} />
      </div>

      {/* Pause indicator */}
      {isPaused && (
        <div className="px-4 py-1 bg-amber/10 border-t border-amber/30 text-center">
          <span className="text-xs text-amber">PAUSED — hover to read</span>
        </div>
      )}

      {/* Trade card overlay */}
      {selectedEvent && (
        <TradeCard
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
        />
      )}
    </div>
  );
}
