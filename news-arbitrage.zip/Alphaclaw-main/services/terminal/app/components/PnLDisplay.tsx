"use client";

import { useEffect, useState } from "react";

interface PnLData {
  total_usdc: number;
  realized_pnl_today: number;
  realized_pnl_today_pct: number;
  open_positions: number;
  circuit_breaker_state?: "ACTIVE" | "HIBERNATION";
}

const DAILY_LOSS_LIMIT_PCT = 15.0;
const WARNING_THRESHOLD_PCT = 10.0; // Amber when within 5% of limit

export default function PnLDisplay() {
  const [pnl, setPnl] = useState<PnLData>({
    total_usdc: 0,
    realized_pnl_today: 0,
    realized_pnl_today_pct: 0,
    open_positions: 0,
  });
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const eventSource = new EventSource("/api/pnl");

    eventSource.onopen = () => setConnected(true);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setPnl({
          total_usdc: data.total_usdc ?? 0,
          realized_pnl_today: data.realized_pnl_today ?? 0,
          realized_pnl_today_pct: data.realized_pnl_today_pct ?? 0,
          open_positions:
            data.open_positions_count ??
            (Array.isArray(data.open_positions)
              ? data.open_positions.length
              : 0),
          circuit_breaker_state: data.circuit_breaker_state,
        });
      } catch {
        // Ignore parse errors
      }
    };

    eventSource.onerror = () => {
      setConnected(false);
    };

    return () => eventSource.close();
  }, []);

  // Determine PnL color state
  const pnlPct = Math.abs(pnl.realized_pnl_today_pct);
  const isWarning =
    pnl.realized_pnl_today_pct < 0 && pnlPct >= WARNING_THRESHOLD_PCT;
  const isCritical =
    pnl.circuit_breaker_state === "HIBERNATION" ||
    pnlPct >= DAILY_LOSS_LIMIT_PCT;

  const pnlColor = isCritical
    ? "text-red"
    : isWarning
      ? "text-amber"
      : pnl.realized_pnl_today_pct >= 0
        ? "text-primary"
        : "text-red";

  return (
    <div className="space-y-6">
      {/* Wallet balance */}
      <div className="bg-surface border border-border rounded-lg p-6">
        <div className="text-xs text-gray uppercase tracking-wider mb-1">
          Wallet Balance
        </div>
        <div className="text-3xl font-bold text-primary">
          ${pnl.total_usdc.toLocaleString("en-US", { minimumFractionDigits: 2 })}
        </div>
        <div className="text-xs text-gray mt-1">USDC (Shadow)</div>
      </div>

      {/* Today's PnL */}
      <div
        className={`bg-surface border rounded-lg p-6 ${
          isCritical
            ? "border-red animate-pulse"
            : isWarning
              ? "border-amber"
              : "border-border"
        }`}
      >
        <div className="text-xs text-gray uppercase tracking-wider mb-1">
          Today&apos;s P&amp;L
        </div>
        <div className={`text-2xl font-bold ${pnlColor}`}>
          {pnl.realized_pnl_today_pct >= 0 ? "+" : ""}
          {pnl.realized_pnl_today_pct.toFixed(2)}%
        </div>
        <div className={`text-sm ${pnlColor}`}>
          {pnl.realized_pnl_today >= 0 ? "+" : ""}$
          {pnl.realized_pnl_today.toFixed(2)}
        </div>
        {isWarning && !isCritical && (
          <div className="text-xs text-amber mt-2">
            Approaching daily loss limit ({DAILY_LOSS_LIMIT_PCT}%)
          </div>
        )}
        {isCritical && (
          <div className="text-xs text-red mt-2 font-bold">
            CIRCUIT BREAKER — HIBERNATION
          </div>
        )}
      </div>

      {/* Open positions */}
      <div className="bg-surface border border-border rounded-lg p-6">
        <div className="text-xs text-gray uppercase tracking-wider mb-1">
          Open Positions
        </div>
        <div className="text-2xl font-bold text-primary">
          {pnl.open_positions}
        </div>
      </div>

      {/* Connection status */}
      <div className="flex items-center gap-2 text-xs text-gray">
        <div
          className={`w-1.5 h-1.5 rounded-full ${connected ? "bg-primary" : "bg-red"}`}
        />
        {connected ? "PnL feed connected" : "PnL feed disconnected"}
      </div>
    </div>
  );
}
