"use client";

import { useEffect, useState } from "react";

export default function CircuitBreakerPill() {
  const [state, setState] = useState<"ACTIVE" | "HIBERNATION">("ACTIVE");

  useEffect(() => {
    // Subscribe to PnL SSE to detect circuit breaker state changes
    const eventSource = new EventSource("/api/pnl");

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.circuit_breaker_state) {
          setState(data.circuit_breaker_state);
        }
      } catch {
        // Ignore parse errors
      }
    };

    return () => eventSource.close();
  }, []);

  const isActive = state === "ACTIVE";

  return (
    <div
      className={`
        px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider
        ${
          isActive
            ? "bg-primary/20 text-primary border border-primary/40"
            : "bg-red/20 text-red border border-red/40 animate-pulse"
        }
      `}
    >
      {state}
    </div>
  );
}
