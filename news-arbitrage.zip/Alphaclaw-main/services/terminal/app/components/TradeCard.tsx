"use client";

interface TraceEvent {
  event_type: string;
  event_id: string;
  timestamp: string;
  payload: Record<string, any>;
}

interface TradeCardProps {
  event: TraceEvent;
  onClose: () => void;
}

export default function TradeCard({ event, onClose }: TradeCardProps) {
  const p = event.payload ?? {};

  const side = p.side ?? "?";
  const entryPrice = p.entry_price ?? p.market_price_at_signal ?? 0;
  const edgePct = p.edge_pct ?? 0;
  const positionUsdc = p.position_usdc ?? 0;
  const compositeP = p.composite_p ?? 0;
  const delta15m = p.delta_15m;
  const delta1h = p.delta_1h;
  const delta24h = p.delta_24h;
  const mfe = p.max_favorable ?? 0;
  const mae = p.max_adverse ?? 0;
  const priceBasis = p.price_24h_basis;
  const sourceUrl = p.source_url ?? p.primary_source_url;
  const reasoning = p.reasoning_summary ?? "";
  const marketTitle = p.market_title ?? p.market_id ?? "Unknown Market";

  const formatDelta = (delta: number | null | undefined) => {
    if (delta == null) return "\u2014";
    const pct = (delta * 100).toFixed(2);
    const arrow = delta >= 0 ? "\u2191" : "\u2193";
    return `${arrow} ${delta >= 0 ? "+" : ""}${pct}%`;
  };

  const deltaColor = (delta: number | null | undefined) => {
    if (delta == null) return "text-gray";
    return delta >= 0 ? "text-primary" : "text-red";
  };

  // Max value for MFE/MAE bar scaling
  const maxExcursion = Math.max(mfe, mae, 0.01);

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
      <div className="bg-surface border border-border rounded-lg max-w-lg w-full max-h-[80vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-start justify-between p-4 border-b border-border">
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-bold text-primary">{marketTitle}</h3>
            <div className="flex items-center gap-2 mt-2">
              <span
                className={`px-2 py-0.5 rounded text-xs font-bold ${
                  side === "YES"
                    ? "bg-primary/20 text-primary border border-primary/40"
                    : "bg-red/20 text-red border border-red/40"
                }`}
              >
                {side}
              </span>
              <span className="text-xs text-gray italic">[SHADOW]</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray hover:text-primary transition-colors text-lg ml-4"
          >
            x
          </button>
        </div>

        {/* Metrics grid */}
        <div className="grid grid-cols-2 gap-3 p-4">
          <div>
            <div className="text-xs text-gray">Entry Price</div>
            <div className="text-sm font-bold">
              ${Number(entryPrice).toFixed(4)}
            </div>
          </div>
          <div>
            <div className="text-xs text-gray">Edge</div>
            <div className="text-sm font-bold text-primary">
              +{Number(edgePct).toFixed(1)}%
            </div>
          </div>
          <div>
            <div className="text-xs text-gray">Position</div>
            <div className="text-sm font-bold">
              ${Number(positionUsdc).toFixed(2)}
            </div>
          </div>
          <div>
            <div className="text-xs text-gray">Composite P</div>
            <div className="text-sm font-bold">
              {(Number(compositeP) * 100).toFixed(1)}%
            </div>
          </div>
        </div>

        {/* Price deltas */}
        <div className="px-4 pb-3">
          <div className="text-xs text-gray mb-2 uppercase tracking-wider">
            Price Movement
          </div>
          <div className="flex gap-6">
            <div>
              <div className="text-xs text-gray">15m</div>
              <div className={`text-sm font-bold ${deltaColor(delta15m)}`}>
                {formatDelta(delta15m)}
              </div>
            </div>
            <div>
              <div className="text-xs text-gray">1h</div>
              <div className={`text-sm font-bold ${deltaColor(delta1h)}`}>
                {formatDelta(delta1h)}
              </div>
            </div>
            <div>
              <div className="text-xs text-gray">24h</div>
              <div className={`text-sm font-bold ${deltaColor(delta24h)}`}>
                {formatDelta(delta24h)}
              </div>
            </div>
          </div>
        </div>

        {/* MFE / MAE bars */}
        <div className="px-4 pb-3">
          <div className="text-xs text-gray mb-2 uppercase tracking-wider">
            Excursion
          </div>
          <div className="space-y-2">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-primary">MFE (Favorable)</span>
                <span className="text-primary">
                  {(mfe * 100).toFixed(2)}%
                </span>
              </div>
              <div className="h-2 bg-border rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all"
                  style={{ width: `${(mfe / maxExcursion) * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-red">MAE (Adverse)</span>
                <span className="text-red">{(mae * 100).toFixed(2)}%</span>
              </div>
              <div className="h-2 bg-border rounded-full overflow-hidden">
                <div
                  className="h-full bg-red rounded-full transition-all"
                  style={{ width: `${(mae / maxExcursion) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Price basis */}
        {priceBasis && (
          <div className="px-4 pb-3">
            <span className="text-xs text-gray">24h Basis: </span>
            <span className="text-xs font-bold">
              {priceBasis === "settlement" ? "Settlement" : "Mark-to-Market"}
            </span>
          </div>
        )}

        {/* Source URL */}
        {sourceUrl && (
          <div className="px-4 pb-3">
            <a
              href={sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-amber hover:underline inline-flex items-center gap-1"
            >
              {sourceUrl.length > 50
                ? sourceUrl.slice(0, 50) + "..."
                : sourceUrl}
              <svg
                className="w-3 h-3"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>
            </a>
          </div>
        )}

        {/* Reasoning */}
        {reasoning && (
          <div className="px-4 pb-4">
            <div className="text-xs text-gray mb-1 uppercase tracking-wider">
              Reasoning
            </div>
            <p className="text-xs italic text-gray/80 font-mono leading-relaxed">
              {reasoning}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
