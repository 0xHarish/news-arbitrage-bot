import crypto from "crypto";

const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET ?? "";

/**
 * Validate an admin JWT token using timing-safe comparison.
 * Returns true if the token has a valid signature, false otherwise.
 */
export function validateAdminToken(token: string): boolean {
  try {
    if (!ADMIN_JWT_SECRET) return false;

    const parts = token.split(".");
    if (parts.length !== 3) return false;

    const [header, payload, signature] = parts;

    // Compute expected signature
    const expectedSig = crypto
      .createHmac("sha256", ADMIN_JWT_SECRET)
      .update(`${header}.${payload}`)
      .digest("base64url");

    // Use timing-safe comparison to prevent timing attacks
    const sigBuffer = Buffer.from(signature, "base64url");
    const expectedBuffer = Buffer.from(expectedSig, "base64url");

    if (sigBuffer.length !== expectedBuffer.length) return false;

    return crypto.timingSafeEqual(sigBuffer, expectedBuffer);
  } catch {
    return false;
  }
}
