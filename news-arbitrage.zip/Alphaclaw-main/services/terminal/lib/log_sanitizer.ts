/**
 * Sanitize headers for logging — redact sensitive values.
 * Case-insensitive matching per spec §17.6.
 */

const SENSITIVE_HEADERS = new Set([
  "authorization",
  "x-admin-token",
  "cookie",
]);

export function sanitizeHeaders(
  headers: Record<string, string>
): Record<string, string> {
  const sanitized: Record<string, string> = {};

  for (const [key, value] of Object.entries(headers)) {
    if (SENSITIVE_HEADERS.has(key.toLowerCase())) {
      sanitized[key] = "[REDACTED]";
    } else {
      sanitized[key] = value;
    }
  }

  return sanitized;
}
