export function getWsUrl(feed: 'public' | 'raw'): string {
  const base = process.env.NEXT_PUBLIC_WS_URL
  if (base) {
    const safeBase =
      typeof window !== 'undefined' && window.location.protocol === 'https:'
        ? base.replace(/^ws:\/\//, 'wss://')
        : base
    return `${safeBase}?feed=${feed}`
  }
  const protocol =
    typeof window !== 'undefined' && window.location.protocol === 'https:'
      ? 'wss:'
      : 'ws:'
  return `${protocol}//${window.location.host}/api/ws?feed=${feed}`
}
