"""
Shadow Price Tracker — polls shadow_trades rows and fills in price checkpoints,
MFE/MAE excursions, and market resolution data.
"""

import asyncio
import logging
from datetime import datetime, timezone

import httpx

from app.config import settings
from app.db import get_pool

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Checkpoint intervals
# ---------------------------------------------------------------------------
_15M = 15 * 60          # seconds
_1H = 60 * 60
_24H = 24 * 60 * 60


# ---------------------------------------------------------------------------
# Polymarket CLOB helpers
# ---------------------------------------------------------------------------

async def fetch_mid_price(market_id: str) -> float | None:
    """
    GET {CLOB_BASE_URL}/midpoint?token_id={market_id}
    Returns the mid-price as a float, or None on any error.

    NOTE: market_id must be a decimal CLOB token_id
    (e.g. "16244226514787692625509418115934807606115354849618134222354736093244725545119"),
    NOT the hex condition_id. The /midpoint endpoint returns 404 for condition_ids.
    """
    url = f"{settings.POLYMARKET_CLOB_BASE_URL}/midpoint"
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url, params={"token_id": market_id})
            resp.raise_for_status()
            data = resp.json()
            mid = data.get("mid")
            if mid is None:
                logger.warning("fetch_mid_price: no 'mid' key in response for market %s", market_id)
                return None
            return float(mid)
    except Exception as exc:
        logger.error("fetch_mid_price error for market %s: %s", market_id, exc)
        return None


async def fetch_market_resolution(market_id: str) -> dict:
    """
    GET {CLOB_BASE_URL}/markets/{market_id}
    Returns dict with resolved status, settlement_price, and resolved_at.
    """
    url = f"{settings.POLYMARKET_CLOB_BASE_URL}/markets/{market_id}"
    _default = {"resolved": False, "settlement_price": None, "resolved_at": None}
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            data = resp.json()
            resolved = bool(data.get("closed", False) or data.get("resolved", False))
            settlement_price_raw = data.get("settlement_price") or data.get("clearing_price")
            settlement_price = float(settlement_price_raw) if settlement_price_raw is not None else None
            resolved_at = data.get("resolved_at") or data.get("end_date_iso") or None
            return {
                "resolved": resolved,
                "settlement_price": settlement_price,
                "resolved_at": resolved_at,
            }
    except Exception as exc:
        logger.error("fetch_market_resolution error for market %s: %s", market_id, exc)
        return _default


# ---------------------------------------------------------------------------
# Row processor
# ---------------------------------------------------------------------------

async def process_shadow_row(row) -> None:
    """
    Fill price checkpoints, MFE/MAE, and resolution data for a single
    shadow_trades row.
    """
    now = datetime.now(timezone.utc)

    created_at = row["created_at"]
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)

    elapsed = (now - created_at).total_seconds()

    market_id = row["market_id"]
    clob_token_id = row.get("clob_token_id") or market_id  # fallback for legacy rows
    side = row["side"]
    entry_price = row["entry_price"]
    row_id = row["id"]

    price_15m = row["price_15m"]
    price_1h = row["price_1h"]
    price_24h = row["price_24h"]
    max_favorable = row["max_favorable"]
    max_adverse = row["max_adverse"]

    pool = await get_pool()
    any_update = False

    # ------------------------------------------------------------------
    # 15-minute checkpoint
    # ------------------------------------------------------------------
    if elapsed >= _15M and price_15m is None:
        mid = await fetch_mid_price(clob_token_id)
        if mid is not None:
            await pool.execute(
                "UPDATE shadow_trades SET price_15m = $1 WHERE id = $2",
                mid, row_id,
            )
            price_15m = mid
            any_update = True
            logger.debug("shadow %s: set price_15m=%.4f", row_id, mid)

    # ------------------------------------------------------------------
    # 1-hour checkpoint
    # ------------------------------------------------------------------
    if elapsed >= _1H and price_1h is None:
        mid = await fetch_mid_price(clob_token_id)
        if mid is not None:
            await pool.execute(
                "UPDATE shadow_trades SET price_1h = $1 WHERE id = $2",
                mid, row_id,
            )
            price_1h = mid
            any_update = True
            logger.debug("shadow %s: set price_1h=%.4f", row_id, mid)

    # ------------------------------------------------------------------
    # 24-hour checkpoint / resolution
    # ------------------------------------------------------------------
    if price_24h is None:
        resolution = await fetch_market_resolution(market_id)

        if resolution["resolved"] and resolution["settlement_price"] is not None:
            s_price = resolution["settlement_price"]
            s_time = resolution["resolved_at"]
            resolved_before_24h = elapsed < _24H

            await pool.execute(
                """
                UPDATE shadow_trades
                   SET price_24h            = $1,
                       price_24h_basis      = 'settlement',
                       resolved_before_24h  = $2,
                       resolved_at          = $3,
                       resolved_price       = $4
                 WHERE id = $5
                """,
                s_price, resolved_before_24h, s_time, s_price, row_id,
            )
            price_24h = s_price
            any_update = True
            logger.info(
                "shadow %s: market resolved (settlement=%.4f, before_24h=%s)",
                row_id, s_price, resolved_before_24h,
            )

        elif elapsed >= _24H:
            mid = await fetch_mid_price(clob_token_id)
            if mid is not None:
                await pool.execute(
                    """
                    UPDATE shadow_trades
                       SET price_24h           = $1,
                           price_24h_basis     = 'midprice',
                           resolved_before_24h = false
                     WHERE id = $2
                    """,
                    mid, row_id,
                )
                price_24h = mid
                any_update = True
                logger.debug("shadow %s: set price_24h=%.4f (midprice)", row_id, mid)

    # ------------------------------------------------------------------
    # MFE / MAE — only while the trade is still live (< 24h, not resolved)
    # ------------------------------------------------------------------
    if price_24h is None and elapsed < _24H:
        mid = await fetch_mid_price(clob_token_id)
        if mid is not None:
            if side == "YES":
                favorable_excursion = mid - entry_price
                adverse_excursion = entry_price - mid
            else:
                favorable_excursion = entry_price - mid
                adverse_excursion = mid - entry_price

            new_max_favorable = max(max_favorable or 0.0, favorable_excursion)
            new_max_adverse = max(max_adverse or 0.0, adverse_excursion)

            await pool.execute(
                """
                UPDATE shadow_trades
                   SET max_favorable = $1,
                       max_adverse   = $2
                 WHERE id = $3
                """,
                new_max_favorable, new_max_adverse, row_id,
            )
            any_update = True
            logger.debug(
                "shadow %s: MFE=%.4f MAE=%.4f", row_id, new_max_favorable, new_max_adverse
            )

    # ------------------------------------------------------------------
    # tracking_status transitions
    # ------------------------------------------------------------------
    all_checkpoints_filled = (
        price_15m is not None
        and price_1h is not None
        and price_24h is not None
    )

    if all_checkpoints_filled:
        await pool.execute(
            "UPDATE shadow_trades SET tracking_status = 'COMPLETE' WHERE id = $1",
            row_id,
        )
        logger.info("shadow %s: tracking_status -> COMPLETE", row_id)
    elif any_update and row["tracking_status"] == "PENDING":
        await pool.execute(
            "UPDATE shadow_trades SET tracking_status = 'TRACKING' WHERE id = $1",
            row_id,
        )
        logger.info("shadow %s: tracking_status -> TRACKING", row_id)


# ---------------------------------------------------------------------------
# Main polling loop
# ---------------------------------------------------------------------------

async def track_shadow_trades() -> None:
    """
    Async loop that runs forever, polling every 60 seconds.
    Queries all non-COMPLETE shadow_trades rows and processes each one.
    """
    logger.info("Shadow price tracker started (60-second poll interval)")
    while True:
        try:
            pool = await get_pool()
            rows = await pool.fetch(
                """
                SELECT * FROM shadow_trades
                 WHERE tracking_status != 'COMPLETE'
                 ORDER BY created_at ASC
                """
            )
            logger.debug("Shadow tracker: processing %d active rows", len(rows))
            for row in rows:
                try:
                    await process_shadow_row(row)
                except Exception as row_exc:
                    logger.error(
                        "Shadow tracker: error processing row %s: %s",
                        row["id"], row_exc,
                        exc_info=True,
                    )
        except Exception as exc:
            logger.error("Shadow tracker: cycle error: %s", exc, exc_info=True)

        await asyncio.sleep(60)
