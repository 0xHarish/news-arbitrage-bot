import json
import logging
import uuid
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("alphaclaw.publisher")


async def publish_trade_signal(
    signal_id: str,
    verdict_id: str,
    market_id: str,
    side: str,
    composite_p: float,
    kelly_fraction: float,
    position_usdc: float,
    wallet_exposure: float,
    market_price: float,
    reasoning_summary: str,
    source_url: str = "",
    expires_in_seconds: int = 900,
    clob_token_id: str = "",
) -> str | None:
    """
    Publish a trade signal to Redis and persist to DB.

    IMPORTANT: DB write happens FIRST, then Redis publish.
    This ordering mitigates risk R-06 (Redis message loss) —
    if Redis fails after DB write, the broker can re-query on reconnect.

    Returns the trade_signal UUID on success, None on failure.
    """
    from app.db import get_pool
    from app.redis_client import get_redis

    now = datetime.now(timezone.utc)
    expires_at = datetime.fromtimestamp(
        now.timestamp() + expires_in_seconds, tz=timezone.utc
    ).isoformat()

    # Step 1: Write to DB FIRST
    trade_signal_id = None
    try:
        pool = await get_pool()
        row = await pool.fetchrow(
            """
            INSERT INTO trade_signals (
                signal_id, verdict_id, market_id, side,
                composite_p, kelly_fraction, position_usdc, wallet_exposure
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
            """,
            uuid.UUID(signal_id) if signal_id else None,
            uuid.UUID(verdict_id) if verdict_id else None,
            market_id,
            side,
            composite_p,
            kelly_fraction,
            position_usdc,
            wallet_exposure,
        )
        trade_signal_id = str(row["id"]) if row else None
    except Exception as e:
        logger.error(f"Failed to write trade_signal to DB: {e}")
        return None

    # Step 2: Publish to Redis
    message = {
        "schema_version": "1.0",
        "event": "TRADE_SIGNAL",
        "signal_id": signal_id,
        "verdict_id": verdict_id,
        "trade_signal_id": trade_signal_id,
        "market_id": market_id,
        "side": side,
        "composite_p": composite_p,
        "kelly_fraction": kelly_fraction,
        "position_usdc": position_usdc,
        "wallet_exposure": wallet_exposure,
        "market_price_at_signal": market_price,
        "reasoning_summary": reasoning_summary,
        "primary_source_url": source_url,
        "clob_token_id": clob_token_id,
        "expires_at": expires_at,
        "timestamp": now.isoformat(),
    }

    try:
        redis = await get_redis()
        await redis.publish("trade_signals", json.dumps(message))
        logger.info(f"Published trade signal: market={market_id}, side={side}, ${position_usdc}")
    except Exception as e:
        logger.error(f"Failed to publish trade_signal to Redis: {e}")
        # DB write succeeded — broker can still pick this up on reconnect

    return trade_signal_id


async def publish_neural_trace_raw(event_type: str, payload: dict) -> None:
    """
    Publish full internal reasoning trace to neural_trace_raw.

    Also appends to Redis list neural_trace_raw:history (LPUSH + LTRIM 500).
    """
    from app.redis_client import get_redis

    message = {
        "schema_version": "1.0",
        "event_type": event_type,
        "event_id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "payload": payload,
    }

    try:
        redis = await get_redis()
        msg_str = json.dumps(message)
        await redis.publish("neural_trace_raw", msg_str)
        await redis.lpush("neural_trace_raw:history", msg_str)
        await redis.ltrim("neural_trace_raw:history", 0, 499)
    except Exception as e:
        logger.error(f"Failed to publish neural_trace_raw: {e}")


async def publish_neural_trace_public(event_type: str, payload: dict) -> None:
    """
    Publish sanitized event to neural_trace_public.

    Removes: raw_text, internal scores, opus raw reasoning.
    Also appends to Redis list neural_trace_public:history (LPUSH + LTRIM 100).

    Event type mapping:
    - HUNT   — Signal detected and being evaluated
    - STRIKE — Trade executed
    - PASS   — Signal evaluated, no trade
    - SHIELD — Signal dropped by circuit breaker or oracle dispute
    """
    from app.redis_client import get_redis

    # Sanitize payload — remove sensitive fields
    sanitized = {k: v for k, v in payload.items() if k not in {
        "raw_text", "canonical_tokens", "opus_raw_reasoning",
        "fast_match_score", "opus_confidence", "signal_id", "verdict_id",
    }}

    message = {
        "schema_version": "1.0",
        "event_type": event_type,
        "event_id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "payload": sanitized,
    }

    try:
        redis = await get_redis()
        msg_str = json.dumps(message)
        await redis.publish("neural_trace_public", msg_str)
        await redis.lpush("neural_trace_public:history", msg_str)
        await redis.ltrim("neural_trace_public:history", 0, 99)
    except Exception as e:
        logger.error(f"Failed to publish neural_trace_public: {e}")


async def publish_drop_event(
    market_title: str,
    drop_reason: str,
    source_handle: str = "",
    source_url: str = "",
) -> None:
    """
    Publish a drop event as PASS or SHIELD to public channel.

    SHIELD if dropped by circuit breaker or oracle dispute.
    PASS if dropped by confidence/ambiguity checks.
    """
    shield_reasons = {"active_oracle_dispute", "circuit_breaker", "DAILY_LOSS_LIMIT"}
    event_type = "SHIELD" if any(r in drop_reason for r in shield_reasons) else "PASS"

    await publish_neural_trace_raw("SIGNAL_DROPPED", {
        "market_title": market_title,
        "drop_reason": drop_reason,
        "source_handle": source_handle,
    })

    await publish_neural_trace_public(event_type, {
        "market_title": market_title,
        "action": f"DROPPED: {drop_reason}",
        "reasoning_summary": f"Signal dropped: {drop_reason}",
        "source_url": source_url,
        "confidence_label": "N/A",
    })
