"""
AlphaClaw Price Anomaly Engine

Detects statistically abnormal price moves via rolling z-score analysis
on Polymarket WebSocket ticks. Triggers mean-reversion scalp opportunities.

Phase A: detect + log only (no trades published to Broker)
Phase B: additionally publish trade signals to Redis for shadow execution
Phase C: publish to Redis AND execute live trades on Polymarket CLOB
"""

import asyncio
import json
import logging
import math
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path

import httpx

from app.config import settings
from app.fastmatch.zscore import RollingZScore

logger = logging.getLogger("alphaclaw.anomaly")


@dataclass
class AnomalyMarketState:
    """Per-market rolling statistics for anomaly detection."""

    zscore_calc: RollingZScore
    clob_token_yes: str | None = None
    clob_token_no: str | None = None
    best_bid: float | None = None
    best_ask: float | None = None
    last_detection_at: float = 0.0  # monotonic time for cooldown
    volume_24h: float = 0.0
    orderbook_depth: float = 0.0


class AnomalyEngine:
    """
    Fast mean-reversion scalp detector.

    Monitors per-market rolling z-scores and triggers anomaly detections
    when statistical thresholds are exceeded. Phase A logs detections to
    the anomaly_detections table and publishes HUNT neural trace events.
    Phase B additionally publishes trade signals to Redis.
    """

    def __init__(self, schemas_dir: str):
        self._markets: dict[str, AnomalyMarketState] = {}
        self._schemas_dir = schemas_dir
        self._rest_task: asyncio.Task | None = None
        self._stats_task: asyncio.Task | None = None
        self._load_markets()

        # Diagnostic counters — reset every stats dump
        self._diag = {
            "ticks_received": 0,
            "drop_disabled": 0,
            "drop_unknown_market": 0,
            "drop_price_range": 0,
            "drop_warmup": 0,
            "drop_stats_failed": 0,
            "drop_zscore_below": 0,
            "drop_delta_below": 0,
            "drop_missing_bid_ask": 0,
            "drop_spread_wide": 0,
            "drop_volume_missing": 0,
            "drop_depth_missing": 0,
            "drop_cooldown": 0,
            "detections": 0,
        }
        self._max_abs_z: float = 0.0
        self._sum_abs_z: float = 0.0
        self._z_count: int = 0
        # Seed so the first dump fires within 30s instead of a full interval
        self._last_stats_dump: float = time.monotonic() - max(0, settings.ANOMALY_STATS_INTERVAL_SECONDS - 30)

    def _load_markets(self):
        """Load tracked markets from resolution schemas."""
        schemas_path = Path(self._schemas_dir)
        if not schemas_path.exists():
            logger.warning(f"Anomaly: schemas dir not found: {self._schemas_dir}")
            return

        for schema_file in sorted(schemas_path.glob("*.json")):
            try:
                with open(schema_file) as f:
                    schema = json.load(f)
                market_id = schema.get("condition_id") or schema.get("market_id")
                if not market_id:
                    continue

                clob_tokens = schema.get("clob_tokens", {})
                state = AnomalyMarketState(
                    zscore_calc=RollingZScore(window=settings.ANOMALY_Z_WINDOW),
                    clob_token_yes=clob_tokens.get("YES"),
                    clob_token_no=clob_tokens.get("NO"),
                )
                self._markets[market_id] = state
            except (json.JSONDecodeError, OSError) as e:
                logger.error(f"Anomaly: failed to load schema {schema_file}: {e}")

        logger.info(f"Anomaly engine: tracking {len(self._markets)} markets")
        logger.info(
            f"ANOMALY INIT: markets={len(self._markets)} "
            f"z_window={settings.ANOMALY_Z_WINDOW} z_threshold={settings.ANOMALY_Z_THRESHOLD} "
            f"min_delta={settings.ANOMALY_MIN_PRICE_DELTA} max_spread={settings.ANOMALY_MAX_SPREAD} "
            f"cooldown={settings.ANOMALY_COOLDOWN_SECONDS}s "
            f"require_volume={settings.ANOMALY_REQUIRE_VOLUME} "
            f"require_depth={settings.ANOMALY_REQUIRE_DEPTH} phase={settings.ANOMALY_PHASE} "
            f"price_range=[{settings.ANOMALY_PRICE_MIN}, {settings.ANOMALY_PRICE_MAX}]"
        )
        logger.info(
            f"ANOMALY ALIVE: engine initialized, enabled={settings.ANOMALY_ENABLED}, "
            f"phase={settings.ANOMALY_PHASE}, markets={len(self._markets)}, "
            f"stats_interval={settings.ANOMALY_STATS_INTERVAL_SECONDS}s"
        )

    def _maybe_dump_stats(self):
        """Periodically log a one-line diagnostic summary."""
        now = time.monotonic()
        elapsed = now - self._last_stats_dump
        if elapsed < settings.ANOMALY_STATS_INTERVAL_SECONDS:
            return

        total = len(self._markets)
        warmed = sum(1 for s in self._markets.values() if s.zscore_calc.is_warmed)
        avg_z = (self._sum_abs_z / self._z_count) if self._z_count > 0 else 0.0

        logger.info(
            f"ANOMALY STATS ({elapsed:.0f}s): "
            f"ticks={self._diag['ticks_received']} markets={total} warmed={warmed}/{total}, "
            f"max_z={self._max_abs_z:.3f} avg_z={avg_z:.3f}, "
            f"detections={self._diag['detections']}, "
            f"drops=[price_range={self._diag['drop_price_range']} warmup={self._diag['drop_warmup']} stats_failed={self._diag['drop_stats_failed']} "
            f"zscore={self._diag['drop_zscore_below']} "
            f"delta={self._diag['drop_delta_below']} spread={self._diag['drop_spread_wide']} "
            f"bid_ask={self._diag['drop_missing_bid_ask']} cooldown={self._diag['drop_cooldown']}]"
        )

        # Reset counters
        for k in self._diag:
            self._diag[k] = 0
        self._max_abs_z = 0.0
        self._sum_abs_z = 0.0
        self._z_count = 0
        self._last_stats_dump = now

    async def on_tick(
        self,
        market_id: str,
        price: float,
        best_bid: float | None,
        best_ask: float | None,
    ):
        """
        Called from polymarket_ws._process_tick on every price update.

        Updates rolling z-score and checks trigger conditions for anomaly
        detection. Does not block the narrative pipeline.
        """
        self._maybe_dump_stats()
        self._diag["ticks_received"] += 1

        if not settings.ANOMALY_ENABLED:
            self._diag["drop_disabled"] += 1
            logger.debug("tick dropped — engine disabled")
            return

        state = self._markets.get(market_id)
        if state is None:
            self._diag["drop_unknown_market"] += 1
            logger.debug(f"tick dropped — unknown market {market_id[:16]}...")
            return

        # Filter out nearly-resolved markets (price outside tradeable range)
        if price < settings.ANOMALY_PRICE_MIN or price > settings.ANOMALY_PRICE_MAX:
            self._diag["drop_price_range"] += 1
            logger.debug(
                f"ANOMALY DROP: reason=price_out_of_range market={market_id} price={price}"
            )
            return

        # Update bid/ask cache
        if best_bid is not None:
            state.best_bid = best_bid
        if best_ask is not None:
            state.best_ask = best_ask

        # Update rolling z-score
        zscore = state.zscore_calc.update(price)

        # Need a filled window to detect anomalies
        if not state.zscore_calc.is_warmed:
            self._diag["drop_warmup"] += 1
            logger.debug(
                f"warmup {market_id[:16]}... ({state.zscore_calc.fill_count}/{state.zscore_calc.window})"
            )
            return

        # Track z-score statistics for warmed markets
        abs_z = abs(zscore)
        self._sum_abs_z += abs_z
        self._z_count += 1
        if abs_z > self._max_abs_z:
            self._max_abs_z = abs_z
            logger.debug(
                f"NEW_MAX_Z: market={market_id[:16]} z={zscore:.4f} abs_z={abs_z:.4f} price={price:.6f}"
            )

        # Compute mean and price delta from rolling window
        stats = self._get_rolling_stats(state.zscore_calc)
        if stats is None:
            self._diag["drop_stats_failed"] += 1
            logger.debug(f"stats failed (zero variance) for {market_id[:16]}...")
            return
        mean, std = stats

        price_delta = abs(price - mean)

        # --- Trigger check ---
        if abs(zscore) < settings.ANOMALY_Z_THRESHOLD:
            self._diag["drop_zscore_below"] += 1
            logger.debug(
                f"ZSCORE_DROP: market={market_id[:16]} z={zscore:.4f} abs_z={abs_z:.4f} "
                f"threshold={settings.ANOMALY_Z_THRESHOLD} price={price:.6f} mean={mean:.6f} std={std:.6f}"
            )
            return
        logger.info(
            f"ZSCORE_PASS: market={market_id[:16]} z={zscore:.4f} abs_z={abs_z:.4f} "
            f"threshold={settings.ANOMALY_Z_THRESHOLD} price={price:.6f} delta={price_delta:.6f}"
        )

        if price_delta < settings.ANOMALY_MIN_PRICE_DELTA:
            self._diag["drop_delta_below"] += 1
            logger.debug(
                f"delta={price_delta:.4f} < {settings.ANOMALY_MIN_PRICE_DELTA} for {market_id[:16]}... "
                f"(z={zscore:.3f} PASSED)"
            )
            return

        self._diag["detections"] += 1

        # --- Cooldown check ---
        now = time.monotonic()
        cooldown_active = (now - state.last_detection_at) < settings.ANOMALY_COOLDOWN_SECONDS

        # --- Liquidity checks ---
        spread_pct = None
        would_trade = True

        if state.best_bid is not None and state.best_ask is not None and state.best_ask > 0:
            spread_pct = (state.best_ask - state.best_bid) / state.best_ask
            if spread_pct > settings.ANOMALY_MAX_SPREAD:
                would_trade = False
                logger.debug(f"ANOMALY DROP: reason=spread_too_wide market={market_id[:16]} spread={spread_pct:.4f}")
                self._diag["drop_spread_wide"] += 1
        else:
            would_trade = False  # No bid/ask data
            logger.debug(f"ANOMALY DROP: reason=missing_bid_ask market={market_id[:16]}")
            self._diag["drop_missing_bid_ask"] += 1

        if settings.ANOMALY_REQUIRE_VOLUME and state.volume_24h < settings.ANOMALY_MIN_VOLUME_24H:
            would_trade = False
            logger.debug(f"ANOMALY DROP: reason=volume_below_min market={market_id[:16]} vol={state.volume_24h}")
            self._diag["drop_volume_missing"] += 1
        if settings.ANOMALY_REQUIRE_DEPTH and state.orderbook_depth < settings.ANOMALY_MIN_DEPTH:
            would_trade = False
            logger.debug(f"ANOMALY DROP: reason=depth_below_min market={market_id[:16]} depth={state.orderbook_depth}")
            self._diag["drop_depth_missing"] += 1

        if cooldown_active:
            would_trade = False
            logger.debug(f"ANOMALY DROP: reason=cooldown_active market={market_id[:16]}")
            self._diag["drop_cooldown"] += 1

        # --- Direction ---
        # z > 0 = price above mean → expect reversion down → buy NO
        # z < 0 = price below mean → expect reversion up → buy YES
        side = "NO" if zscore > 0 else "YES"

        # --- Position sizing ---
        position_usdc = settings.ANOMALY_WALLET_EXPOSURE * 1000.0  # fixed fraction

        # --- Limit price ---
        if state.best_bid is not None and state.best_ask is not None:
            mid = (state.best_bid + state.best_ask) / 2.0
        else:
            mid = price
        limit_price = (
            mid - settings.ANOMALY_LIMIT_OFFSET
            if side == "YES"
            else mid + settings.ANOMALY_LIMIT_OFFSET
        )

        # Resolve CLOB token for the chosen side
        clob_token_id = state.clob_token_yes if side == "YES" else state.clob_token_no

        # Update cooldown only for tradeable detections
        if would_trade:
            state.last_detection_at = now

        # Log detection
        logger.info(
            f"ANOMALY {'TRADE' if would_trade else 'DETECT'}: "
            f"market={market_id} side={side} z={zscore:.2f} "
            f"delta={price_delta:.4f} spread={f'{spread_pct:.4f}' if spread_pct is not None else 'N/A'} "
            f"would_trade={would_trade}"
        )

        # Write to DB
        await self._write_detection(
            market_id=market_id,
            clob_token_id=clob_token_id,
            side=side,
            zscore=zscore,
            price=price,
            price_delta=price_delta,
            mean=mean,
            std=std,
            limit_price=limit_price,
            position_usdc=position_usdc,
            best_bid=state.best_bid,
            best_ask=state.best_ask,
            spread_pct=spread_pct,
            cooldown_active=cooldown_active,
            would_trade=would_trade,
        )

        # Publish neural trace HUNT event
        await self._publish_hunt_event(
            market_id=market_id,
            side=side,
            zscore=zscore,
            price=price,
            price_delta=price_delta,
            would_trade=would_trade,
        )

        # Phase B/C: publish trade signal to Redis → Broker
        if would_trade and settings.ANOMALY_PHASE in ("B", "C"):
            await self._publish_trade_signal(
                market_id=market_id,
                clob_token_id=clob_token_id or "",
                side=side,
                zscore=zscore,
                price=price,
                limit_price=limit_price,
                position_usdc=position_usdc,
            )

        # Phase C: execute live trade on Polymarket CLOB
        if would_trade and settings.ANOMALY_PHASE == "C":
            from app.execution.live_executor import execute_live_trade

            trade_result = await execute_live_trade({
                "market_id": market_id,
                "clob_token_id": clob_token_id or "",
                "side": side,
                "zscore": zscore,
                "price": price,
                "limit_price": limit_price,
                "position_usdc": position_usdc,
            })
            if trade_result:
                logger.info(
                    f"PHASE_C EXECUTED: order_id={trade_result['order_id']} "
                    f"status={trade_result['status']} "
                    f"limit_price={trade_result['limit_price']:.6f} "
                    f"size={trade_result['size']:.4f} market={market_id}"
                )
            else:
                logger.warning(f"PHASE_C SKIPPED: no trade executed for market={market_id}")

    def reset_all(self):
        """Reset all z-score calculators. Called on WS reconnect."""
        for state in self._markets.values():
            state.zscore_calc.reset()
        logger.info("Anomaly engine: all z-score calculators reset")

    @property
    def market_count(self) -> int:
        """Number of markets being tracked for anomalies."""
        return len(self._markets)

    async def start_rest_polling(self):
        """Start background REST API polling for volume/depth data."""
        self._rest_task = asyncio.create_task(self._rest_poll_loop())

    async def start_stats_loop(self):
        """Start background periodic stats dump (runs even with zero ticks)."""
        self._stats_task = asyncio.create_task(self._stats_dump_loop())

    async def stop(self):
        """Stop all background tasks (REST polling + stats dump)."""
        for task in (self._rest_task, self._stats_task):
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        self._rest_task = None
        self._stats_task = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _get_rolling_stats(zs: RollingZScore) -> tuple[float, float] | None:
        """Extract mean and std from a RollingZScore's window."""
        if len(zs._values) < zs.window:
            return None
        n = len(zs._values)
        mean = sum(zs._values) / n
        variance = sum((v - mean) ** 2 for v in zs._values) / n
        if variance <= 0:
            return None
        return (mean, math.sqrt(variance))

    async def _write_detection(self, **kwargs):
        """Persist anomaly detection to anomaly_detections table."""
        try:
            from app.db import get_pool

            pool = await get_pool()
            await pool.execute(
                """
                INSERT INTO anomaly_detections (
                    market_id, clob_token_id, side, zscore, price, price_delta,
                    mean, std, limit_price, position_usdc, best_bid, best_ask,
                    spread_pct, cooldown_active, would_trade, phase
                ) VALUES (
                    $1, $2, $3, $4, $5, $6,
                    $7, $8, $9, $10, $11, $12,
                    $13, $14, $15, $16
                )
                """,
                kwargs["market_id"],
                kwargs.get("clob_token_id"),
                kwargs["side"],
                kwargs["zscore"],
                kwargs["price"],
                kwargs["price_delta"],
                kwargs["mean"],
                kwargs["std"],
                kwargs.get("limit_price"),
                kwargs.get("position_usdc"),
                kwargs.get("best_bid"),
                kwargs.get("best_ask"),
                kwargs.get("spread_pct"),
                kwargs.get("cooldown_active", False),
                kwargs.get("would_trade", False),
                settings.ANOMALY_PHASE,
            )
        except Exception as e:
            logger.warning(
                f"Anomaly: failed to write detection to DB "
                f"(market={kwargs.get('market_id', '?')}): {e}\n"
                f"{traceback.format_exc()}"
            )

    async def _publish_hunt_event(self, **kwargs):
        """Publish HUNT neural trace event for Terminal display."""
        from app.publisher.redis_pub import (
            publish_neural_trace_public,
            publish_neural_trace_raw,
        )

        trade_label = "TRADE" if kwargs["would_trade"] else "DETECT"
        await publish_neural_trace_public("HUNT", {
            "market_title": kwargs["market_id"],
            "source_handle": "anomaly_engine",
            "source_tier": 0,
            "action": (
                f"ANOMALY {trade_label}: {kwargs['side']} "
                f"z={kwargs['zscore']:.2f}"
            ),
            "reasoning_summary": (
                f"Price anomaly z={kwargs['zscore']:.2f} "
                f"delta={kwargs['price_delta']:.4f}"
            ),
        })

        await publish_neural_trace_raw("ANOMALY_DETECTION", {
            "market_id": kwargs["market_id"],
            "side": kwargs["side"],
            "zscore": kwargs["zscore"],
            "price": kwargs["price"],
            "price_delta": kwargs["price_delta"],
            "would_trade": kwargs["would_trade"],
        })

    async def _publish_trade_signal(self, **kwargs):
        """Phase B: publish anomaly trade signal to Redis → Broker."""
        from app.publisher.redis_pub import publish_trade_signal

        await publish_trade_signal(
            signal_id="",
            verdict_id="",
            market_id=kwargs["market_id"],
            side=kwargs["side"],
            composite_p=0.0,
            kelly_fraction=0.0,
            position_usdc=kwargs["position_usdc"],
            wallet_exposure=settings.ANOMALY_WALLET_EXPOSURE,
            market_price=kwargs["price"],
            reasoning_summary=f"Z-score reversion: z={kwargs['zscore']:.2f}",
            clob_token_id=kwargs["clob_token_id"],
            expires_in_seconds=settings.ANOMALY_EXPIRES_SECONDS,
        )

    # ------------------------------------------------------------------
    # Periodic stats dump (runs independently of ticks)
    # ------------------------------------------------------------------

    async def _stats_dump_loop(self):
        """Periodically dump stats even when no ticks are arriving."""
        logger.info("Anomaly stats dump loop started")
        while True:
            try:
                await asyncio.sleep(settings.ANOMALY_STATS_INTERVAL_SECONDS)
                self._maybe_dump_stats()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.error(f"Anomaly stats dump error: {e}")

    # ------------------------------------------------------------------
    # REST polling for volume / orderbook depth
    # ------------------------------------------------------------------

    async def _rest_poll_loop(self):
        """Periodically fetch volume and orderbook depth from CLOB REST API."""
        logger.info("Anomaly REST poller started (60s interval)")
        while True:
            try:
                await self._fetch_all_market_data()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.error(f"Anomaly REST poll error: {e}")
            await asyncio.sleep(60)

    async def _fetch_all_market_data(self):
        """Fetch volume/depth for all tracked markets from CLOB REST API."""
        base_url = settings.POLYMARKET_CLOB_BASE_URL

        async with httpx.AsyncClient(timeout=10.0) as client:
            for market_id, state in self._markets.items():
                token_id = state.clob_token_yes or state.clob_token_no
                if not token_id:
                    continue
                try:
                    # Fetch orderbook depth
                    resp = await client.get(
                        f"{base_url}/book",
                        params={"token_id": token_id},
                    )
                    if resp.status_code == 200:
                        data = resp.json()
                        bids = data.get("bids", [])
                        asks = data.get("asks", [])
                        bid_depth = sum(float(b.get("size", 0)) for b in bids)
                        ask_depth = sum(float(a.get("size", 0)) for a in asks)
                        state.orderbook_depth = bid_depth + ask_depth

                    # Fetch market data for volume
                    resp2 = await client.get(
                        f"{base_url}/markets/{market_id}",
                    )
                    if resp2.status_code == 200:
                        market_data = resp2.json()
                        raw_vol = (
                            market_data.get("volume_num_24hr")
                            or market_data.get("volume_24h")
                            or market_data.get("volume")
                        )
                        state.volume_24h = float(raw_vol or 0)
                        if state.volume_24h == 0:
                            # Log available keys so we can find the right field name
                            vol_keys = [k for k in market_data if "vol" in k.lower()]
                            logger.info(
                                f"Anomaly REST: vol=0 for {market_id[:16]}... "
                                f"status={resp2.status_code} vol_keys={vol_keys} "
                                f"response_keys={list(market_data.keys())[:15]}"
                            )
                    else:
                        logger.info(
                            f"Anomaly REST: /markets/{market_id[:16]}... "
                            f"returned status={resp2.status_code}"
                        )
                except Exception as e:
                    logger.info(f"Anomaly: REST fetch failed for {market_id[:16]}...: {e}")

                # Small delay between markets to avoid rate limiting
                await asyncio.sleep(0.5)

        vol_zero = sum(1 for s in self._markets.values() if s.volume_24h == 0)
        depth_zero = sum(1 for s in self._markets.values() if s.orderbook_depth == 0)
        logger.info(
            f"Anomaly REST poll: {len(self._markets)} markets, "
            f"vol_zero={vol_zero} depth_zero={depth_zero}"
        )
