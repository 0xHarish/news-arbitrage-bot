# Anomaly Engine — Price anomaly detection for mean-reversion scalps
