import logging
from app.config import settings

logger = logging.getLogger("alphaclaw.sizing")


def normalize_zscore(zscore: float) -> float:
    """
    Normalize z-score to 0.0-1.0 range.
    Formula: min(abs(zscore) / Z_SCORE_MAX, 1.0)
    """
    return min(abs(zscore) / settings.Z_SCORE_MAX, 1.0)


def calculate_composite_p(opus_confidence: float, zscore: float) -> float:
    """
    Calculate composite probability.
    Formula: (opus_confidence × W_OPUS) + (normalized_zscore × W_ZSCORE)

    W_OPUS = 0.75 (primary weight — legalistic reasoning)
    W_ZSCORE = 0.25 (secondary weight — market anomaly signal)
    """
    normalized_z = normalize_zscore(zscore)
    composite = (opus_confidence * settings.W_OPUS) + (normalized_z * settings.W_ZSCORE)
    return min(composite, 1.0)  # Cap at 1.0


def calculate_kelly_fraction(composite_p: float, market_price: float) -> float:
    """
    Calculate raw Kelly fraction.

    Formula: kelly = (p * b - (1 - p)) / b
    Where b = (1 / market_price) - 1 (net odds)

    Returns 0.0 if the bet is unprofitable (negative Kelly).
    """
    if market_price <= 0.0 or market_price >= 1.0:
        return 0.0

    b = (1.0 / market_price) - 1.0  # Net odds
    kelly = (composite_p * b - (1.0 - composite_p)) / b
    return max(0.0, kelly)  # Never negative


def calculate_position(
    composite_p: float,
    market_price: float,
    wallet_total_usdc: float,
) -> float:
    """
    Calculate position size in USDC with all safety caps applied.

    Pipeline:
    1. Check composite_p >= MIN_COMPOSITE_P (0.80) — else return 0.0
    2. Calculate Kelly fraction
    3. Apply fractional Kelly (quarter Kelly: × 0.25)
    4. Multiply by wallet total
    5. Cap at MAX_WALLET_EXPOSURE (5% of wallet)
    6. Floor at MIN_POSITION_USDC ($5.00) — if below floor, return 0.0 (avoid dust)
    7. Round to 2 decimal places

    Returns:
        Position size in USDC (2 decimals), or 0.0 if no trade
    """
    # Gate: minimum composite probability
    if composite_p < settings.MIN_COMPOSITE_P:
        return 0.0

    # Kelly fraction
    kelly_f = calculate_kelly_fraction(composite_p, market_price)
    if kelly_f <= 0.0:
        return 0.0

    # Fractional Kelly (quarter Kelly to reduce variance)
    fractional_kelly = kelly_f * settings.KELLY_FRACTION

    # Raw position
    raw_position = fractional_kelly * wallet_total_usdc

    # Hard cap: MAX_WALLET_EXPOSURE (5% of wallet)
    max_position = wallet_total_usdc * settings.MAX_WALLET_EXPOSURE
    capped_position = min(raw_position, max_position)

    # Floor: minimum position to avoid dust trades
    if capped_position < settings.MIN_POSITION_USDC:
        return 0.0

    return round(capped_position, 2)
