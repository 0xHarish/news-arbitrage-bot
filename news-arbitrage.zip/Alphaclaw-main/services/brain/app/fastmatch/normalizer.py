import re
import spacy
import nltk
from nltk.corpus import stopwords

# Load models (these are initialized once at module level)
nlp = spacy.load("en_core_web_sm", disable=["parser", "ner"])  # Only need lemmatizer

# Ensure NLTK data
nltk.download("stopwords", quiet=True)

# Financial stopwords that appear in every news headline but carry no signal
FINANCIAL_STOPWORDS = {
    "said", "according", "report", "told", "sources", "noted", "added",
    "reports", "says", "saying", "reported", "update", "breaking",
}

STOPWORDS = set(stopwords.words("english")) | FINANCIAL_STOPWORDS

# Regex patterns for stripping
URL_PATTERN = re.compile(r"https?://\S+|www\.\S+")
MENTION_PATTERN = re.compile(r"@\w+")
HASHTAG_PATTERN = re.compile(r"#\w+")
PUNCTUATION_PATTERN = re.compile(r"[^\w\s]")


def normalize(text: str) -> list[str]:
    """
    Normalize raw text into canonical tokens for Fast-Match lookup.

    Pipeline:
    1. Lowercase
    2. Strip URLs, mentions, hashtags
    3. Remove punctuation
    4. Tokenize on whitespace
    5. Remove stopwords (NLTK English + financial stopwords)
    6. Apply lemmatization (spaCy en_core_web_sm)
    7. Deduplicate token list (preserving order), re-filter stopwords post-lemma
    """
    if not text:
        return []

    # 1. Lowercase
    text = text.lower()

    # 2. Strip URLs, mentions, hashtags
    text = URL_PATTERN.sub("", text)
    text = MENTION_PATTERN.sub("", text)
    text = HASHTAG_PATTERN.sub("", text)

    # 3. Remove punctuation
    text = PUNCTUATION_PATTERN.sub(" ", text)

    # 4. Tokenize on whitespace
    tokens = text.split()

    # 5. Remove stopwords (pre-lemma pass to reduce spaCy workload)
    tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 1]

    # 6. Apply lemmatization via spaCy
    if tokens:
        doc = nlp(" ".join(tokens))
        tokens = [token.lemma_ for token in doc]

    # 7. Deduplicate while preserving order; re-filter stopwords post-lemma
    #    (lemmatization can reduce a non-stopword back to a stopword form)
    seen = set()
    result = []
    for token in tokens:
        if token not in seen and token not in STOPWORDS and len(token) > 1:
            seen.add(token)
            result.append(token)

    return result
