import json
import re
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger("alphaclaw.fastmatch")

TOKEN_ALIASES: dict[str, frozenset[str]] = {
    "fed": frozenset({"fed", "federal"}),
    "un":  frozenset({"un", "united"}),
}


@dataclass
class InboundSignal:
    """Signal from any ingestion tier"""
    source_tier: int              # 1=polymarket, 2=social, 3=hn, 4=perplexity
    source_handle: str
    source_domain: str
    raw_text: str
    market_id: Optional[str] = None
    zscore: Optional[float] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    url: Optional[str] = None
    trust_weight: float = 0.5


@dataclass
class FastMatchResult:
    """Output of the Fast-Match pipeline"""
    signal: InboundSignal
    canonical_tokens: list[str]
    matched_category_id: Optional[str] = None
    matched_market_id: Optional[str] = None
    fast_match_score: float = 0.0
    fast_match_hit: bool = False
    escalate_to_opus: bool = False
    drop_reason: Optional[str] = None
    matched_resolution_signals: list[str] = field(default_factory=list)
    matched_clob_token_yes: Optional[str] = None
    matched_clob_token_no: Optional[str] = None


class FastMatchEngine:
    def __init__(self, narrative_dict_path: str = None, resolution_schemas_dir: str = None):
        """
        Load narrative dictionary and all resolution schemas into memory.
        Called once at startup.
        """
        if narrative_dict_path is None:
            narrative_dict_path = str(
                Path(__file__).parent.parent.parent.parent.parent / "data" / "narrative_dict.json"
            )
        if resolution_schemas_dir is None:
            resolution_schemas_dir = str(
                Path(__file__).parent.parent.parent.parent.parent / "data" / "resolution_schemas"
            )

        # Load narrative dict
        with open(narrative_dict_path) as f:
            self._narrative_dict = json.load(f)

        # Load all resolution schemas
        self._resolution_schemas: dict[str, dict] = {}
        schemas_path = Path(resolution_schemas_dir)
        for schema_file in schemas_path.glob("*.json"):
            with open(schema_file) as f:
                schema = json.load(f)
                self._resolution_schemas[schema["condition_id"]] = schema

        # Build reverse index: market_tag -> category_id
        self._tag_to_categories: dict[str, list[str]] = {}
        for cat_id, cat in self._narrative_dict["categories"].items():
            for tag in cat.get("market_tags", []):
                self._tag_to_categories.setdefault(tag.lower(), []).append(cat_id)

        # Build reverse index: market_id -> resolution_schema
        self._market_to_schema: dict[str, dict] = {}
        for cid, schema in self._resolution_schemas.items():
            mid = schema.get("market_id", cid)
            self._market_to_schema[mid] = schema
            self._market_to_schema[cid] = schema

        logger.info(
            f"FastMatchEngine loaded: {len(self._narrative_dict['categories'])} categories, "
            f"{len(self._resolution_schemas)} resolution schemas"
        )

    async def process(self, signal: InboundSignal) -> FastMatchResult:
        """
        Run the 8-step Fast-Match pipeline on an inbound signal.

        Steps:
        1. Normalize text to canonical tokens
        2. Check for active oracle disputes
        3. Adversarial filter
        4. Token matching against resolution signals
        5. Source independence check
        6. Z-score gate (Tier 1 only)
        7. Golden window check
        8. Score aggregation + escalation decision
        """
        from app.fastmatch.normalizer import normalize
        from app.config import settings

        result = FastMatchResult(signal=signal, canonical_tokens=[])

        # Step 1: Normalize
        tokens = normalize(signal.raw_text)
        result.canonical_tokens = tokens

        if not tokens:
            result.drop_reason = "empty_after_normalization"
            return result

        # Match signal to category
        matched_category = self._match_category(tokens, signal)
        if not matched_category:
            result.drop_reason = "no_category_match"
            return result

        result.matched_category_id = matched_category["id"]
        category = matched_category

        # Try to match to a specific market
        matched_schema = self._match_market(tokens, category)
        if matched_schema:
            result.matched_market_id = matched_schema.get("condition_id")
            signal.market_id = result.matched_market_id
            clob_tokens = matched_schema.get("clob_tokens", {})
            result.matched_clob_token_yes = clob_tokens.get("YES")
            result.matched_clob_token_no = clob_tokens.get("NO")

        # Step 2: Oracle dispute check
        if result.matched_market_id:
            has_dispute = await self._check_oracle_dispute(result.matched_market_id)
            if has_dispute:
                result.drop_reason = "active_oracle_dispute"
                return result

        # Step 3: Adversarial filter
        adversarial_patterns = category.get("adversarial_patterns", [])
        raw_text_lower = signal.raw_text.lower()
        for pattern in adversarial_patterns:
            if pattern.lower() in raw_text_lower:
                result.drop_reason = f"adversarial_pattern:{pattern}"
                return result

        # Step 4: Token matching against resolution signals
        score, matched_signals = self._match_resolution_signals(tokens, category, signal.raw_text)
        result.fast_match_score = score
        result.matched_resolution_signals = matched_signals

        if score == 0.0:
            result.drop_reason = "no_resolution_signal_match"
            return result

        # Step 5: Source independence check
        # For a single signal, we count it as 1 source.
        # The engine should be called with accumulated source_domains from signal cluster.
        # For now, single signals pass if minimum_independent_sources <= 1
        min_sources = category.get("minimum_independent_sources", 2)
        # In production, this would check a signal cluster. For single signals, we check if
        # this signal alone meets the threshold (it won't for min >= 2, but that's correct —
        # the orchestrator batches signals before calling this)
        source_count = 1  # Single signal = 1 source
        if source_count < min_sources:
            # Don't drop — mark as needing more sources. The signal is still recorded.
            # In production the signal cluster manager handles accumulation.
            pass  # Source independence is checked at cluster level, not individual signal level

        # Step 6: Z-score gate (Tier 1 signals only)
        if signal.source_tier == 1:
            if signal.zscore is None or abs(signal.zscore) < settings.Z_SCORE_THRESHOLD:
                result.drop_reason = "zscore_below_threshold"
                return result

        # Step 7: Golden window check
        golden_window = category.get("golden_window_seconds", 900)
        now = datetime.now(timezone.utc)
        signal_age = (now - signal.timestamp.replace(tzinfo=timezone.utc)).total_seconds()
        if signal_age > golden_window:
            result.drop_reason = "outside_golden_window"
            return result

        # Step 8: Score aggregation + escalation
        result.fast_match_hit = score > 0

        if score >= settings.FAST_MATCH_ESCALATION_THRESHOLD:
            result.escalate_to_opus = True
        else:
            result.drop_reason = "score_below_escalation_threshold"

        return result

    def _match_category(self, tokens: list[str], signal: InboundSignal) -> dict | None:
        """Find the best matching category for the signal tokens."""
        best_category = None
        best_overlap = 0

        for cat_id, category in self._narrative_dict["categories"].items():
            market_tags = [t.lower() for t in category.get("market_tags", [])]
            overlap = len(set(tokens) & set(market_tags))
            if overlap > best_overlap:
                best_overlap = overlap
                best_category = category

        return best_category if best_overlap > 0 else None

    def _match_market(self, tokens: list[str], category: dict) -> dict | None:
        """Try to match tokens to a specific resolution schema within the category."""
        cat_id = category["id"]
        best_schema = None
        best_score = 0

        for cid, schema in self._resolution_schemas.items():
            if schema.get("category_id") != cat_id:
                continue
            # Check key entity name/alias overlap with tokens
            score = 0
            for entity in schema.get("key_entities", []):
                name_tokens = entity["name"].lower().split()
                if any(t in tokens for t in name_tokens):
                    score += 1
                for alias in entity.get("aliases", []):
                    if alias.lower() in tokens:
                        score += 1
            if score > best_score:
                best_score = score
                best_schema = schema

        return best_schema if best_score > 0 else None

    def _match_resolution_signals(
        self, tokens: list[str], category: dict, raw_text: str
    ) -> tuple[float, list[str]]:
        """
        Step 4: For each resolution_signal in the matched category:
        - Verify ALL canonical_tokens are present in the signal tokens
        - Verify at least ONE regex_pattern matches the raw text
        - Accumulate weighted score

        Returns (score, list_of_matched_signal_ids)
        """
        total_weight = 0.0
        matched_weight = 0.0
        matched_ids = []

        for res_signal in category.get("resolution_signals", []):
            weight = res_signal.get("weight", 0.5)
            total_weight += weight

            # Check ALL canonical tokens present
            canonical = res_signal.get("canonical_tokens", [])
            tokens_set = set(tokens)
            all_tokens_present = all(
                ct in tokens_set or bool(tokens_set & TOKEN_ALIASES.get(ct, frozenset()))
                for ct in canonical
            )

            if not all_tokens_present:
                continue

            # Check at least ONE regex matches
            regex_patterns = res_signal.get("regex_patterns", [])
            regex_match = False
            if not regex_patterns:
                # No regex required — token match alone suffices
                regex_match = True
            else:
                for pattern in regex_patterns:
                    try:
                        if re.search(pattern, raw_text, re.IGNORECASE):
                            regex_match = True
                            break
                    except re.error:
                        logger.warning(f"Invalid regex pattern: {pattern}")
                        continue

            if regex_match:
                matched_weight += weight
                matched_ids.append(res_signal.get("signal_id", "unknown"))

        # Score = accumulated matched weight, capped at 1.0
        # A single authoritative match (weight 1.0) should be sufficient
        # to escalate to Opus for deeper analysis
        score = min(matched_weight, 1.0)
        return score, matched_ids

    def get_resolution_schema(self, market_id: str) -> dict | None:
        """Look up a resolution schema by market_id or condition_id."""
        return self._market_to_schema.get(market_id)

    async def _check_oracle_dispute(self, market_id: str) -> bool:
        """Check TimescaleDB for active oracle disputes on this market."""
        try:
            from app.db import get_pool
            pool = await get_pool()
            row = await pool.fetchval(
                "SELECT EXISTS(SELECT 1 FROM oracle_disputes WHERE market_id = $1 AND dispute_status = 'ACTIVE')",
                market_id
            )
            return bool(row)
        except Exception as e:
            logger.error(f"Oracle dispute check failed: {e}")
            return False  # Fail open — don't block on DB errors

    async def write_signal_to_db(self, result: FastMatchResult) -> str | None:
        """Persist the signal to the signals table. Returns the signal UUID."""
        try:
            from app.db import get_pool
            import json as json_mod
            pool = await get_pool()
            row = await pool.fetchrow(
                """
                INSERT INTO signals (
                    source_tier, source_handle, raw_text, canonical_tokens,
                    market_id, zscore, fast_match_hit, fast_match_score,
                    escalated_to_opus, drop_reason
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                RETURNING id
                """,
                result.signal.source_tier,
                result.signal.source_handle,
                result.signal.raw_text,
                json_mod.dumps(result.canonical_tokens),
                result.matched_market_id,
                result.signal.zscore,
                result.fast_match_hit,
                result.fast_match_score,
                result.escalate_to_opus,
                result.drop_reason,
            )
            return str(row["id"]) if row else None
        except Exception as e:
            logger.error(f"Failed to write signal to DB: {e}")
            return None
