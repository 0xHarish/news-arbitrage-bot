import math
from collections import deque


class RollingZScore:
    """
    Rolling Z-score calculator using a sliding window.

    Maintains a sliding window of values and computes the z-score
    of each new value relative to the window's running mean and
    standard deviation.

    Uses a deque to maintain the window and computes population mean
    and variance directly from the stored values on each update.
    This is numerically stable for the default window size of 50 and
    avoids the complexity and error-prone nature of pure online
    sliding-window Welford removal.
    """

    def __init__(self, window: int = 50):
        self.window = window
        self._values: deque[float] = deque()

    def update(self, value: float) -> float:
        """
        Add a new value and return the z-score.

        The z-score measures how far the NEW value deviates from the
        PREVIOUS window's distribution (mean and std computed before
        the new value is added). This avoids the new value dampening
        its own anomaly signal.

        Returns 0.0 during warmup (fewer than `window` values have
        been observed) or if standard deviation is zero.
        """
        # Warmup: fill the window first, no z-score yet
        if len(self._values) < self.window:
            self._values.append(value)
            return 0.0

        # Compute mean/std from the PREVIOUS window (excludes new value)
        n = len(self._values)
        mean = sum(self._values) / n
        variance = sum((v - mean) ** 2 for v in self._values) / n

        # Update the window: add new value, drop oldest
        self._values.append(value)
        self._values.popleft()

        if variance <= 0.0:
            return 0.0

        std = math.sqrt(variance)
        return (value - mean) / std

    @property
    def fill_count(self) -> int:
        return len(self._values)

    @property
    def is_warmed(self) -> bool:
        return len(self._values) >= self.window

    def reset(self):
        """Clear all rolling state. Called on WebSocket reconnect."""
        self._values.clear()
