import json
import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx

from app.config import settings

logger = logging.getLogger("alphaclaw.ingestion.hn")

# Hacker News Firebase API
HN_API_BASE = "https://hacker-news.firebaseio.com/v0"


@dataclass
class Tier3Signal:
    """Emitted when a relevant HN story is detected."""
    source_handle: str            # HN item ID
    source_domain: str            # Story's source domain
    raw_text: str                 # Story title
    url: str                      # Story URL or HN comments URL
    hn_score: int                 # HN point score
    matched_tags: list[str]       # Which market_tags matched
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class HNPoller:
    """
    Tier 3 data source: Hacker News API.

    Polls /v0/topstories every HN_POLL_INTERVAL_SECONDS.
    Filters by keyword intersection with active market_tags.
    Tracks seen IDs in Redis to avoid reprocessing.
    """

    def __init__(self, narrative_dict_path: str = None):
        if narrative_dict_path is None:
            narrative_dict_path = str(
                Path(__file__).parent.parent.parent.parent.parent / "data" / "narrative_dict.json"
            )

        self._market_tags: set[str] = set()
        self._signal_callback = None
        self._running = False
        self._http_client: Optional[httpx.AsyncClient] = None
        self._load_market_tags(narrative_dict_path)

    def _load_market_tags(self, path: str):
        """Load all market_tags from the narrative dictionary."""
        try:
            with open(path) as f:
                data = json.load(f)
            for cat_id, category in data.get("categories", {}).items():
                for tag in category.get("market_tags", []):
                    self._market_tags.add(tag.lower())
            logger.info(f"HN poller loaded {len(self._market_tags)} market tags")
        except Exception as e:
            logger.error(f"Failed to load market tags: {e}")

    def on_signal(self, callback):
        """Register callback for Tier3Signal emissions."""
        self._signal_callback = callback

    async def start(self):
        """Start the polling loop."""
        self._running = True
        self._http_client = httpx.AsyncClient(timeout=15.0)

        logger.info(f"HN poller started. Interval: {settings.HN_POLL_INTERVAL_SECONDS}s")

        while self._running:
            try:
                await self._poll_cycle()
            except Exception as e:
                logger.error(f"HN poll cycle failed: {e}")

            await asyncio.sleep(settings.HN_POLL_INTERVAL_SECONDS)

    async def stop(self):
        """Stop the polling loop."""
        self._running = False
        if self._http_client:
            await self._http_client.aclose()

    async def _poll_cycle(self):
        """Fetch top stories, filter new ones, check relevance, emit signals."""
        # Fetch top story IDs
        response = await self._http_client.get(f"{HN_API_BASE}/topstories.json")
        response.raise_for_status()
        story_ids = response.json()

        if not isinstance(story_ids, list):
            return

        # Check top 30 stories (balances API calls vs coverage)
        for story_id in story_ids[:30]:
            # Deduplication: check if seen
            is_seen = await self._check_and_mark_seen(str(story_id))
            if is_seen:
                continue

            # Fetch story metadata
            story = await self._fetch_story(story_id)
            if not story:
                continue

            title = story.get("title", "")
            if not title:
                continue

            # Keyword filter: intersect title tokens with market_tags
            title_tokens = set(title.lower().split())
            matched_tags = list(title_tokens & self._market_tags)

            if not matched_tags:
                continue

            # Extract domain from story URL
            story_url = story.get("url", f"https://news.ycombinator.com/item?id={story_id}")
            source_domain = self._extract_domain(story_url)

            signal = Tier3Signal(
                source_handle=str(story_id),
                source_domain=source_domain,
                raw_text=title,
                url=story_url,
                hn_score=story.get("score", 0),
                matched_tags=matched_tags,
            )

            # Write to DB
            await self._write_signal_to_db(signal)

            logger.info(f"Tier3 signal: story={story_id}, title={title[:60]}, tags={matched_tags}")
            if self._signal_callback:
                await self._signal_callback(signal)

    async def _fetch_story(self, story_id: int) -> Optional[dict]:
        """Fetch story metadata from HN API."""
        try:
            response = await self._http_client.get(f"{HN_API_BASE}/item/{story_id}.json")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.debug(f"Failed to fetch HN story {story_id}: {e}")
            return None

    async def _check_and_mark_seen(self, story_id: str) -> bool:
        """Check Redis if story already processed. Mark with 24h TTL."""
        try:
            from app.redis_client import get_redis
            redis = await get_redis()
            key = f"hn:seen:{story_id}"
            already_seen = await redis.exists(key)
            if already_seen:
                return True
            await redis.set(key, "1", ex=86400)  # 24 hour TTL
            return False
        except Exception as e:
            logger.debug(f"Redis HN dedup failed: {e}")
            return False  # Fail open

    def _extract_domain(self, url: str) -> str:
        """Extract root domain from URL."""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            if domain.startswith("www."):
                domain = domain[4:]
            return domain or "news.ycombinator.com"
        except Exception:
            return "news.ycombinator.com"

    async def _write_signal_to_db(self, signal: Tier3Signal):
        """Write signal to the signals table."""
        try:
            from app.db import get_pool
            pool = await get_pool()
            await pool.execute(
                """
                INSERT INTO signals (source_tier, source_handle, raw_text, market_id)
                VALUES (3, $1, $2, NULL)
                """,
                signal.source_handle,
                signal.raw_text,
            )
        except Exception as e:
            logger.debug(f"Failed to write HN signal to DB: {e}")


async def run_hn_poller(signal_callback=None) -> HNPoller:
    """Helper to create and start HN poller as a background task."""
    poller = HNPoller()
    if signal_callback:
        poller.on_signal(signal_callback)
    await poller.start()
    return poller
