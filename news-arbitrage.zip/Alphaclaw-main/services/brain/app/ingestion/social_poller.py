import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

import httpx

from app.config import settings

logger = logging.getLogger("alphaclaw.ingestion.social")

# SocialData.tools API endpoint
SOCIALDATA_API_BASE = "https://api.socialdata.tools"


@dataclass
class Tier2Signal:
    """Emitted when a whitelisted account posts a relevant tweet."""
    source_handle: str
    source_domain: str
    raw_text: str
    canonical_tokens: list[str]   # Populated by FastMatchEngine, empty on initial emit
    trust_weight: float
    url: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class SocialPoller:
    """
    Tier 2 data source: SocialData.tools REST API.

    Polls for recent tweets every SOCIAL_POLL_INTERVAL_SECONDS.
    Filters against the whitelist. Deduplicates using Redis SET.
    """

    def __init__(self, whitelist_cache=None):
        self._whitelist = whitelist_cache
        self._signal_callback = None
        self._running = False
        self._http_client: Optional[httpx.AsyncClient] = None

    def on_signal(self, callback):
        """Register callback for Tier2Signal emissions."""
        self._signal_callback = callback

    async def start(self):
        """Start the polling loop."""
        self._running = True
        self._http_client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "Authorization": f"Bearer {settings.SOCIALDATA_API_KEY}",
                "Accept": "application/json",
            }
        )

        logger.info(f"Social poller started. Interval: {settings.SOCIAL_POLL_INTERVAL_SECONDS}s")

        while self._running:
            try:
                await self._poll_cycle()
            except Exception as e:
                logger.error(f"Social poll cycle failed: {e}")

            await asyncio.sleep(settings.SOCIAL_POLL_INTERVAL_SECONDS)

    async def stop(self):
        """Stop the polling loop and close HTTP client."""
        self._running = False
        if self._http_client:
            await self._http_client.aclose()

    async def _poll_cycle(self):
        """Execute one polling cycle: fetch → filter → deduplicate → emit."""
        # Reload whitelist if stale
        if self._whitelist:
            self._whitelist.reload_if_stale(max_age_seconds=300)

        # Search for recent tweets from tracked keywords/accounts
        tweets = await self._fetch_recent_tweets()

        for tweet in tweets:
            tweet_id = tweet.get("id") or tweet.get("id_str", "")
            handle = self._extract_handle(tweet)
            text = tweet.get("text", "") or tweet.get("full_text", "")

            if not tweet_id or not text:
                continue

            # Whitelist filter
            if self._whitelist and not self._whitelist.contains(handle):
                continue

            # Deduplication via Redis SET with 1-hour TTL
            is_duplicate = await self._check_and_mark_seen(str(tweet_id))
            if is_duplicate:
                continue

            # Build signal
            account = self._whitelist.get(handle) if self._whitelist else None
            trust_weight = account.trust_weight if account else 0.5

            # Extract source domain from any URL in the tweet
            source_domain = self._extract_domain(tweet)

            signal = Tier2Signal(
                source_handle=handle,
                source_domain=source_domain,
                raw_text=text,
                canonical_tokens=[],  # Populated downstream by FastMatchEngine
                trust_weight=trust_weight,
                url=f"https://twitter.com/{handle.lstrip('@')}/status/{tweet_id}",
            )

            # Write to DB
            await self._write_signal_to_db(signal)

            # Emit signal
            logger.info(f"Tier2 signal: handle={handle}, text={text[:80]}...")
            if self._signal_callback:
                await self._signal_callback(signal)

    async def _fetch_recent_tweets(self) -> list[dict]:
        """Fetch recent tweets from SocialData.tools API."""
        if not self._http_client:
            return []

        try:
            # SocialData.tools search endpoint
            response = await self._http_client.get(
                f"{SOCIALDATA_API_BASE}/twitter/search",
                params={
                    "query": "polymarket OR prediction market OR FOMC OR SEC OR ceasefire",
                    "type": "Latest",
                },
            )
            response.raise_for_status()
            data = response.json()
            return data.get("tweets", data.get("data", []))
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429:
                logger.warning("SocialData rate limited. Backing off.")
            else:
                logger.error(f"SocialData API error: {e.response.status_code}")
            return []
        except Exception as e:
            logger.error(f"SocialData fetch failed: {e}")
            return []

    def _extract_handle(self, tweet: dict) -> str:
        """Extract the @handle from a tweet object."""
        user = tweet.get("user", {}) or tweet.get("author", {})
        handle = user.get("screen_name") or user.get("username", "")
        if handle and not handle.startswith("@"):
            handle = f"@{handle}"
        return handle

    def _extract_domain(self, tweet: dict) -> str:
        """Extract the primary source domain from tweet URLs."""
        entities = tweet.get("entities", {})
        urls = entities.get("urls", [])
        for url_obj in urls:
            expanded_url = url_obj.get("expanded_url") or url_obj.get("url", "")
            if expanded_url:
                try:
                    parsed = urlparse(expanded_url)
                    domain = parsed.netloc.lower()
                    # Strip www. prefix
                    if domain.startswith("www."):
                        domain = domain[4:]
                    return domain
                except Exception:
                    pass
        return "twitter.com"

    async def _check_and_mark_seen(self, tweet_id: str) -> bool:
        """Check if tweet already seen. Mark as seen with 1h TTL. Returns True if duplicate."""
        try:
            from app.redis_client import get_redis
            redis = await get_redis()
            key = f"social:seen_ids:{tweet_id}"
            already_seen = await redis.exists(key)
            if already_seen:
                return True
            await redis.set(key, "1", ex=3600)  # 1 hour TTL
            return False
        except Exception as e:
            logger.debug(f"Redis dedup check failed: {e}")
            return False  # Fail open — process the tweet

    async def _write_signal_to_db(self, signal: Tier2Signal):
        """Write signal to the signals table."""
        try:
            from app.db import get_pool
            pool = await get_pool()
            await pool.execute(
                """
                INSERT INTO signals (source_tier, source_handle, raw_text, market_id)
                VALUES (2, $1, $2, NULL)
                """,
                signal.source_handle,
                signal.raw_text,
            )
        except Exception as e:
            logger.debug(f"Failed to write social signal to DB: {e}")


async def run_social_poller(whitelist_cache=None, signal_callback=None) -> SocialPoller:
    """Helper to create and start social poller as a background task."""
    poller = SocialPoller(whitelist_cache=whitelist_cache)
    if signal_callback:
        poller.on_signal(signal_callback)
    await poller.start()
    return poller
