import hashlib
import json
import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

import httpx

from app.config import settings

logger = logging.getLogger("alphaclaw.ingestion.perplexity")

PERPLEXITY_API_URL = "https://api.perplexity.ai/chat/completions"


@dataclass
class Citation:
    """A single citation from Perplexity's response."""
    url: str
    domain: str
    snippet: str


@dataclass
class PerplexityResult:
    """Result of a Perplexity fact-verification query."""
    summary: str
    citations: list[Citation]
    source_domains: set[str]     # Deduplicated root domains
    confidence: float            # 0.0-1.0 based on citation quality
    cached: bool = False
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class PerplexityClient:
    """
    Tier 4: Perplexity on-demand fact verification.

    Invoked by Fast-Match engine when a signal scores above
    FAST_MATCH_ESCALATION_THRESHOLD. Uses sonar-pro model with
    search_recency_filter: "hour".

    Features:
    - Request caching in Redis (5-minute TTL, keyed by query hash)
    - Retry with exponential backoff on rate-limit (429) responses
    - Domain normalization (strips subdomains to root domain)
    """

    def __init__(self):
        self._http_client: Optional[httpx.AsyncClient] = None

    async def initialize(self):
        """Initialize the HTTP client."""
        self._http_client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "Authorization": f"Bearer {settings.PERPLEXITY_API_KEY}",
                "Content-Type": "application/json",
            }
        )

    async def close(self):
        """Close the HTTP client."""
        if self._http_client:
            await self._http_client.aclose()

    async def fetch_corroboration(self, query: str) -> PerplexityResult:
        """
        Query Perplexity for corroboration of a signal.

        Args:
            query: Natural language query about the event to verify

        Returns:
            PerplexityResult with summary, citations, and source domains
        """
        if not self._http_client:
            await self.initialize()

        # Check cache first
        cache_key = self._cache_key(query)
        cached_result = await self._check_cache(cache_key)
        if cached_result:
            logger.debug(f"Perplexity cache hit for query: {query[:60]}...")
            return cached_result

        # Make API request with retry
        response_data = await self._request_with_retry(query)

        # Parse response
        result = self._parse_response(response_data)

        # Cache result
        await self._set_cache(cache_key, result)

        logger.info(
            f"Perplexity result: {len(result.citations)} citations, "
            f"{len(result.source_domains)} domains, confidence={result.confidence:.2f}"
        )
        return result

    async def _request_with_retry(
        self, query: str, max_retries: int = 3
    ) -> dict:
        """Make Perplexity API request with exponential backoff on 429."""
        backoff = 2  # seconds

        for attempt in range(max_retries):
            try:
                response = await self._http_client.post(
                    PERPLEXITY_API_URL,
                    json={
                        "model": settings.PERPLEXITY_MODEL,
                        "messages": [
                            {
                                "role": "system",
                                "content": (
                                    "You are a fact-checking assistant. Verify the following claim "
                                    "using recent news sources. Cite your sources."
                                ),
                            },
                            {
                                "role": "user",
                                "content": query,
                            },
                        ],
                        "search_recency_filter": "hour",
                        "return_citations": True,
                    },
                )

                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", backoff))
                    logger.warning(
                        f"Perplexity rate limited (attempt {attempt + 1}/{max_retries}). "
                        f"Retrying in {retry_after}s..."
                    )
                    await asyncio.sleep(retry_after)
                    backoff *= 2
                    continue

                response.raise_for_status()
                return response.json()

            except httpx.HTTPStatusError:
                raise
            except Exception as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Perplexity request failed (attempt {attempt + 1}): {e}")
                    await asyncio.sleep(backoff)
                    backoff *= 2
                else:
                    raise

        raise RuntimeError("Perplexity request failed after all retries")

    def _parse_response(self, data: dict) -> PerplexityResult:
        """Parse Perplexity API response into PerplexityResult."""
        choices = data.get("choices", [])
        content = ""
        if choices:
            content = choices[0].get("message", {}).get("content", "")

        # Extract citations from the response
        citations_raw = data.get("citations", [])
        citations = []
        source_domains = set()

        for cite in citations_raw:
            if isinstance(cite, str):
                url = cite
                snippet = ""
            elif isinstance(cite, dict):
                url = cite.get("url", "")
                snippet = cite.get("snippet", cite.get("text", ""))
            else:
                continue

            if not url:
                continue

            domain = self._normalize_domain(url)
            citations.append(Citation(url=url, domain=domain, snippet=snippet))
            source_domains.add(domain)

        # Compute confidence based on citation count and domain diversity
        confidence = self._compute_confidence(len(citations), len(source_domains))

        return PerplexityResult(
            summary=content,
            citations=citations,
            source_domains=source_domains,
            confidence=confidence,
        )

    def _normalize_domain(self, url: str) -> str:
        """Extract root domain from URL, stripping subdomains."""
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.lower()

            # Strip www. prefix
            if domain.startswith("www."):
                domain = domain[4:]

            # For common multi-level TLDs, keep the appropriate parts
            parts = domain.split(".")
            if len(parts) >= 3 and parts[-1] in ("uk", "au", "jp", "br"):
                # e.g., bbc.co.uk -> bbc.co.uk
                return ".".join(parts[-3:])
            elif len(parts) >= 2:
                # e.g., news.bbc.com -> bbc.com
                return ".".join(parts[-2:])

            return domain
        except Exception:
            return "unknown"

    def _compute_confidence(self, citation_count: int, domain_count: int) -> float:
        """
        Compute a confidence score based on citation quality.

        Heuristic:
        - 0 citations → 0.3 (low confidence)
        - 1-2 citations from 1 domain → 0.5
        - 2+ citations from 2+ domains → 0.7
        - 3+ citations from 3+ domains → 0.85
        - 5+ citations from 3+ domains → 0.95
        """
        if citation_count == 0:
            return 0.3
        if citation_count <= 2 and domain_count <= 1:
            return 0.5
        if domain_count >= 3 and citation_count >= 5:
            return 0.95
        if domain_count >= 3:
            return 0.85
        if domain_count >= 2:
            return 0.7
        return 0.5

    def _cache_key(self, query: str) -> str:
        """Generate a Redis cache key from the query hash."""
        query_hash = hashlib.sha256(query.encode()).hexdigest()[:16]
        return f"perplexity:cache:{query_hash}"

    async def _check_cache(self, key: str) -> Optional[PerplexityResult]:
        """Check Redis cache for a previous result."""
        try:
            from app.redis_client import get_redis
            redis = await get_redis()
            cached = await redis.get(key)
            if cached:
                data = json.loads(cached)
                citations = [
                    Citation(url=c["url"], domain=c["domain"], snippet=c["snippet"])
                    for c in data.get("citations", [])
                ]
                return PerplexityResult(
                    summary=data["summary"],
                    citations=citations,
                    source_domains=set(data.get("source_domains", [])),
                    confidence=data["confidence"],
                    cached=True,
                )
            return None
        except Exception as e:
            logger.debug(f"Cache check failed: {e}")
            return None

    async def _set_cache(self, key: str, result: PerplexityResult):
        """Cache a result in Redis with 5-minute TTL."""
        try:
            from app.redis_client import get_redis
            redis = await get_redis()
            data = {
                "summary": result.summary,
                "citations": [
                    {"url": c.url, "domain": c.domain, "snippet": c.snippet}
                    for c in result.citations
                ],
                "source_domains": list(result.source_domains),
                "confidence": result.confidence,
            }
            await redis.set(key, json.dumps(data), ex=300)  # 5 minute TTL
        except Exception as e:
            logger.debug(f"Cache set failed: {e}")
