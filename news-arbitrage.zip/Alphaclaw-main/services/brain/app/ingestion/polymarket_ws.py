import json
import asyncio
import logging
import random
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
import websockets
from websockets.exceptions import ConnectionClosed

from app.config import settings
from app.fastmatch.zscore import RollingZScore

logger = logging.getLogger("alphaclaw.ingestion.polymarket")

# Polymarket public WebSocket endpoint
POLYMARKET_WS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/market"


@dataclass
class Tier1Signal:
    """Emitted when a market shows anomalous price movement."""

    market_id: str
    current_price: float  # 0.0-1.0 (probability)
    price_delta: float    # change from rolling mean
    zscore: float
    volume_24h: float
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class PolymarketIngestion:
    """
    Tier 1 data source: Polymarket WebSocket price feed.

    Tracks all markets from resolution_schemas/, computes rolling Z-scores
    on price ticks, and emits Tier1Signal when |z| >= threshold.
    """

    def __init__(self, schemas_dir: str = None, anomaly_engine=None):
        if schemas_dir is None:
            schemas_dir = str(
                Path(__file__).parent.parent.parent.parent / "data" / "resolution_schemas"
            )

        self._schemas_dir = schemas_dir
        self._market_ids: list[str] = []
        self._asset_ids: list[str] = []                        # CLOB token IDs for WS subscription
        self._asset_to_market: dict[str, str] = {}             # asset_id -> condition_id
        self._zscores: dict[str, RollingZScore] = {}           # market_id -> RollingZScore
        self._last_prices: dict[str, float] = {}               # market_id -> last price
        self._signal_callback = None
        self._running = False
        self._anomaly_engine = anomaly_engine
        self._load_markets()

    def _load_markets(self):
        """Load tracked market IDs from resolution schemas directory."""
        schemas_path = Path(self._schemas_dir)
        if not schemas_path.exists():
            logger.warning(f"Resolution schemas dir not found: {self._schemas_dir}")
            return

        for schema_file in sorted(schemas_path.glob("*.json")):
            try:
                with open(schema_file) as f:
                    schema = json.load(f)
                # Prefer condition_id; fall back to market_id
                market_id = schema.get("condition_id") or schema.get("market_id")
                if not market_id:
                    logger.warning(
                        f"Schema {schema_file.name} has no condition_id or market_id field; skipping"
                    )
                    continue

                self._market_ids.append(market_id)
                self._zscores[market_id] = RollingZScore(window=settings.Z_SCORE_WINDOW)

                # Collect CLOB token IDs for WS subscription
                clob_tokens = schema.get("clob_tokens", {})
                for side in ("YES", "NO"):
                    token_id = clob_tokens.get(side)
                    if token_id:
                        self._asset_ids.append(token_id)
                        self._asset_to_market[token_id] = market_id
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON in schema {schema_file}: {e}")
            except OSError as e:
                logger.error(f"Failed to open schema {schema_file}: {e}")
            except Exception as e:
                logger.error(f"Unexpected error loading schema {schema_file}: {e}")

        logger.info(f"Polymarket WS: tracking {len(self._market_ids)} markets")

    def on_signal(self, callback):
        """Register a callback for Tier1Signal emissions.

        The callback must be an async callable with the signature:
            async def callback(signal: Tier1Signal) -> None
        """
        self._signal_callback = callback

    async def start(self):
        """Start the WebSocket connection with auto-reconnect.

        Runs until stop() is called. Uses exponential backoff with jitter
        (starting at 1s, capped at 60s) between reconnect attempts.
        Z-score state is reset on every reconnect to prevent stale windows
        from distorting scores after a gap in data.
        """
        self._running = True
        backoff = 1  # Initial backoff in seconds
        max_backoff = 60

        while self._running:
            try:
                await self._connect_and_listen()
                # Clean disconnect (server closed gracefully) — reset backoff
                backoff = 1
            except ConnectionClosed as e:
                logger.warning(
                    f"Polymarket WS disconnected: {e}. Reconnecting in {backoff}s..."
                )
            except Exception as e:
                logger.error(
                    f"Polymarket WS error: {e}. Reconnecting in {backoff}s..."
                )

            if not self._running:
                break

            # Exponential backoff with jitter (up to 10% of current backoff)
            jitter = random.uniform(0, backoff * 0.1)
            await asyncio.sleep(backoff + jitter)
            backoff = min(backoff * 2, max_backoff)

            # Reset Z-scores on reconnect to prevent stale rolling state
            self._reset_all_zscores()

    async def stop(self):
        """Gracefully stop the WebSocket connection."""
        self._running = False

    def _reset_all_zscores(self):
        """Reset all Z-score calculators. Called on reconnect."""
        for market_id in self._zscores:
            self._zscores[market_id].reset()
        if self._anomaly_engine:
            self._anomaly_engine.reset_all()
        logger.info("All Z-score calculators reset after reconnect")

    async def _connect_and_listen(self):
        """Open a WebSocket connection, subscribe to all tracked markets, and
        process incoming messages until the connection closes."""
        async with websockets.connect(POLYMARKET_WS_URL) as ws:
            logger.info(f"Connected to Polymarket WS: {POLYMARKET_WS_URL}")

            # Subscribe to all tracked assets in a single message
            subscribe_msg = json.dumps({
                "assets_ids": self._asset_ids,
                "type": "market",
            })
            await ws.send(subscribe_msg)

            logger.info(
                f"Subscribed to {len(self._asset_ids)} asset channels "
                f"across {len(self._market_ids)} markets"
            )

            # Process messages until the connection is closed
            async for raw_msg in ws:
                if not self._running:
                    break
                try:
                    msg = json.loads(raw_msg)
                    if isinstance(msg, list):
                        for element in msg:
                            try:
                                await self._handle_message(element)
                            except Exception as e:
                                logger.error(f"Error handling WS batch element: {e}")
                    elif isinstance(msg, dict):
                        await self._handle_message(msg)
                    else:
                        logger.warning(f"Unexpected WS message type: {type(msg).__name__}")
                except json.JSONDecodeError:
                    logger.warning(
                        f"Invalid JSON from Polymarket WS: {raw_msg[:200]}"
                    )
                except Exception as e:
                    logger.error(f"Error handling WS message: {e}")

    async def _handle_message(self, msg: dict):
        """Process a single WebSocket message.

        Handles price_change and last_trade_price event types. Extracts the
        asset ID, resolves it to a market (condition_id), updates the rolling
        Z-score, writes every tick to the DB, and emits a Tier1Signal if
        |zscore| >= threshold.
        """
        msg_type = msg.get("event_type", "")

        if msg_type == "price_change":
            # price_change contains a price_changes array with per-asset entries
            for change in msg.get("price_changes", []):
                asset_id = change.get("asset_id")
                market_id = self._asset_to_market.get(asset_id or "")
                if market_id is None:
                    continue

                best_bid = change.get("best_bid")
                best_ask = change.get("best_ask")
                if best_bid is None or best_ask is None:
                    continue
                try:
                    price = (float(best_bid) + float(best_ask)) / 2.0
                except (TypeError, ValueError):
                    continue

                await self._process_tick(
                    market_id, price, msg,
                    best_bid=float(best_bid), best_ask=float(best_ask),
                )

        elif msg_type == "last_trade_price":
            asset_id = msg.get("asset_id")
            market_id = self._asset_to_market.get(asset_id or "")
            if market_id is None:
                return

            raw_price = msg.get("price")
            if raw_price is None:
                return
            try:
                price = float(raw_price)
            except (TypeError, ValueError):
                return

            await self._process_tick(market_id, price, msg)

    async def _process_tick(
        self, market_id: str, price: float, msg: dict,
        best_bid: float | None = None, best_ask: float | None = None,
    ):
        """Update Z-score, persist tick, emit Tier1Signal, and feed anomaly engine."""
        if market_id not in self._zscores:
            return

        zscore = self._zscores[market_id].update(price)

        prev_price = self._last_prices.get(market_id, price)
        self._last_prices[market_id] = price
        price_delta = price - prev_price

        await self._write_tick_to_db(market_id, price, zscore)

        # Feed tick to anomaly engine (parallel path, does not block narrative)
        if self._anomaly_engine:
            try:
                await self._anomaly_engine.on_tick(market_id, price, best_bid, best_ask)
            except Exception as e:
                logger.error(f"Anomaly engine error: {e}")

        if abs(zscore) >= settings.Z_SCORE_THRESHOLD:
            signal = Tier1Signal(
                market_id=market_id,
                current_price=price,
                price_delta=price_delta,
                zscore=zscore,
                volume_24h=float(msg.get("volume_24h") or 0.0),
            )
            logger.info(
                f"Tier1 signal: market={market_id}, price={price:.4f}, "
                f"z={zscore:.2f}, delta={price_delta:.4f}"
            )
            if self._signal_callback:
                await self._signal_callback(signal)

    async def _write_tick_to_db(self, market_id: str, price: float, zscore: float):
        """Persist a single price tick to the signals table.

        Errors are logged at DEBUG level so a transient DB outage does not
        interrupt the ingestion loop.  source_tier=1 marks these rows as
        raw Polymarket data for Phase 2 calibration pipelines.
        """
        try:
            from app.db import get_pool

            pool = await get_pool()
            await pool.execute(
                """
                INSERT INTO signals (source_tier, source_handle, raw_text, market_id, zscore)
                VALUES (1, 'polymarket_ws', $1, $2, $3)
                """,
                f"price_tick:{price:.6f}",
                market_id,
                zscore,
            )
        except Exception as e:
            logger.debug(f"Failed to write tick to DB (market={market_id}): {e}")


async def run_polymarket_ingestion(
    signal_callback=None,
) -> PolymarketIngestion:
    """Create a PolymarketIngestion instance and start it as a long-running task.

    Intended for use as a background task in the main application lifecycle:

        asyncio.create_task(run_polymarket_ingestion(callback))

    Args:
        signal_callback: Optional async callable invoked for every Tier1Signal.

    Returns:
        The PolymarketIngestion instance (already running).
    """
    ingestion = PolymarketIngestion()
    if signal_callback:
        ingestion.on_signal(signal_callback)
    await ingestion.start()
    return ingestion
