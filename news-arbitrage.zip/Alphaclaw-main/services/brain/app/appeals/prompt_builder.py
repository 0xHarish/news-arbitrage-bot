import json


SYSTEM_PROMPT = """You are a legal analyst specializing in prediction market contract interpretation.
Your task is to determine whether a given news event satisfies the exact resolution
criteria of a specific prediction market contract.

You must respond with a JSON object ONLY. No prose. No explanation outside the JSON.

Response schema:
{
  "resolution_match": boolean,
  "outcome": "YES" | "NO" | "AMBIGUOUS",
  "confidence": float (0.0–1.0),
  "reasoning": string (1–3 sentences, suitable for public display),
  "disqualifying_factors": string[] | null,
  "requires_perplexity_followup": boolean
}

Rules:
- confidence > 0.80 required to recommend a trade
- If the event is a PRELIMINARY report, not a FINAL ruling, confidence must be <= 0.65
- If ANY forbidden_token from the resolution schema is present in the news, outcome = AMBIGUOUS
- Cite the specific resolution_criteria language in your reasoning"""


def build_user_prompt(
    signal_raw_text: str,
    signal_source_handle: str,
    signal_source_domain: str,
    resolution_schema: dict,
    perplexity_citations: list[dict] | None = None,
) -> str:
    """
    Build the user prompt for Opus with full market context.

    Args:
        signal_raw_text: The raw text of the news signal
        signal_source_handle: Source handle (e.g. @AP)
        signal_source_domain: Source domain (e.g. apnews.com)
        resolution_schema: The market's resolution schema dict
        perplexity_citations: Optional Perplexity fact-check citations
    """
    citations_text = "None available"
    if perplexity_citations:
        citations_text = json.dumps(perplexity_citations, indent=2)

    return f"""MARKET RESOLUTION CRITERIA:
{json.dumps(resolution_schema.get('resolution_criteria', ''), indent=2)}

KEY ENTITIES:
{json.dumps(resolution_schema.get('key_entities', []), indent=2)}

THRESHOLD CONDITIONS:
{json.dumps(resolution_schema.get('threshold_conditions', []), indent=2)}

NEWS SIGNAL:
Source: {signal_source_handle} ({signal_source_domain})
Text: {signal_raw_text}

CORROBORATING SOURCES (Perplexity):
{citations_text}

Does this news event satisfy the resolution criteria? Respond with the JSON schema only."""
