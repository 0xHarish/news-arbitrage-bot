import json
import re
import time
import logging
from dataclasses import dataclass
from typing import Optional

from openai import AsyncOpenAI

from app.config import settings
from app.appeals.prompt_builder import SYSTEM_PROMPT, build_user_prompt

logger = logging.getLogger("alphaclaw.appeals.opus")


def _extract_json(text: str) -> dict:
    """Extract JSON from a response that may be wrapped in markdown code fences."""
    text = text.strip()
    if not text:
        raise json.JSONDecodeError("Empty response from model", text, 0)
    # Strip markdown code fences (```json ... ``` or ``` ... ```)
    fence_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if fence_match:
        text = fence_match.group(1).strip()
    return json.loads(text)


@dataclass
class OpusVerdict:
    resolution_match: bool
    outcome: str              # "YES" | "NO" | "AMBIGUOUS"
    confidence: float         # 0.0-1.0
    reasoning: str
    disqualifying_factors: list[str] | None
    requires_perplexity_followup: bool
    latency_ms: int
    prompt_tokens: int
    completion_tokens: int
    verdict_id: str | None = None


class OpusClient:
    """
    Layer 2: Claude Opus 4.6 via OpenRouter (OpenAI-compatible API).

    Only invoked when Fast-Match score >= 0.6.
    Evaluates signals against market resolution criteria.
    """

    def __init__(self, perplexity_client=None):
        self._client = AsyncOpenAI(
            api_key=settings.OPENROUTER_API_KEY,
            base_url=settings.OPENROUTER_BASE_URL,
        )
        self._perplexity = perplexity_client

    async def invoke(
        self,
        signal_raw_text: str,
        signal_source_handle: str,
        signal_source_domain: str,
        signal_id: str | None,
        resolution_schema: dict,
        perplexity_citations: list[dict] | None = None,
    ) -> OpusVerdict:
        """
        Invoke Opus to evaluate a signal against resolution criteria.

        If the verdict requests a Perplexity followup, a second invocation
        is triggered with additional context (max 1 re-invocation).
        """
        # First invocation
        verdict = await self._call_opus(
            signal_raw_text=signal_raw_text,
            signal_source_handle=signal_source_handle,
            signal_source_domain=signal_source_domain,
            resolution_schema=resolution_schema,
            perplexity_citations=perplexity_citations,
        )

        # Write first verdict to DB
        verdict_db_id = await self._write_verdict_to_db(verdict, signal_id, resolution_schema)
        verdict.verdict_id = verdict_db_id

        # Handle followup request (max 1 re-invocation)
        if verdict.requires_perplexity_followup and self._perplexity:
            logger.info("Opus requested Perplexity followup — re-invoking...")
            try:
                followup_result = await self._perplexity.fetch_corroboration(
                    f"Verify: {signal_raw_text}"
                )
                followup_citations = [
                    {"url": c.url, "domain": c.domain, "snippet": c.snippet}
                    for c in followup_result.citations
                ]

                # Second invocation with additional context
                verdict = await self._call_opus(
                    signal_raw_text=signal_raw_text,
                    signal_source_handle=signal_source_handle,
                    signal_source_domain=signal_source_domain,
                    resolution_schema=resolution_schema,
                    perplexity_citations=(perplexity_citations or []) + followup_citations,
                )
                # Force no further followups
                verdict.requires_perplexity_followup = False

                # Write second verdict to DB
                followup_db_id = await self._write_verdict_to_db(verdict, signal_id, resolution_schema)
                verdict.verdict_id = followup_db_id
            except Exception as e:
                logger.error(f"Perplexity followup failed: {e}")

        return verdict

    async def _call_opus(
        self,
        signal_raw_text: str,
        signal_source_handle: str,
        signal_source_domain: str,
        resolution_schema: dict,
        perplexity_citations: list[dict] | None = None,
    ) -> OpusVerdict:
        """Make a single async Opus API call via OpenRouter and parse the response."""
        user_prompt = build_user_prompt(
            signal_raw_text=signal_raw_text,
            signal_source_handle=signal_source_handle,
            signal_source_domain=signal_source_domain,
            resolution_schema=resolution_schema,
            perplexity_citations=perplexity_citations,
        )

        start_time = time.monotonic()

        try:
            response = await self._client.chat.completions.create(
                model=settings.CLAUDE_MODEL,
                max_tokens=1024,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
            )

            latency_ms = int((time.monotonic() - start_time) * 1000)

            raw_text = response.choices[0].message.content or ""
            usage = response.usage

            logger.debug(f"Opus raw response ({len(raw_text)} chars): {raw_text[:500]}")

            verdict_data = _extract_json(raw_text)

            return OpusVerdict(
                resolution_match=verdict_data.get("resolution_match", False),
                outcome=verdict_data.get("outcome", "AMBIGUOUS"),
                confidence=float(verdict_data.get("confidence", 0.0)),
                reasoning=verdict_data.get("reasoning", ""),
                disqualifying_factors=verdict_data.get("disqualifying_factors"),
                requires_perplexity_followup=verdict_data.get("requires_perplexity_followup", False),
                latency_ms=latency_ms,
                prompt_tokens=usage.prompt_tokens if usage else 0,
                completion_tokens=usage.completion_tokens if usage else 0,
            )

        except json.JSONDecodeError as e:
            latency_ms = int((time.monotonic() - start_time) * 1000)
            logger.error(f"Opus returned non-JSON response: {e} | raw={raw_text[:300]!r}")
            return OpusVerdict(
                resolution_match=False,
                outcome="AMBIGUOUS",
                confidence=0.0,
                reasoning=f"Opus response parse error: {e}",
                disqualifying_factors=["json_parse_error"],
                requires_perplexity_followup=False,
                latency_ms=latency_ms,
                prompt_tokens=0,
                completion_tokens=0,
            )
        except Exception as e:
            latency_ms = int((time.monotonic() - start_time) * 1000)
            logger.error(f"Opus API call failed: {e}")
            return OpusVerdict(
                resolution_match=False,
                outcome="AMBIGUOUS",
                confidence=0.0,
                reasoning=f"Opus API error: {e}",
                disqualifying_factors=["api_error"],
                requires_perplexity_followup=False,
                latency_ms=latency_ms,
                prompt_tokens=0,
                completion_tokens=0,
            )

    async def _write_verdict_to_db(
        self, verdict: OpusVerdict, signal_id: str | None, resolution_schema: dict
    ) -> str | None:
        """Persist the verdict to opus_verdicts table."""
        try:
            from app.db import get_pool
            pool = await get_pool()
            row = await pool.fetchrow(
                """
                INSERT INTO opus_verdicts (
                    signal_id, market_id, prompt_tokens, completion_tokens,
                    raw_response, resolution_match, opus_confidence,
                    reasoning_summary, latency_ms
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                RETURNING id
                """,
                signal_id,
                resolution_schema.get("market_id", resolution_schema.get("condition_id", "")),
                verdict.prompt_tokens,
                verdict.completion_tokens,
                json.dumps({
                    "outcome": verdict.outcome,
                    "confidence": verdict.confidence,
                    "reasoning": verdict.reasoning,
                    "disqualifying_factors": verdict.disqualifying_factors,
                }),
                verdict.resolution_match,
                verdict.confidence,
                verdict.reasoning,
                verdict.latency_ms,
            )
            return str(row["id"]) if row else None
        except Exception as e:
            logger.error(f"Failed to write opus verdict to DB: {e}")
            return None
