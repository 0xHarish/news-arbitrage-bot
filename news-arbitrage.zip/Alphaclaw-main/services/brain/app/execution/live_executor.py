"""Phase C: Live trade execution via Polymarket CLOB API."""

import asyncio
import logging
import traceback

from py_clob_client.client import ClobClient
from py_clob_client.clob_types import ApiCreds, OrderArgs, OrderType
from py_clob_client.order_builder.constants import BUY

from app.config import settings

logger = logging.getLogger("alphaclaw.execution")

# Lazy-initialized singleton
_client: ClobClient | None = None


def _get_client() -> ClobClient:
    """Lazy-initialize the ClobClient singleton."""
    global _client
    if _client is None:
        creds = ApiCreds(
            api_key=settings.POLYMARKET_API_KEY,
            api_secret=settings.POLYMARKET_API_SECRET,
            api_passphrase=settings.POLYMARKET_API_PASSPHRASE,
        )
        _client = ClobClient(
            host=settings.POLYMARKET_CLOB_BASE_URL,
            key=settings.HOT_WALLET_PRIVATE_KEY,
            chain_id=137,
            signature_type=0,
            funder=settings.HOT_WALLET_ADDRESS,
            creds=creds,
        )
        logger.info("ClobClient initialized for live execution")
    return _client


async def execute_live_trade(signal: dict) -> dict | None:
    """
    Execute a live trade on Polymarket CLOB.

    Args:
        signal: Dict with keys: clob_token_id, price, position_usdc,
                side, market_id, zscore, limit_price

    Returns:
        {"order_id": ..., "status": ..., "limit_price": ..., "size": ...}
        on success, None on failure.
    """
    try:
        client = _get_client()
        token_id = signal["clob_token_id"]
        signal_price = signal["price"]

        # a. Get midpoint
        mid = float(await asyncio.to_thread(client.get_midpoint, token_id))
        logger.info(
            f"LIVE_EXEC: midpoint={mid:.6f} for token={token_id[:16]}... "
            f"market={signal['market_id']}"
        )

        # b. Slippage check
        slippage_bps = abs(mid - signal_price) / signal_price * 10_000
        if slippage_bps > settings.ANOMALY_MAX_SLIPPAGE_BPS:
            logger.warning(
                f"LIVE_EXEC SKIP: slippage={slippage_bps:.1f}bps > "
                f"max={settings.ANOMALY_MAX_SLIPPAGE_BPS}bps "
                f"mid={mid:.6f} signal_price={signal_price:.6f} "
                f"market={signal['market_id']}"
            )
            return None

        # c. Compute fill price (cross the spread for immediate fill)
        side = signal["side"]
        position_usdc = signal["position_usdc"]

        # Use the best ask price to ensure immediate fill
        # Add a small buffer (ANOMALY_LIMIT_OFFSET) to ensure we cross the spread
        fill_price = round(mid + settings.ANOMALY_LIMIT_OFFSET, 2)
        # Ensure price is within valid range
        fill_price = min(fill_price, 0.99)
        fill_price = max(fill_price, 0.01)

        # d. Compute size based on fill price
        size = round(position_usdc / fill_price, 2)
        # Minimum size check
        if size < 1.0:
            size = 1.0

        logger.info(
            f"LIVE_EXEC ORDER: market={signal['market_id']} side={side} "
            f"fill_price={fill_price:.6f} size={size:.4f} "
            f"position_usdc={position_usdc:.2f} (crossing spread for immediate fill)"
        )

        # e. Create and post order (price above market = immediate fill)
        order_args = OrderArgs(
            price=fill_price,
            size=size,
            side=BUY,
            token_id=token_id,
        )
        signed_order = await asyncio.to_thread(client.create_order, order_args)
        # Use GTC but price above market = immediate fill. FOK may not be supported.
        resp = await asyncio.to_thread(client.post_order, signed_order, OrderType.GTC)

        # f. Log everything
        order_id = resp.get("orderID", "UNKNOWN")
        status = resp.get("status", "UNKNOWN")
        logger.info(
            f"LIVE_EXEC RESULT: order_id={order_id} status={status} "
            f"fill_price={fill_price:.6f} size={size:.4f} "
            f"market={signal['market_id']} side={side}"
        )
        if resp.get("errorMsg"):
            logger.error(f"LIVE_EXEC API ERROR: {resp['errorMsg']}")

        # Step 5: Write to live_trades DB
        await _write_live_trade(
            signal=signal,
            order_id=order_id,
            limit_price=fill_price,
            filled_amount=size,
            status=status,
        )

        # g. Return result
        return {
            "order_id": order_id,
            "status": status,
            "limit_price": fill_price,
            "size": size,
        }

    except Exception as e:
        # h. Never crash the engine
        logger.error(
            f"LIVE_EXEC ERROR: {e}\n"
            f"signal={signal}\n"
            f"{traceback.format_exc()}"
        )
        return None


async def _write_live_trade(
    signal: dict,
    order_id: str,
    limit_price: float,
    filled_amount: float,
    status: str,
) -> None:
    """Persist live trade to live_trades table."""
    try:
        from app.db import get_pool

        pool = await get_pool()
        await pool.execute(
            """
            INSERT INTO live_trades (
                signal_id, verdict_id, market_id, clob_token_id, side,
                limit_price, composite_p, kelly_fraction, position_usdc,
                order_ids, filled_amount, status
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
            """,
            None,                           # signal_id (anomaly trades have no narrative signal)
            None,                           # verdict_id
            signal["market_id"],
            signal.get("clob_token_id"),
            signal["side"],
            limit_price,
            0.0,                            # composite_p (not used by anomaly trades)
            0.0,                            # kelly_fraction (not used by anomaly trades)
            signal["position_usdc"],
            [order_id],                     # order_ids TEXT[] — wrap single ID in array
            filled_amount,
            status,
        )
        logger.info(f"LIVE_EXEC DB: trade recorded for market={signal['market_id']}")
    except Exception as e:
        logger.warning(
            f"LIVE_EXEC DB ERROR: failed to write live trade: {e}\n"
            f"{traceback.format_exc()}"
        )
