import redis.asyncio as redis
from app.config import settings

client: redis.Redis | None = None


async def init_redis() -> None:
    global client
    client = redis.from_url(settings.REDIS_URL, decode_responses=True)


async def close_redis() -> None:
    global client
    if client:
        await client.close()
        client = None


async def get_redis() -> redis.Redis:
    if client is None:
        raise RuntimeError("Redis client not initialized")
    return client
