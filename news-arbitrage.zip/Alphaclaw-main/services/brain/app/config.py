from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Logging
    LOG_LEVEL: str = "INFO"

    # Infrastructure
    REDIS_URL: str = "redis://localhost:6379"
    TIMESCALE_URL: str = "postgresql://alphaclaw:password@localhost:5432/alphaclaw"

    # LLM (via OpenRouter)
    OPENROUTER_API_KEY: str
    OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"
    CLAUDE_MODEL: str = "anthropic/claude-opus-4-6"

    # Perplexity
    PERPLEXITY_API_KEY: str
    PERPLEXITY_MODEL: str = "sonar-pro"

    # Social data
    SOCIALDATA_API_KEY: str

    # Signal detection
    Z_SCORE_THRESHOLD: float = 2.5
    Z_SCORE_WINDOW: int = 50
    Z_SCORE_MAX: float = 5.0

    # Fast-match escalation
    FAST_MATCH_ESCALATION_THRESHOLD: float = 0.60

    # Position sizing
    KELLY_FRACTION: float = 0.25
    MAX_WALLET_EXPOSURE: float = 0.05
    MIN_POSITION_USDC: float = 5.00

    # Composite probability gate
    MIN_COMPOSITE_P: float = 0.80

    # Composite score weights
    W_OPUS: float = 0.75
    W_ZSCORE: float = 0.25

    # Polymarket CLOB API
    POLYMARKET_CLOB_BASE_URL: str = "https://clob.polymarket.com"
    POLYMARKET_API_KEY: str = ""
    POLYMARKET_API_SECRET: str = ""
    POLYMARKET_API_PASSPHRASE: str = ""
    HOT_WALLET_PRIVATE_KEY: str = ""
    HOT_WALLET_ADDRESS: str = ""

    # Polling intervals (seconds)
    SOCIAL_POLL_INTERVAL_SECONDS: int = 15
    HN_POLL_INTERVAL_SECONDS: int = 60
    WHITELIST_EXPORT_INTERVAL_SECONDS: int = 300

    # Anomaly Engine
    ANOMALY_ENABLED: bool = True
    ANOMALY_PHASE: str = "C"                    # "A"=log only, "B"=shadow, "C"=live
    ANOMALY_Z_THRESHOLD: float = 0.5
    ANOMALY_Z_WINDOW: int = 60
    ANOMALY_MIN_PRICE_DELTA: float = 0.01
    ANOMALY_WALLET_EXPOSURE: float = 0.005      # 0.5% per trade
    ANOMALY_COOLDOWN_SECONDS: int = 600         # 10 min per market
    ANOMALY_MAX_SLIPPAGE_BPS: int = 80
    ANOMALY_MIN_VOLUME_24H: float = 5000.0
    ANOMALY_MIN_DEPTH: float = 500.0
    ANOMALY_MAX_SPREAD: float = 0.05            # 5%
    ANOMALY_LIMIT_OFFSET: float = 0.01          # mid +/- 0.01
    ANOMALY_EXPIRES_SECONDS: int = 300          # 5 min signal expiry
    ANOMALY_STATS_INTERVAL_SECONDS: int = 60   # diagnostic dump every 60s
    ANOMALY_REQUIRE_VOLUME: bool = False       # Phase A: don't hard-block on missing volume
    ANOMALY_REQUIRE_DEPTH: bool = False        # Phase A: don't hard-block on missing depth
    ANOMALY_PRICE_MIN: float = 0.15            # Skip ticks below this (settled/resolved)
    ANOMALY_PRICE_MAX: float = 0.85            # Skip ticks above this (settled/resolved)


settings = Settings()
