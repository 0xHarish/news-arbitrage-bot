import json
import os
import logging
import asyncio
from pathlib import Path
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional

from app.config import settings
from app.db import get_pool

logger = logging.getLogger("alphaclaw.whitelist")

# Default path for the whitelist snapshot file
DEFAULT_WHITELIST_PATH = Path(__file__).parent.parent.parent.parent.parent / "data" / "whitelist.json"


@dataclass
class WhitelistAccount:
    handle: str
    category_ids: list[str]
    trust_weight: float
    is_active: bool = True
    notes: Optional[str] = None


@dataclass
class WhitelistSnapshot:
    accounts: list[WhitelistAccount]
    exported_at: str
    count: int


async def export_snapshot(output_path: Path = DEFAULT_WHITELIST_PATH) -> bool:
    """
    Export whitelist from DB to JSON file using atomic write.

    Safety guards:
    - Aborts if the new export is empty
    - Aborts if the new export is less than 50% the size of the previous export
      (protects against accidental mass-deletion in DB)
    - Uses atomic write pattern: write to .tmp.json first, then os.replace()

    Returns True on success, False on abort.
    """
    try:
        pool = await get_pool()

        # Query all active whitelist accounts
        rows = await pool.fetch(
            """
            SELECT handle, category_ids, trust_weight, is_active, notes
            FROM whitelist_accounts
            WHERE is_active = TRUE
            ORDER BY handle
            """
        )

        new_count = len(rows)

        # Guard: abort on empty export
        if new_count == 0:
            logger.error("Whitelist export aborted: query returned 0 accounts")
            await _alert_admin("Whitelist export aborted: 0 accounts returned from DB", "CRITICAL")
            return False

        # Guard: 50% shrink protection
        if output_path.exists():
            try:
                with open(output_path) as f:
                    previous = json.load(f)
                    previous_count = previous.get("count", 0)
                    if previous_count > 0 and new_count < previous_count * 0.5:
                        logger.error(
                            f"Whitelist export aborted: new count ({new_count}) is <50% of "
                            f"previous count ({previous_count}). Possible mass deletion."
                        )
                        await _alert_admin(
                            f"Whitelist shrink guard triggered: {new_count} vs {previous_count} previous",
                            "CRITICAL"
                        )
                        return False
            except (json.JSONDecodeError, KeyError):
                pass  # Previous file is corrupt — overwrite is fine

        # Build snapshot
        accounts = []
        for row in rows:
            accounts.append({
                "handle": row["handle"],
                "category_ids": json.loads(row["category_ids"]) if isinstance(row["category_ids"], str) else row["category_ids"],
                "trust_weight": row["trust_weight"],
            })

        snapshot = {
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "count": new_count,
            "accounts": accounts,
        }

        # Atomic write: .tmp first, then replace
        tmp_path = output_path.with_suffix(".tmp.json")
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(tmp_path, "w") as f:
            json.dump(snapshot, f, indent=2)

        os.replace(str(tmp_path), str(output_path))
        logger.info(f"Whitelist exported: {new_count} accounts to {output_path}")
        return True

    except Exception as e:
        logger.error(f"Whitelist export failed: {e}")
        await _alert_admin(f"Whitelist export failed: {e}", "CRITICAL")
        return False


async def _alert_admin(message: str, severity: str = "WARNING"):
    """Write an alert to the admin_alerts table."""
    try:
        pool = await get_pool()
        await pool.execute(
            "INSERT INTO admin_alerts (severity, message) VALUES ($1, $2)",
            severity, message
        )
    except Exception as e:
        logger.error(f"Failed to write admin alert: {e}")


async def scheduled_export_loop():
    """Background task that exports whitelist on a regular interval."""
    while True:
        await asyncio.sleep(settings.WHITELIST_EXPORT_INTERVAL_SECONDS)
        await export_snapshot()


async def listen_for_refresh():
    """Subscribe to Redis 'whitelist:refresh' channel and trigger immediate export."""
    try:
        # Imported here to keep the redis package as an optional runtime dependency
        # for tests that do not exercise the pub/sub path.
        from app.redis_client import get_redis
        redis = await get_redis()
        pubsub = redis.pubsub()
        await pubsub.subscribe("whitelist:refresh")

        async for message in pubsub.listen():
            if message["type"] == "message":
                logger.info("Received whitelist:refresh signal, exporting...")
                await export_snapshot()
    except Exception as e:
        logger.error(f"Whitelist refresh listener failed: {e}")


class WhitelistCache:
    """
    In-memory cache of the whitelist for fast signal filtering.

    Loads from the JSON snapshot file. Provides O(1) lookups by handle.
    Auto-reloads if the snapshot is stale.
    """

    def __init__(self, whitelist_path: Path = DEFAULT_WHITELIST_PATH):
        self._path = whitelist_path
        self._accounts: dict[str, WhitelistAccount] = {}
        self._loaded_at: Optional[datetime] = None
        self._count: int = 0

    def load(self) -> int:
        """
        Load the whitelist from the JSON snapshot file.
        Returns the number of accounts loaded.
        """
        if not self._path.exists():
            logger.warning(f"Whitelist file not found: {self._path}")
            return 0

        try:
            with open(self._path) as f:
                data = json.load(f)

            self._accounts.clear()
            for entry in data.get("accounts", []):
                account = WhitelistAccount(
                    handle=entry["handle"],
                    category_ids=entry.get("category_ids", []),
                    trust_weight=entry.get("trust_weight", 0.5),
                )
                # Store with both @ and without @ prefix
                handle = entry["handle"]
                self._accounts[handle.lower()] = account
                if handle.startswith("@"):
                    self._accounts[handle[1:].lower()] = account
                else:
                    self._accounts[f"@{handle}".lower()] = account

            self._loaded_at = datetime.now(timezone.utc)
            self._count = len(data.get("accounts", []))
            logger.info(f"WhitelistCache loaded: {self._count} accounts")
            return self._count

        except Exception as e:
            logger.error(f"WhitelistCache load failed: {e}")
            return 0

    def get(self, handle: str) -> Optional[WhitelistAccount]:
        """
        Look up an account by handle. Case-insensitive.
        Returns None if the handle is not in the whitelist.
        """
        return self._accounts.get(handle.lower())

    def reload_if_stale(self, max_age_seconds: int = 300) -> bool:
        """
        Reload the whitelist if it's older than max_age_seconds.
        Returns True if a reload was performed.
        """
        if self._loaded_at is None:
            self.load()
            return True

        age = (datetime.now(timezone.utc) - self._loaded_at).total_seconds()
        if age > max_age_seconds:
            self.load()
            return True

        return False

    @property
    def count(self) -> int:
        return self._count

    def contains(self, handle: str) -> bool:
        """Check if a handle is in the whitelist."""
        return self.get(handle) is not None
