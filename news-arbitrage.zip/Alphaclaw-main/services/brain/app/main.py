import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI

from app.db import init_db, close_db, get_pool
from app.redis_client import init_redis, close_redis, get_redis
from app.config import settings
from app.fastmatch.engine import FastMatchEngine, FastMatchResult, InboundSignal
from app.whitelist.exporter import WhitelistCache, export_snapshot, scheduled_export_loop
from app.ingestion.polymarket_ws import PolymarketIngestion, Tier1Signal
from app.ingestion.social_poller import SocialPoller, Tier2Signal
from app.ingestion.hn_poller import HNPoller, Tier3Signal
from app.ingestion.perplexity_client import PerplexityClient
from app.appeals.opus_client import OpusClient
from app.sizing.kelly import calculate_position, calculate_composite_p, calculate_kelly_fraction
from app.publisher.redis_pub import (
    publish_trade_signal, publish_neural_trace_public, publish_neural_trace_raw,
    publish_drop_event,
)
from app.shadow.price_tracker import fetch_mid_price

logger = logging.getLogger("alphaclaw.brain")
logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO), format="%(asctime)s %(name)s %(levelname)s %(message)s")

# Project root for data file paths
PROJECT_ROOT = Path(__file__).parent.parent.parent.parent
NARRATIVE_DICT_PATH = str(PROJECT_ROOT / "data" / "narrative_dict.json")
RESOLUTION_SCHEMAS_DIR = str(PROJECT_ROOT / "data" / "resolution_schemas")

# Module-level references for graceful shutdown
_background_tasks: list[asyncio.Task] = []
_polymarket: PolymarketIngestion | None = None
_social_poller: SocialPoller | None = None
_hn_poller: HNPoller | None = None
_perplexity: PerplexityClient | None = None
_whitelist_cache: WhitelistCache | None = None
_fast_match: FastMatchEngine | None = None
_opus_client: OpusClient | None = None
_anomaly_engine = None


def _get_market_title(market_id: str | None) -> str:
    """Resolve a human-readable market title from the resolution schema."""
    if not market_id or not _fast_match:
        return market_id or "Unknown Market"
    schema = _fast_match.get_resolution_schema(market_id)
    if schema:
        return schema.get("title", schema.get("question", market_id))
    return market_id


async def _escalate_signal(
    result: FastMatchResult,
    inbound: InboundSignal,
    signal_db_id: str | None,
) -> None:
    """Full escalation pipeline: Opus → Kelly → publish trade signal."""
    if not _opus_client or not _fast_match:
        return

    market_id = result.matched_market_id
    if not market_id:
        logger.warning("Escalation skipped: no matched_market_id")
        return

    # 1. Publish HUNT event — Terminal shows signal being evaluated
    await publish_neural_trace_public("HUNT", {
        "market_title": _get_market_title(market_id),
        "source_handle": inbound.source_handle,
        "source_tier": inbound.source_tier,
        "fast_match_score": result.fast_match_score,
        "action": "Evaluating signal...",
        "reasoning_summary": f"Tier {inbound.source_tier} signal escalated (score={result.fast_match_score:.2f})",
    })
    await publish_neural_trace_raw("SIGNAL_ESCALATED", {
        "market_id": market_id,
        "signal_id": signal_db_id,
        "source_handle": inbound.source_handle,
        "source_tier": inbound.source_tier,
        "fast_match_score": result.fast_match_score,
        "raw_text": inbound.raw_text,
    })

    # 2. Look up resolution schema
    resolution_schema = _fast_match.get_resolution_schema(market_id)
    if not resolution_schema:
        logger.warning(f"No resolution schema for market {market_id}")
        await publish_drop_event(
            market_title=market_id,
            drop_reason="no_resolution_schema",
            source_handle=inbound.source_handle,
            source_url=inbound.url or "",
        )
        return

    market_title = resolution_schema.get("title", resolution_schema.get("question", market_id))

    # 3. Call Opus
    try:
        verdict = await _opus_client.invoke(
            signal_raw_text=inbound.raw_text,
            signal_source_handle=inbound.source_handle,
            signal_source_domain=inbound.source_domain,
            signal_id=signal_db_id,
            resolution_schema=resolution_schema,
        )
    except Exception as e:
        logger.error(f"Opus invocation failed: {e}")
        await publish_drop_event(
            market_title=market_title,
            drop_reason="opus_invocation_error",
            source_handle=inbound.source_handle,
            source_url=inbound.url or "",
        )
        return

    # 4. Gate on AMBIGUOUS or no resolution match
    if verdict.outcome == "AMBIGUOUS" or not verdict.resolution_match:
        drop_reason = "ambiguous_verdict" if verdict.outcome == "AMBIGUOUS" else "no_resolution_match"
        logger.info(f"Opus dropped signal: {drop_reason} (market={market_id})")
        await publish_drop_event(
            market_title=market_title,
            drop_reason=drop_reason,
            source_handle=inbound.source_handle,
            source_url=inbound.url or "",
        )
        return

    # 5. Calculate composite probability
    zscore = inbound.zscore if inbound.zscore is not None else 0.0
    composite_p = calculate_composite_p(verdict.confidence, zscore)

    # 6. Gate on MIN_COMPOSITE_P
    if composite_p < settings.MIN_COMPOSITE_P:
        logger.info(f"Composite_p below threshold: {composite_p:.3f} < {settings.MIN_COMPOSITE_P} (market={market_id})")
        await publish_drop_event(
            market_title=market_title,
            drop_reason=f"composite_p_below_threshold ({composite_p:.3f})",
            source_handle=inbound.source_handle,
            source_url=inbound.url or "",
        )
        return

    # Resolve CLOB token_id from FastMatch result (decimal, not hex condition_id)
    clob_token = (result.matched_clob_token_yes if verdict.outcome == "YES"
                  else result.matched_clob_token_no)
    if not clob_token:
        logger.error(f"No CLOB token_id for market {market_id} side {verdict.outcome}")
        await publish_drop_event(
            market_title=market_title,
            drop_reason="no_clob_token_id",
            source_handle=inbound.source_handle,
            source_url=inbound.url or "",
        )
        return

    # Fetch current market price from CLOB API
    market_price = await fetch_mid_price(clob_token)
    if market_price is None:
        logger.error(f"Cannot fetch market price for {market_id} (token={clob_token})")
        await publish_drop_event(
            market_title=market_title,
            drop_reason="market_price_unavailable",
            source_handle=inbound.source_handle,
            source_url=inbound.url or "",
        )
        return

    # 7. Calculate position size
    wallet_total_usdc = 1000.0
    position_usdc = calculate_position(composite_p, market_price, wallet_total_usdc)

    # 8. Gate on position_usdc
    if position_usdc <= 0:
        logger.info(f"Position size zero: composite_p={composite_p:.3f}, price={market_price:.4f} (market={market_id})")
        await publish_drop_event(
            market_title=market_title,
            drop_reason=f"position_size_zero (kelly unprofitable at price={market_price:.4f})",
            source_handle=inbound.source_handle,
            source_url=inbound.url or "",
        )
        return

    # Calculate supporting values
    kelly_fraction = calculate_kelly_fraction(composite_p, market_price)
    wallet_exposure = position_usdc / wallet_total_usdc
    side = verdict.outcome  # "YES" or "NO"

    # 9. Publish trade signal → DB then Redis → Broker picks it up
    trade_signal_id = await publish_trade_signal(
        signal_id=signal_db_id or "",
        verdict_id=verdict.verdict_id or "",
        market_id=market_id,
        side=side,
        composite_p=composite_p,
        kelly_fraction=kelly_fraction,
        position_usdc=position_usdc,
        wallet_exposure=wallet_exposure,
        market_price=market_price,
        reasoning_summary=verdict.reasoning[:500],
        source_url=inbound.url or "",
        clob_token_id=clob_token,
    )

    # 10. Publish STRIKE event — Terminal shows trade signal
    logger.info(
        f"TRADE SIGNAL: market={market_id} side={side} ${position_usdc} "
        f"(composite_p={composite_p:.3f}, kelly={kelly_fraction:.4f})"
    )
    await publish_neural_trace_public("STRIKE", {
        "market_title": market_title,
        "side": side,
        "position_usdc": position_usdc,
        "composite_p": composite_p,
        "market_price": market_price,
        "action": f"TRADE: {side} ${position_usdc:.2f}",
        "reasoning_summary": verdict.reasoning[:200],
        "source_url": inbound.url or "",
        "confidence_label": f"{composite_p:.0%}",
    })
    await publish_neural_trace_raw("TRADE_SIGNAL_PUBLISHED", {
        "trade_signal_id": trade_signal_id,
        "signal_id": signal_db_id,
        "verdict_id": verdict.verdict_id,
        "market_id": market_id,
        "market_title": market_title,
        "side": side,
        "composite_p": composite_p,
        "kelly_fraction": kelly_fraction,
        "position_usdc": position_usdc,
        "wallet_exposure": wallet_exposure,
        "market_price": market_price,
        "reasoning": verdict.reasoning,
    })


async def _handle_tier1_signal(signal: Tier1Signal):
    """Route Tier 1 (Polymarket price anomaly) signals to FastMatch."""
    if not _fast_match:
        return
    inbound = InboundSignal(
        source_tier=1,
        source_handle="polymarket_ws",
        source_domain="polymarket.com",
        raw_text=f"Price anomaly: {signal.market_id} z={signal.zscore:.2f} price={signal.current_price:.4f}",
        market_id=signal.market_id,
        zscore=signal.zscore,
        timestamp=signal.timestamp,
    )
    result = await _fast_match.process(inbound)
    signal_db_id = await _fast_match.write_signal_to_db(result)
    if result.escalate_to_opus:
        logger.info(f"Tier1 escalated to Opus: market={signal.market_id}, score={result.fast_match_score:.2f}")
        await _escalate_signal(result, inbound, signal_db_id)
    else:
        await publish_drop_event(
            market_title=_get_market_title(signal.market_id),
            drop_reason=result.drop_reason or "below_escalation_threshold",
            source_handle="polymarket_ws",
        )


async def _handle_tier2_signal(signal: Tier2Signal):
    """Route Tier 2 (social) signals to FastMatch."""
    if not _fast_match:
        return
    inbound = InboundSignal(
        source_tier=2,
        source_handle=signal.source_handle,
        source_domain=signal.source_domain,
        raw_text=signal.raw_text,
        trust_weight=signal.trust_weight,
        url=signal.url,
        timestamp=signal.timestamp,
    )
    result = await _fast_match.process(inbound)
    signal_db_id = await _fast_match.write_signal_to_db(result)
    if result.escalate_to_opus:
        logger.info(f"Tier2 escalated to Opus: handle={signal.source_handle}, score={result.fast_match_score:.2f}")
        await _escalate_signal(result, inbound, signal_db_id)
    else:
        await publish_drop_event(
            market_title=_get_market_title(result.matched_market_id),
            drop_reason=result.drop_reason or "below_escalation_threshold",
            source_handle=signal.source_handle,
            source_url=signal.url or "",
        )


async def _handle_tier3_signal(signal: Tier3Signal):
    """Route Tier 3 (HN) signals to FastMatch."""
    if not _fast_match:
        return
    inbound = InboundSignal(
        source_tier=3,
        source_handle=signal.source_handle,
        source_domain=signal.source_domain,
        raw_text=signal.raw_text,
        url=signal.url,
        timestamp=signal.timestamp,
    )
    result = await _fast_match.process(inbound)
    signal_db_id = await _fast_match.write_signal_to_db(result)
    if result.escalate_to_opus:
        logger.info(f"Tier3 escalated to Opus: hn_id={signal.source_handle}, score={result.fast_match_score:.2f}")
        await _escalate_signal(result, inbound, signal_db_id)
    else:
        await publish_drop_event(
            market_title=_get_market_title(result.matched_market_id),
            drop_reason=result.drop_reason or "below_escalation_threshold",
            source_handle=signal.source_handle,
            source_url=signal.url or "",
        )


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _polymarket, _social_poller, _hn_poller, _perplexity, _whitelist_cache, _fast_match, _opus_client, _anomaly_engine

    # Startup
    logger.info("Starting Brain service...")
    await init_db()
    await init_redis()

    # Initialize FastMatch engine
    _fast_match = FastMatchEngine(NARRATIVE_DICT_PATH, RESOLUTION_SCHEMAS_DIR)

    # Initialize whitelist cache
    _whitelist_cache = WhitelistCache()
    _whitelist_cache.load()

    # Initialize Perplexity client
    _perplexity = PerplexityClient()
    await _perplexity.initialize()

    # Initialize Opus client (Layer 2)
    _opus_client = OpusClient(perplexity_client=_perplexity)

    # Initialize anomaly engine (parallel fast mean-reversion detector)
    if settings.ANOMALY_ENABLED:
        from app.anomaly.engine import AnomalyEngine
        _anomaly_engine = AnomalyEngine(schemas_dir=RESOLUTION_SCHEMAS_DIR)
        await _anomaly_engine.start_rest_polling()
        await _anomaly_engine.start_stats_loop()
        logger.info(f"Anomaly engine initialized (phase={settings.ANOMALY_PHASE})")

    # Start Polymarket WebSocket ingestion
    _polymarket = PolymarketIngestion(
        schemas_dir=RESOLUTION_SCHEMAS_DIR,
        anomaly_engine=_anomaly_engine,
    )
    _polymarket.on_signal(_handle_tier1_signal)
    _background_tasks.append(asyncio.create_task(_polymarket.start()))

    # Start Social poller
    _social_poller = SocialPoller(whitelist_cache=_whitelist_cache)
    _social_poller.on_signal(_handle_tier2_signal)
    _background_tasks.append(asyncio.create_task(_social_poller.start()))

    # Start HN poller
    _hn_poller = HNPoller(narrative_dict_path=NARRATIVE_DICT_PATH)
    _hn_poller.on_signal(_handle_tier3_signal)
    _background_tasks.append(asyncio.create_task(_hn_poller.start()))

    # Start whitelist export scheduler
    _background_tasks.append(asyncio.create_task(scheduled_export_loop()))

    logger.info("Brain service started — all ingestion tiers active")
    yield

    # Shutdown
    logger.info("Shutting down Brain service...")

    # Stop all ingestion tiers
    if _polymarket:
        await _polymarket.stop()
    if _social_poller:
        await _social_poller.stop()
    if _hn_poller:
        await _hn_poller.stop()
    if _anomaly_engine:
        await _anomaly_engine.stop()
    if _perplexity:
        await _perplexity.close()

    # Cancel background tasks
    for task in _background_tasks:
        task.cancel()
    await asyncio.gather(*_background_tasks, return_exceptions=True)
    _background_tasks.clear()

    await close_redis()
    await close_db()
    logger.info("Brain service shut down")


app = FastAPI(title="AlphaClaw Brain", version="0.1.0", lifespan=lifespan)


@app.get("/health")
async def health():
    """Health check: DB, Redis, and ingestion status."""
    try:
        pool = await get_pool()
        redis = await get_redis()
        db_ok = await pool.fetchval("SELECT 1") == 1
        redis_ok = await redis.ping()
    except Exception:
        db_ok = False
        redis_ok = False

    return {
        "status": "ok" if (db_ok and redis_ok) else "degraded",
        "db": "connected" if db_ok else "disconnected",
        "redis": "connected" if redis_ok else "disconnected",
        "active_markets": len(_polymarket._market_ids) if _polymarket else 0,
        "whitelist_accounts": _whitelist_cache.count if _whitelist_cache else 0,
        "anomaly_engine": {
            "enabled": settings.ANOMALY_ENABLED,
            "phase": settings.ANOMALY_PHASE,
            "markets": _anomaly_engine.market_count if _anomaly_engine else 0,
        },
    }


@app.get("/metrics")
async def metrics():
    """Internal metrics endpoint: signal counts and engine state."""
    try:
        pool = await get_pool()
        signals_1h = await pool.fetchval(
            "SELECT COUNT(*) FROM signals WHERE created_at > NOW() - INTERVAL '1 hour'"
        )
        escalations_1h = await pool.fetchval(
            "SELECT COUNT(*) FROM signals WHERE escalated_to_opus = TRUE AND created_at > NOW() - INTERVAL '1 hour'"
        )
        drops = await pool.fetch(
            """
            SELECT drop_reason, COUNT(*) as cnt
            FROM signals
            WHERE drop_reason IS NOT NULL AND created_at > NOW() - INTERVAL '1 hour'
            GROUP BY drop_reason ORDER BY cnt DESC
            """
        )
    except Exception:
        return {"error": "database unavailable"}

    return {
        "signals_last_hour": signals_1h or 0,
        "escalations_last_hour": escalations_1h or 0,
        "drops_by_reason": {row["drop_reason"]: row["cnt"] for row in drops},
    }
