// PM2 ecosystem configuration for AlphaClaw Brain service
// Docs: https://pm2.keymetrics.io/docs/usage/application-declaration/

module.exports = {
    apps: [
        {
            name: "Brain",
            script: "/root/alphaclaw/services/brain/venv/bin/python",
            args: "-m uvicorn app.main:app --host 0.0.0.0 --port 8000",
            cwd: "/root/alphaclaw/services/brain",
            interpreter: "none",
            env: {
                // Anomaly Engine — Phase A (detect + log)
                ANOMALY_ENABLED: "True",
                ANOMALY_PHASE: "C",
                ANOMALY_Z_THRESHOLD: "0.5",
                ANOMALY_MIN_PRICE_DELTA: "0.01",
                ANOMALY_Z_WINDOW: "60",
                ANOMALY_COOLDOWN_SECONDS: "600",
                ANOMALY_REQUIRE_VOLUME: "False",
                ANOMALY_REQUIRE_DEPTH: "False",
                ANOMALY_STATS_INTERVAL_SECONDS: "60",
            },
            // Restart policy
            max_restarts: 10,
            restart_delay: 3000,
            // Logging
            log_date_format: "YYYY-MM-DD HH:mm:ss",
            merge_logs: true,
        },
    ],
};
