import pytest
from app.fastmatch.normalizer import normalize


class TestNormalizer:
    def test_url_stripping(self):
        """URLs must be fully removed, not tokenized"""
        tokens = normalize("Check https://example.com/path?q=1 for details")
        assert "https" not in tokens
        assert "example" not in tokens
        assert "com" not in tokens
        assert "check" in tokens
        assert "detail" in tokens  # lemmatized

    def test_hashtag_stripping(self):
        """Hashtags are removed entirely"""
        tokens = normalize("#Breaking news about #election")
        assert "breaking" not in tokens  # financial stopword
        assert "news" in tokens
        assert "election" in tokens

    def test_mention_stripping(self):
        """@mentions are removed"""
        tokens = normalize("@AP calls the race for Smith")
        assert "ap" not in tokens  # was a mention, stripped
        assert "call" in tokens  # lemmatized from "calls"
        assert "race" in tokens
        assert "smith" in tokens

    def test_adversarial_phrase_survival(self):
        """Key signal tokens survive normalization for AP race calls"""
        tokens = normalize("AP calls race for the winner in Texas")
        assert "ap" in tokens
        assert "call" in tokens  # lemmatized
        assert "race" in tokens
        assert "winner" in tokens
        assert "texas" in tokens

    def test_false_positive_adversarial_tokens(self):
        """Adversarial words like 'leading' survive as tokens (filtering is engine's job)"""
        tokens = normalize("AP sources say candidate is leading")
        assert "ap" in tokens
        assert "lead" in tokens  # lemmatized from "leading"
        # "sources" and "say" are stopwords/financial_stopwords

    def test_lemmatization_verbs(self):
        """Verbs are properly lemmatized"""
        tokens = normalize("raises called increasing filed")
        assert "raise" in tokens
        assert "call" in tokens
        assert "increase" in tokens
        assert "file" in tokens

    def test_lemmatization_nouns(self):
        """Plural nouns are lemmatized"""
        tokens = normalize("elections filings approvals")
        assert "election" in tokens
        assert "filing" in tokens
        assert "approval" in tokens

    def test_empty_string(self):
        """Empty string returns empty list"""
        assert normalize("") == []

    def test_none_input(self):
        """None input returns empty list"""
        assert normalize(None) == []

    def test_deduplication(self):
        """Duplicate tokens are removed, order preserved"""
        tokens = normalize("rate rate rate increase increase")
        assert tokens.count("rate") == 1
        assert tokens.count("increase") == 1
        assert tokens.index("rate") < tokens.index("increase")

    def test_stopword_removal(self):
        """Common English stopwords are removed"""
        tokens = normalize("the fed is going to raise the rate")
        assert "the" not in tokens
        assert "is" not in tokens
        assert "to" not in tokens
        assert "going" not in tokens or "go" in tokens  # lemmatized
        assert "fed" in tokens
        assert "raise" in tokens
        assert "rate" in tokens

    def test_financial_stopword_removal(self):
        """Financial stopwords are removed"""
        tokens = normalize("Sources said according to reports")
        # "sources", "said", "according", "report" are all financial/english stopwords
        assert len(tokens) == 0 or all(t not in {"source", "said", "according", "report"} for t in tokens)

    def test_real_signal_fed(self):
        """Real-world signal: Fed rate decision"""
        tokens = normalize("FOMC raises federal funds rate by 25 basis points to 5.50%")
        assert "fomc" in tokens
        assert "raise" in tokens
        assert "federal" in tokens
        assert "fund" in tokens or "funds" in tokens
        assert "rate" in tokens
        assert "basis" in tokens
        assert "point" in tokens

    def test_real_signal_ap_call(self):
        """Real-world signal: AP race call"""
        tokens = normalize("AP calls the Texas Senate race for Republican candidate Cruz")
        assert "ap" in tokens
        assert "call" in tokens
        assert "texas" in tokens
        assert "senate" in tokens
        assert "race" in tokens
        assert "republican" in tokens
