import pytest
import math
from unittest.mock import patch, MagicMock

from app.sizing.kelly import (
    normalize_zscore,
    calculate_composite_p,
    calculate_kelly_fraction,
    calculate_position,
)


class TestNormalizeZscore:
    def test_basic_normalization(self):
        """zscore of 2.5 with Z_SCORE_MAX=5.0 → 0.5"""
        assert normalize_zscore(2.5) == pytest.approx(0.5)

    def test_capped_at_one(self):
        """zscore exceeding Z_SCORE_MAX is capped at 1.0"""
        assert normalize_zscore(10.0) == 1.0

    def test_negative_zscore(self):
        """Negative z-score uses absolute value"""
        assert normalize_zscore(-3.0) == pytest.approx(0.6)

    def test_zero_zscore(self):
        assert normalize_zscore(0.0) == 0.0


class TestCompositeP:
    def test_basic_calculation(self):
        """opus=0.90, zscore=3.0 → 0.90×0.75 + (3/5)×0.25 = 0.675 + 0.15 = 0.825"""
        result = calculate_composite_p(0.90, 3.0)
        assert result == pytest.approx(0.825)

    def test_capped_at_one(self):
        """Composite p cannot exceed 1.0"""
        result = calculate_composite_p(1.0, 10.0)
        assert result <= 1.0


class TestKellyFraction:
    def test_profitable_bet(self):
        """composite_p=0.87, market_price=0.31 → positive Kelly"""
        kelly = calculate_kelly_fraction(0.87, 0.31)
        # b = (1/0.31) - 1 = 2.2258
        # kelly = (0.87 * 2.2258 - 0.13) / 2.2258 = (1.9364 - 0.13) / 2.2258 ≈ 0.8116
        assert kelly > 0
        assert kelly == pytest.approx(0.8116, abs=0.01)

    def test_unprofitable_bet(self):
        """Low confidence, high price → negative Kelly → returns 0.0"""
        kelly = calculate_kelly_fraction(0.30, 0.90)
        assert kelly == 0.0

    def test_edge_market_price_zero(self):
        """Market price of 0.0 → returns 0.0 (division by zero protection)"""
        assert calculate_kelly_fraction(0.90, 0.0) == 0.0

    def test_edge_market_price_one(self):
        """Market price of 1.0 → returns 0.0"""
        assert calculate_kelly_fraction(0.90, 1.0) == 0.0


class TestCalculatePosition:
    def test_standard_calculation(self):
        """composite_p=0.87, market_price=0.31, wallet=$1000"""
        position = calculate_position(0.87, 0.31, 1000.0)
        assert position > 0
        assert position <= 50.0  # 5% cap = $50
        assert position == round(position, 2)

    def test_never_exceeds_five_percent(self):
        """Position never exceeds 5% of wallet regardless of inputs"""
        position = calculate_position(0.99, 0.01, 1000.0)
        assert position <= 50.0  # 5% of $1000

    def test_zero_if_below_min_composite_p(self):
        """composite_p < 0.80 → returns 0.0"""
        position = calculate_position(0.79, 0.50, 1000.0)
        assert position == 0.0

    def test_zero_on_dust_trade(self):
        """If Kelly produces very small position below $5 floor → returns 0.0"""
        # Very small wallet = dust trade
        position = calculate_position(0.81, 0.79, 50.0)
        # With such a low edge, quarter-Kelly on $50 will be tiny
        assert position == 0.0 or position >= 5.0

    def test_negative_kelly_returns_zero(self):
        """If bet is unprofitable, returns 0.0 — never negative"""
        position = calculate_position(0.81, 0.95, 1000.0)
        assert position >= 0.0

    def test_rounded_to_two_decimals(self):
        """Position is always rounded to 2 decimal places"""
        position = calculate_position(0.90, 0.30, 1000.0)
        if position > 0:
            assert position == round(position, 2)

    def test_exact_min_composite_p_boundary(self):
        """composite_p = exactly 0.80 should still produce a position if profitable"""
        position = calculate_position(0.80, 0.30, 1000.0)
        # 0.80 >= 0.80 (MIN_COMPOSITE_P), so this should work if the bet is profitable
        # b = (1/0.30) - 1 = 2.333
        # kelly = (0.80*2.333 - 0.20) / 2.333 = (1.867-0.20)/2.333 ≈ 0.714 > 0
        assert position > 0 or position == 0.0  # Could be 0 if below floor
