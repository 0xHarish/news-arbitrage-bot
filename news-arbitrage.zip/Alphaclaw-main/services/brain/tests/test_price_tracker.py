"""
Unit tests for app.shadow.price_tracker
"""

import asyncio
from datetime import datetime, timezone, timedelta
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

import app.shadow.price_tracker as pt


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_row(
    *,
    created_at: datetime,
    side: str = "YES",
    entry_price: float = 0.50,
    price_15m: float | None = None,
    price_1h: float | None = None,
    price_24h: float | None = None,
    max_favorable: float | None = None,
    max_adverse: float | None = None,
    tracking_status: str = "PENDING",
) -> MagicMock:
    """Build a MagicMock that behaves like an asyncpg.Record."""
    data = {
        "id": uuid4(),
        "created_at": created_at,
        "market_id": "market-abc",
        "side": side,
        "entry_price": entry_price,
        "price_15m": price_15m,
        "price_1h": price_1h,
        "price_24h": price_24h,
        "max_favorable": max_favorable,
        "max_adverse": max_adverse,
        "tracking_status": tracking_status,
    }
    row = MagicMock()
    row.__getitem__ = MagicMock(side_effect=lambda k: data[k])
    return row


def _mock_pool(execute_mock: AsyncMock | None = None) -> AsyncMock:
    pool = AsyncMock()
    pool.execute = execute_mock or AsyncMock()
    pool.fetch = AsyncMock(return_value=[])
    return pool


# ---------------------------------------------------------------------------
# Test 1: Market resolves YES at T+3h
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_market_resolves_at_3h():
    now = datetime.now(timezone.utc)
    created_at = now - timedelta(hours=3)

    row = _make_row(
        created_at=created_at,
        side="YES",
        entry_price=0.60,
        price_15m=0.62,
        price_1h=0.65,
        price_24h=None,
    )

    execute_calls: list[tuple] = []

    async def fake_execute(sql: str, *args):
        execute_calls.append((sql.strip(), args))

    mock_pool = _mock_pool(execute_mock=AsyncMock(side_effect=fake_execute))

    resolution = {
        "resolved": True,
        "settlement_price": 1.0,
        "resolved_at": "2025-01-01T06:00:00Z",
    }

    with patch("app.shadow.price_tracker.get_pool", return_value=mock_pool), \
         patch("app.shadow.price_tracker.fetch_market_resolution",
               new=AsyncMock(return_value=resolution)), \
         patch("app.shadow.price_tracker.fetch_mid_price",
               new=AsyncMock(return_value=None)):

        await pt.process_shadow_row(row)

    settlement_update = next(
        (c for c in execute_calls if "price_24h" in c[0] and "settlement" in c[0]),
        None,
    )
    assert settlement_update is not None, "Expected a settlement price_24h update"
    args = settlement_update[1]
    assert args[0] == 1.0
    assert args[1] is True  # resolved_before_24h

    complete_update = next(
        (c for c in execute_calls if "COMPLETE" in c[0]),
        None,
    )
    assert complete_update is not None, "Expected tracking_status='COMPLETE' update"


# ---------------------------------------------------------------------------
# Test 2: Market still active at T+25h
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_market_active_at_25h():
    now = datetime.now(timezone.utc)
    created_at = now - timedelta(hours=25)

    row = _make_row(
        created_at=created_at,
        side="YES",
        entry_price=0.50,
        price_15m=0.51,
        price_1h=0.53,
        price_24h=None,
    )

    execute_calls: list[tuple] = []

    async def fake_execute(sql: str, *args):
        execute_calls.append((sql.strip(), args))

    mock_pool = _mock_pool(execute_mock=AsyncMock(side_effect=fake_execute))

    resolution = {"resolved": False, "settlement_price": None, "resolved_at": None}

    with patch("app.shadow.price_tracker.get_pool", return_value=mock_pool), \
         patch("app.shadow.price_tracker.fetch_market_resolution",
               new=AsyncMock(return_value=resolution)), \
         patch("app.shadow.price_tracker.fetch_mid_price",
               new=AsyncMock(return_value=0.58)):

        await pt.process_shadow_row(row)

    midprice_update = next(
        (c for c in execute_calls if "price_24h" in c[0] and "midprice" in c[0]),
        None,
    )
    assert midprice_update is not None, "Expected a midprice price_24h update"
    args = midprice_update[1]
    assert args[0] == 0.58


# ---------------------------------------------------------------------------
# Test 3: MFE/MAE tracking
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_mfe_mae_yes_side():
    now = datetime.now(timezone.utc)
    created_at = now - timedelta(hours=2)

    row = _make_row(
        created_at=created_at,
        side="YES",
        entry_price=0.40,
        price_15m=0.42,
        price_1h=0.44,
        price_24h=None,
        max_favorable=None,
        max_adverse=None,
    )

    mfe_args: list = []

    async def fake_execute(sql: str, *args):
        if "max_favorable" in sql:
            mfe_args.extend(args)

    mock_pool = _mock_pool(execute_mock=AsyncMock(side_effect=fake_execute))

    resolution = {"resolved": False, "settlement_price": None, "resolved_at": None}

    with patch("app.shadow.price_tracker.get_pool", return_value=mock_pool), \
         patch("app.shadow.price_tracker.fetch_market_resolution",
               new=AsyncMock(return_value=resolution)), \
         patch("app.shadow.price_tracker.fetch_mid_price",
               new=AsyncMock(return_value=0.55)):

        await pt.process_shadow_row(row)

    assert len(mfe_args) >= 1, "Expected MFE/MAE update to be called"
    assert mfe_args[0] >= 0.15, f"Expected max_favorable >= 0.15, got {mfe_args[0]}"


# ---------------------------------------------------------------------------
# Test 4: API error — no crash, no update
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_fetch_mid_price_api_error_no_crash():
    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)
        mock_client.get = AsyncMock(side_effect=Exception("connection refused"))
        mock_client_cls.return_value = mock_client

        result = await pt.fetch_mid_price("market-xyz")

    assert result is None

    now = datetime.now(timezone.utc)
    created_at = now - timedelta(minutes=20)

    row = _make_row(
        created_at=created_at,
        side="YES",
        entry_price=0.50,
        price_15m=None,
        price_1h=None,
        price_24h=None,
    )

    execute_called = False

    async def fake_execute(sql: str, *args):
        nonlocal execute_called
        execute_called = True

    mock_pool = _mock_pool(execute_mock=AsyncMock(side_effect=fake_execute))

    resolution = {"resolved": False, "settlement_price": None, "resolved_at": None}

    with patch("app.shadow.price_tracker.get_pool", return_value=mock_pool), \
         patch("app.shadow.price_tracker.fetch_market_resolution",
               new=AsyncMock(return_value=resolution)), \
         patch("app.shadow.price_tracker.fetch_mid_price",
               new=AsyncMock(return_value=None)):

        await pt.process_shadow_row(row)

    assert not execute_called, "Expected no DB update when mid-price fetch fails"


# ---------------------------------------------------------------------------
# Test 5: COMPLETE rows are excluded by the query
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_complete_rows_not_fetched():
    mock_pool = AsyncMock()
    mock_pool.fetch = AsyncMock(return_value=[])

    process_called = False

    async def fake_process(row):
        nonlocal process_called
        process_called = True

    with patch("app.shadow.price_tracker.get_pool", return_value=mock_pool), \
         patch("app.shadow.price_tracker.process_shadow_row",
               new=AsyncMock(side_effect=fake_process)), \
         patch("asyncio.sleep", new=AsyncMock(side_effect=asyncio.CancelledError)):

        try:
            await pt.track_shadow_trades()
        except asyncio.CancelledError:
            pass

    fetch_call_args = mock_pool.fetch.call_args
    assert fetch_call_args is not None
    sql = fetch_call_args[0][0]
    assert "tracking_status" in sql
    assert "COMPLETE" in sql

    assert not process_called
