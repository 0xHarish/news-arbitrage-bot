import pytest
import json
from datetime import datetime, timezone, timedelta
from unittest.mock import AsyncMock, patch, MagicMock
from pathlib import Path

# ---------------------------------------------------------------------------
# Test fixtures: narrative dictionary and resolution schema
# ---------------------------------------------------------------------------

TEST_NARRATIVE_DICT = {
    "version": "1.0.0",
    "last_updated": "2026-02-24",
    "categories": {
        "macro_fed": {
            "id": "macro_fed",
            "label": "FOMC Rate Decisions",
            "market_tags": ["fed", "fomc", "rate", "interest"],
            "resolution_signals": [
                {
                    "signal_id": "rs_fed_official",
                    "label": "Federal Reserve Official",
                    "weight": 1.0,
                    "source_domains": ["federalreserve.gov"],
                    "canonical_tokens": ["fomc", "rate"],
                    "regex_patterns": ["federal funds rate", "FOMC"],
                    "minimum_sources": 1
                },
                {
                    "signal_id": "rs_wsj",
                    "label": "WSJ Confirmation",
                    "weight": 0.9,
                    "source_domains": ["wsj.com"],
                    "canonical_tokens": ["rate", "raise"],
                    "regex_patterns": ["rate.*raise|raise.*rate"],
                    "minimum_sources": 1
                }
            ],
            "adversarial_patterns": ["may raise", "expected to", "sources say"],
            "minimum_independent_sources": 2,
            "golden_window_seconds": 600
        }
    }
}

TEST_RESOLUTION_SCHEMA = {
    "market_id": "0xfed_march2026",
    "condition_id": "0xfed_march2026",
    "title": "Will the Fed raise rates at March 2026 FOMC?",
    "category_id": "macro_fed",
    "resolution_source": "federalreserve.gov",
    "resolution_criteria": "Resolves YES if FOMC raises rate",
    "key_entities": [
        {"name": "Federal Reserve", "aliases": ["Fed", "FOMC"]},
        {"name": "Federal Funds Rate", "aliases": ["rate"]}
    ],
    "threshold_conditions": [
        {
            "condition_id": "tc_yes",
            "outcome": "YES",
            "required_tokens": ["fomc", "raise", "rate"],
            "forbidden_tokens": ["hold", "cut"],
            "authoritative_sources": ["federalreserve.gov"],
            "minimum_sources": 2
        }
    ],
    "oracle_contract": "0x123",
    "expiry_timestamp": 1742500000,
    "created_at": "2026-02-24T00:00:00Z"
}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def engine_data(tmp_path):
    """Create temporary narrative dict and resolution schema files."""
    # Write narrative dict
    nd_path = tmp_path / "narrative_dict.json"
    nd_path.write_text(json.dumps(TEST_NARRATIVE_DICT))

    # Write resolution schema
    schemas_dir = tmp_path / "resolution_schemas"
    schemas_dir.mkdir()
    schema_path = schemas_dir / "0xfed_march2026.json"
    schema_path.write_text(json.dumps(TEST_RESOLUTION_SCHEMA))

    return str(nd_path), str(schemas_dir)


@pytest.fixture
def engine(engine_data):
    from app.fastmatch.engine import FastMatchEngine
    nd_path, schemas_dir = engine_data
    return FastMatchEngine(nd_path, schemas_dir)


# ---------------------------------------------------------------------------
# Helper: build a mock pool that always returns False for oracle dispute check
# ---------------------------------------------------------------------------

def _mock_pool(fetchval_return=False):
    """Return a mock asyncpg pool with fetchval pre-configured."""
    pool = AsyncMock()
    pool.fetchval = AsyncMock(return_value=fetchval_return)
    pool.fetchrow = AsyncMock(return_value=None)
    return pool


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_signal_with_matching_tokens_escalates(engine):
    """
    A well-formed FOMC signal whose tokens match both resolution signals
    should achieve score >= 0.6 and set escalate_to_opus=True.
    """
    from app.fastmatch.engine import InboundSignal

    signal = InboundSignal(
        source_tier=2,
        source_handle="@fedwatcher",
        source_domain="wsj.com",
        raw_text="FOMC raises federal funds rate by 25 basis points",
        timestamp=datetime.now(timezone.utc),
        zscore=3.1,
    )

    # normalize returns tokens that overlap with market_tags AND canonical_tokens
    mock_tokens = ["fomc", "raise", "federal", "funds", "rate", "basis", "points"]

    mock_pool = _mock_pool(fetchval_return=False)

    with patch("app.fastmatch.normalizer.normalize", return_value=mock_tokens), \
         patch("app.db.get_pool", return_value=mock_pool), \
         patch("app.config.settings") as mock_settings:

        mock_settings.Z_SCORE_THRESHOLD = 2.5
        mock_settings.FAST_MATCH_ESCALATION_THRESHOLD = 0.60

        result = await engine.process(signal)

    assert result.fast_match_score >= 0.6, (
        f"Expected score >= 0.6, got {result.fast_match_score}"
    )
    assert result.escalate_to_opus is True
    assert result.drop_reason is None


@pytest.mark.asyncio
async def test_adversarial_pattern_drops(engine):
    """
    A signal containing an adversarial pattern ('sources say') must be
    dropped with a drop_reason that starts with 'adversarial_pattern:'.
    """
    from app.fastmatch.engine import InboundSignal

    signal = InboundSignal(
        source_tier=2,
        source_handle="@rumourmill",
        source_domain="twitter.com",
        raw_text="sources say Fed may raise rates next meeting",
        timestamp=datetime.now(timezone.utc),
    )

    mock_tokens = ["sources", "say", "fed", "may", "raise", "rates", "meeting"]
    mock_pool = _mock_pool(fetchval_return=False)

    with patch("app.fastmatch.normalizer.normalize", return_value=mock_tokens), \
         patch("app.db.get_pool", return_value=mock_pool), \
         patch("app.config.settings") as mock_settings:

        mock_settings.Z_SCORE_THRESHOLD = 2.5
        mock_settings.FAST_MATCH_ESCALATION_THRESHOLD = 0.60

        result = await engine.process(signal)

    assert result.drop_reason is not None
    assert result.drop_reason.startswith("adversarial_pattern:"), (
        f"Expected adversarial_pattern drop, got: {result.drop_reason}"
    )
    assert result.escalate_to_opus is False


@pytest.mark.asyncio
async def test_oracle_dispute_drops(engine):
    """
    When the DB reports an active oracle dispute for the matched market,
    the signal must be dropped with drop_reason='active_oracle_dispute'.
    """
    from app.fastmatch.engine import InboundSignal

    signal = InboundSignal(
        source_tier=2,
        source_handle="@fedwatcher",
        source_domain="wsj.com",
        raw_text="FOMC raises federal funds rate by 25 basis points",
        timestamp=datetime.now(timezone.utc),
        zscore=3.1,
    )

    mock_tokens = ["fomc", "raise", "federal", "funds", "rate", "basis", "points"]
    # fetchval returns True — active dispute exists
    mock_pool = _mock_pool(fetchval_return=True)

    with patch("app.fastmatch.normalizer.normalize", return_value=mock_tokens), \
         patch("app.db.get_pool", return_value=mock_pool), \
         patch("app.config.settings") as mock_settings:

        mock_settings.Z_SCORE_THRESHOLD = 2.5
        mock_settings.FAST_MATCH_ESCALATION_THRESHOLD = 0.60

        result = await engine.process(signal)

    assert result.drop_reason == "active_oracle_dispute"
    assert result.escalate_to_opus is False


@pytest.mark.asyncio
async def test_golden_window_expired_drops(engine):
    """
    A signal whose timestamp is older than the category's golden_window_seconds
    (600 s for macro_fed) must be dropped with drop_reason='outside_golden_window'.
    """
    from app.fastmatch.engine import InboundSignal

    # Timestamp is 700 seconds in the past — beyond the 600 s window
    stale_timestamp = datetime.now(timezone.utc) - timedelta(seconds=700)

    signal = InboundSignal(
        source_tier=2,
        source_handle="@latereporter",
        source_domain="wsj.com",
        raw_text="FOMC raises federal funds rate by 25 basis points",
        timestamp=stale_timestamp,
        zscore=3.5,
    )

    mock_tokens = ["fomc", "raise", "federal", "funds", "rate", "basis", "points"]
    mock_pool = _mock_pool(fetchval_return=False)

    with patch("app.fastmatch.normalizer.normalize", return_value=mock_tokens), \
         patch("app.db.get_pool", return_value=mock_pool), \
         patch("app.config.settings") as mock_settings:

        mock_settings.Z_SCORE_THRESHOLD = 2.5
        mock_settings.FAST_MATCH_ESCALATION_THRESHOLD = 0.60

        result = await engine.process(signal)

    assert result.drop_reason == "outside_golden_window"
    assert result.escalate_to_opus is False


@pytest.mark.asyncio
async def test_tier1_zscore_below_threshold_drops(engine):
    """
    A Tier 1 signal with zscore=1.5 (below the threshold of 2.5) must be
    dropped with drop_reason='zscore_below_threshold'.
    """
    from app.fastmatch.engine import InboundSignal

    signal = InboundSignal(
        source_tier=1,  # Tier 1 = polymarket — z-score gate applies
        source_handle="polymarket",
        source_domain="polymarket.com",
        raw_text="FOMC raises federal funds rate by 25 basis points",
        timestamp=datetime.now(timezone.utc),
        zscore=1.5,  # Below threshold of 2.5
    )

    mock_tokens = ["fomc", "raise", "federal", "funds", "rate", "basis", "points"]
    mock_pool = _mock_pool(fetchval_return=False)

    with patch("app.fastmatch.normalizer.normalize", return_value=mock_tokens), \
         patch("app.db.get_pool", return_value=mock_pool), \
         patch("app.config.settings") as mock_settings:

        mock_settings.Z_SCORE_THRESHOLD = 2.5
        mock_settings.FAST_MATCH_ESCALATION_THRESHOLD = 0.60

        result = await engine.process(signal)

    assert result.drop_reason == "zscore_below_threshold"
    assert result.escalate_to_opus is False


@pytest.mark.asyncio
async def test_score_below_escalation_threshold(engine):
    """
    A signal that partially matches (only the lower-weight rs_wsj signal fires,
    yielding score ≈ 0.47) should not be escalated and should have
    drop_reason='score_below_escalation_threshold'.
    """
    from app.fastmatch.engine import InboundSignal

    signal = InboundSignal(
        source_tier=2,
        source_handle="@partialreporter",
        source_domain="wsj.com",
        # Text does NOT contain "FOMC" so rs_fed_official regex won't match,
        # but does trigger the raise.*rate pattern for rs_wsj
        raw_text="The central bank will raise rate by 25bps",
        timestamp=datetime.now(timezone.utc),
    )

    # Tokens match market_tags (rate) for category match, and rs_wsj canonical
    # tokens [rate, raise], but NOT rs_fed_official canonical tokens [fomc, rate]
    mock_tokens = ["central", "bank", "raise", "rate"]
    mock_pool = _mock_pool(fetchval_return=False)

    with patch("app.fastmatch.normalizer.normalize", return_value=mock_tokens), \
         patch("app.db.get_pool", return_value=mock_pool), \
         patch("app.config.settings") as mock_settings:

        mock_settings.Z_SCORE_THRESHOLD = 2.5
        mock_settings.FAST_MATCH_ESCALATION_THRESHOLD = 0.60

        result = await engine.process(signal)

    # rs_wsj weight=0.9, total_weight=1.0+0.9=1.9 → score=0.9/1.9≈0.47 < 0.60
    assert result.fast_match_score < 0.60, (
        f"Expected score < 0.60, got {result.fast_match_score}"
    )
    assert result.escalate_to_opus is False
    assert result.drop_reason == "score_below_escalation_threshold"


@pytest.mark.asyncio
async def test_no_category_match_drops(engine):
    """
    A signal with tokens completely unrelated to any category must be
    dropped with drop_reason='no_category_match'.
    """
    from app.fastmatch.engine import InboundSignal

    signal = InboundSignal(
        source_tier=2,
        source_handle="@sportsdesk",
        source_domain="espn.com",
        raw_text="The home team wins the championship after a dramatic overtime",
        timestamp=datetime.now(timezone.utc),
    )

    # Tokens share no overlap with any market_tags in TEST_NARRATIVE_DICT
    mock_tokens = ["home", "team", "wins", "championship", "dramatic", "overtime"]
    mock_pool = _mock_pool(fetchval_return=False)

    with patch("app.fastmatch.normalizer.normalize", return_value=mock_tokens), \
         patch("app.db.get_pool", return_value=mock_pool), \
         patch("app.config.settings") as mock_settings:

        mock_settings.Z_SCORE_THRESHOLD = 2.5
        mock_settings.FAST_MATCH_ESCALATION_THRESHOLD = 0.60

        result = await engine.process(signal)

    assert result.drop_reason == "no_category_match"
    assert result.matched_category_id is None
    assert result.escalate_to_opus is False
