import math
import pytest
from app.fastmatch.zscore import RollingZScore


class TestRollingZScore:
    def test_returns_zero_during_warmup(self):
        """Z-score is 0.0 until window is full AND the next value arrives."""
        rz = RollingZScore(window=5)
        # First 5 values fill the window — all return 0.0
        for i in range(5):
            assert rz.update(float(i)) == 0.0
        # 6th value is the first scored against the full previous window
        result = rz.update(10.0)
        assert isinstance(result, float)
        assert result != 0.0

    def test_zero_zscore_identical_values(self):
        """All identical values => z-score of 0 (zero variance)"""
        rz = RollingZScore(window=5)
        for _ in range(5):
            rz.update(42.0)
        # Window full of 42.0. Next 42.0 → variance=0 → z=0
        z = rz.update(42.0)
        assert z == 0.0

    def test_known_zscore(self):
        """Z-score of a new value against a known previous window."""
        rz = RollingZScore(window=5)
        window_values = [10.0, 12.0, 14.0, 16.0, 18.0]
        for v in window_values:
            rz.update(v)
        # 6th value scored against [10,12,14,16,18]:
        # mean = 14.0, variance = 8.0, std = sqrt(8)
        z = rz.update(20.0)
        expected = (20.0 - 14.0) / math.sqrt(8.0)
        assert abs(z - expected) < 0.001

    def test_zscore_excludes_new_value(self):
        """The new value must NOT be included in mean/std calculation."""
        rz = RollingZScore(window=5)
        for v in [10.0, 10.0, 10.0, 10.0, 10.0]:
            rz.update(v)
        # Window: [10,10,10,10,10]. variance=0 → z=0 even for outlier
        z = rz.update(100.0)
        assert z == 0.0  # can't score against zero-variance window
        # But now window is [10,10,10,10,100] — nonzero variance
        z = rz.update(100.0)
        assert z > 0  # previous window has variance, outlier detected

    def test_sliding_window_drops_old(self):
        """After window fills, old values are dropped as window slides."""
        rz = RollingZScore(window=3)
        rz.update(100.0)
        rz.update(100.0)
        rz.update(100.0)
        # Window: [100,100,100]. Next 100 → std=0 → z=0
        z = rz.update(100.0)
        assert z == 0.0
        # First diverging tick against flat window → z=0 (zero variance)
        z = rz.update(200.0)
        assert z == 0.0
        # Window is now [100,100,200] — has variance. Next 200 is positive z
        z = rz.update(200.0)
        assert z > 0

    def test_no_nan_or_inf(self):
        """No NaN or Inf on extreme inputs"""
        rz = RollingZScore(window=5)
        extreme_values = [1e15, -1e15, 1e15, -1e15, 0.0]
        for v in extreme_values:
            z = rz.update(v)
            assert not math.isnan(z)
            assert not math.isinf(z)
        # One more after warmup
        z = rz.update(1e15)
        assert not math.isnan(z)
        assert not math.isinf(z)

    def test_reset_clears_state(self):
        """reset() clears all rolling state"""
        rz = RollingZScore(window=5)
        for i in range(10):
            rz.update(float(i))
        rz.reset()
        # After reset, should return 0 again (window not filled)
        assert rz.update(42.0) == 0.0
        assert rz.update(42.0) == 0.0

    def test_negative_zscore(self):
        """Value below the mean produces negative z-score."""
        rz = RollingZScore(window=5)
        for v in [10.0, 20.0, 30.0, 40.0, 50.0]:
            rz.update(v)
        # 6th value well below window mean (30.0) → negative z
        z = rz.update(5.0)
        assert z < 0

    def test_default_window_is_50(self):
        """Default window size is 50"""
        rz = RollingZScore()
        assert rz.window == 50

    def test_is_warmed(self):
        """is_warmed becomes True once window is filled."""
        rz = RollingZScore(window=3)
        assert not rz.is_warmed
        rz.update(1.0)
        assert not rz.is_warmed
        rz.update(2.0)
        assert not rz.is_warmed
        rz.update(3.0)
        assert rz.is_warmed  # window full after 3rd value
        rz.update(4.0)
        assert rz.is_warmed  # stays warmed

    def test_fill_count(self):
        """fill_count tracks how many values are in the window."""
        rz = RollingZScore(window=3)
        assert rz.fill_count == 0
        rz.update(1.0)
        assert rz.fill_count == 1
        rz.update(2.0)
        assert rz.fill_count == 2
        rz.update(3.0)
        assert rz.fill_count == 3
        rz.update(4.0)
        assert rz.fill_count == 3  # capped at window size
