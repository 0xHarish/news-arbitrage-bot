import json
import pytest
import os
from pathlib import Path
from datetime import datetime, timezone, timedelta
from unittest.mock import AsyncMock, patch, MagicMock

from app.whitelist.exporter import (
    export_snapshot,
    WhitelistCache,
    WhitelistAccount,
    _alert_admin,
)


@pytest.fixture
def whitelist_dir(tmp_path):
    """Create a temporary directory for whitelist files."""
    return tmp_path


@pytest.fixture
def sample_whitelist_file(whitelist_dir):
    """Create a sample whitelist JSON file."""
    data = {
        "exported_at": "2026-02-24T00:00:00Z",
        "count": 5,
        "accounts": [
            {"handle": "@AP", "category_ids": ["us_election_2026"], "trust_weight": 0.95},
            {"handle": "@Reuters", "category_ids": ["geopolitical_ceasefire"], "trust_weight": 0.90},
            {"handle": "@SECGov", "category_ids": ["crypto_regulatory"], "trust_weight": 0.95},
            {"handle": "@federalreserve", "category_ids": ["macro_fed"], "trust_weight": 0.95},
            {"handle": "@ESPN", "category_ids": ["sports_championship"], "trust_weight": 0.80},
        ]
    }
    path = whitelist_dir / "whitelist.json"
    path.write_text(json.dumps(data))
    return path


class TestWhitelistCache:
    def test_load_from_file(self, sample_whitelist_file):
        cache = WhitelistCache(sample_whitelist_file)
        count = cache.load()
        assert count == 5

    def test_get_by_handle(self, sample_whitelist_file):
        cache = WhitelistCache(sample_whitelist_file)
        cache.load()
        account = cache.get("@AP")
        assert account is not None
        assert account.handle == "@AP"
        assert account.trust_weight == 0.95
        assert "us_election_2026" in account.category_ids

    def test_get_case_insensitive(self, sample_whitelist_file):
        cache = WhitelistCache(sample_whitelist_file)
        cache.load()
        assert cache.get("@ap") is not None
        assert cache.get("@AP") is not None
        assert cache.get("@Ap") is not None

    def test_get_without_at_prefix(self, sample_whitelist_file):
        cache = WhitelistCache(sample_whitelist_file)
        cache.load()
        assert cache.get("AP") is not None
        assert cache.get("ap") is not None

    def test_get_unknown_handle(self, sample_whitelist_file):
        cache = WhitelistCache(sample_whitelist_file)
        cache.load()
        assert cache.get("@unknown_handle") is None

    def test_reload_if_stale(self, sample_whitelist_file):
        cache = WhitelistCache(sample_whitelist_file)
        cache.load()
        # Not stale yet
        assert cache.reload_if_stale(max_age_seconds=300) is False
        # Force stale
        cache._loaded_at = datetime.now(timezone.utc) - timedelta(seconds=400)
        assert cache.reload_if_stale(max_age_seconds=300) is True

    def test_load_nonexistent_file(self, whitelist_dir):
        cache = WhitelistCache(whitelist_dir / "nonexistent.json")
        count = cache.load()
        assert count == 0

    def test_contains(self, sample_whitelist_file):
        cache = WhitelistCache(sample_whitelist_file)
        cache.load()
        assert cache.contains("@AP") is True
        assert cache.contains("@nobody") is False


class TestExportSnapshot:
    @pytest.mark.asyncio
    async def test_empty_export_aborts(self):
        """If DB returns 0 rows, export should abort."""
        mock_pool = AsyncMock()
        mock_pool.fetch.return_value = []
        mock_pool.execute = AsyncMock()

        with patch("app.whitelist.exporter.get_pool", return_value=mock_pool):
            result = await export_snapshot(Path("/tmp/test_whitelist.json"))
            assert result is False

    @pytest.mark.asyncio
    async def test_shrink_guard_aborts(self, whitelist_dir):
        """If new count is <50% of previous, export should abort."""
        # Create existing file with 100 accounts
        existing = {
            "count": 100,
            "exported_at": "2026-02-24T00:00:00Z",
            "accounts": [{"handle": f"@user{i}", "category_ids": [], "trust_weight": 0.5} for i in range(100)]
        }
        output_path = whitelist_dir / "whitelist.json"
        output_path.write_text(json.dumps(existing))

        # Mock DB returning only 10 rows
        mock_rows = [
            {"handle": f"@user{i}", "category_ids": '["macro_fed"]', "trust_weight": 0.5, "is_active": True, "notes": None}
            for i in range(10)
        ]
        mock_pool = AsyncMock()
        mock_pool.fetch.return_value = mock_rows
        mock_pool.execute = AsyncMock()

        with patch("app.whitelist.exporter.get_pool", return_value=mock_pool):
            result = await export_snapshot(output_path)
            assert result is False

    @pytest.mark.asyncio
    async def test_successful_export(self, whitelist_dir):
        """Successful export writes file atomically."""
        output_path = whitelist_dir / "whitelist.json"

        mock_rows = [
            {"handle": "@AP", "category_ids": '["us_election"]', "trust_weight": 0.95, "is_active": True, "notes": None},
            {"handle": "@Reuters", "category_ids": '["geopolitical"]', "trust_weight": 0.90, "is_active": True, "notes": None},
        ]
        mock_pool = AsyncMock()
        mock_pool.fetch.return_value = mock_rows
        mock_pool.execute = AsyncMock()

        with patch("app.whitelist.exporter.get_pool", return_value=mock_pool):
            result = await export_snapshot(output_path)
            assert result is True
            assert output_path.exists()

            data = json.loads(output_path.read_text())
            assert data["count"] == 2
            assert len(data["accounts"]) == 2

    @pytest.mark.asyncio
    async def test_atomic_write_no_tmp_left(self, whitelist_dir):
        """After successful export, .tmp.json file should not exist."""
        output_path = whitelist_dir / "whitelist.json"
        tmp_path = whitelist_dir / "whitelist.tmp.json"

        mock_rows = [
            {"handle": "@AP", "category_ids": '["test"]', "trust_weight": 0.95, "is_active": True, "notes": None},
        ]
        mock_pool = AsyncMock()
        mock_pool.fetch.return_value = mock_rows
        mock_pool.execute = AsyncMock()

        with patch("app.whitelist.exporter.get_pool", return_value=mock_pool):
            await export_snapshot(output_path)
            assert not tmp_path.exists()
