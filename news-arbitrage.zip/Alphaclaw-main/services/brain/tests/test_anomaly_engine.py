"""
Tests for the Anomaly Engine (Phase A).

Covers:
  - Detection pipeline: warmup → z-score → trigger → DB write
  - ANOMALY_REQUIRE_VOLUME flag behaviour
  - ANOMALY_REQUIRE_DEPTH flag behaviour
  - Stats dump timing
  - would_trade logic with/without bid/ask data
"""
import json
import math
import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_schema(market_id: str, yes_token: str = "YES_TOKEN", no_token: str = "NO_TOKEN"):
    """Create a minimal resolution schema dict."""
    return {
        "condition_id": market_id,
        "market_id": market_id,
        "title": f"Test market {market_id}",
        "clob_tokens": {"YES": yes_token, "NO": no_token},
    }


def _write_schema(tmp_path, market_id: str, **kwargs):
    """Write a resolution schema JSON file and return the schemas dir."""
    schemas_dir = tmp_path / "resolution_schemas"
    schemas_dir.mkdir(exist_ok=True)
    fname = market_id.replace("0x", "")[:20] + ".json"
    schema = _make_schema(market_id, **kwargs)
    (schemas_dir / fname).write_text(json.dumps(schema))
    return str(schemas_dir)


def _default_settings(**overrides):
    """Return a mock settings object with sensible Phase A defaults."""
    defaults = {
        "ANOMALY_ENABLED": True,
        "ANOMALY_PHASE": "A",
        "ANOMALY_Z_THRESHOLD": 2.0,
        "ANOMALY_Z_WINDOW": 5,           # Small window for fast tests
        "ANOMALY_MIN_PRICE_DELTA": 0.02,
        "ANOMALY_WALLET_EXPOSURE": 0.005,
        "ANOMALY_COOLDOWN_SECONDS": 600,
        "ANOMALY_MAX_SLIPPAGE_BPS": 80,
        "ANOMALY_MIN_VOLUME_24H": 5000.0,
        "ANOMALY_MIN_DEPTH": 500.0,
        "ANOMALY_MAX_SPREAD": 0.05,
        "ANOMALY_LIMIT_OFFSET": 0.01,
        "ANOMALY_EXPIRES_SECONDS": 300,
        "ANOMALY_STATS_INTERVAL_SECONDS": 60,
        "ANOMALY_REQUIRE_VOLUME": False,
        "ANOMALY_REQUIRE_DEPTH": False,
        "POLYMARKET_CLOB_BASE_URL": "https://clob.polymarket.com",
    }
    defaults.update(overrides)
    mock = MagicMock()
    for k, v in defaults.items():
        setattr(mock, k, v)
    return mock


def _mock_pool():
    """Return a mock asyncpg pool that accepts INSERT calls."""
    pool = AsyncMock()
    pool.execute = AsyncMock(return_value=None)
    return pool


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

MARKET_ID = "0xtest_market_001"


@pytest.fixture
def schemas_dir(tmp_path):
    """Create a temp dir containing one resolution schema."""
    return _write_schema(tmp_path, MARKET_ID)


@pytest.fixture
def engine(schemas_dir):
    """Create an AnomalyEngine with settings mocked for fast test cycles."""
    mock_settings = _default_settings()
    with patch("app.anomaly.engine.settings", mock_settings):
        from app.anomaly.engine import AnomalyEngine
        eng = AnomalyEngine(schemas_dir=schemas_dir)
    return eng, mock_settings


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_detection_written_to_db_after_warmup(engine, schemas_dir):
    """
    After enough ticks to warm up the z-score window, a spike should
    trigger a detection and call pool.execute to INSERT into anomaly_detections.
    """
    eng, mock_settings = engine
    mock_pool = _mock_pool()

    with patch("app.anomaly.engine.settings", mock_settings), \
         patch("app.db.get_pool", AsyncMock(return_value=mock_pool)), \
         patch("app.anomaly.engine.publish_neural_trace_public", new_callable=AsyncMock), \
         patch("app.anomaly.engine.publish_neural_trace_raw", new_callable=AsyncMock):

        # Feed window_size ticks at a stable price to warm up
        stable_price = 0.50
        for _ in range(mock_settings.ANOMALY_Z_WINDOW):
            await eng.on_tick(MARKET_ID, stable_price, best_bid=0.49, best_ask=0.51)

        # Now feed a spike well above the mean
        spike_price = 0.65
        await eng.on_tick(MARKET_ID, spike_price, best_bid=0.64, best_ask=0.66)

    # The spike should have triggered a detection → DB write
    assert mock_pool.execute.call_count >= 1, (
        f"Expected at least 1 DB write, got {mock_pool.execute.call_count}"
    )

    # Verify the INSERT contains 'anomaly_detections'
    call_args = mock_pool.execute.call_args_list[-1]
    sql = call_args[0][0]
    assert "anomaly_detections" in sql, "DB write should target anomaly_detections table"


@pytest.mark.asyncio
async def test_no_detection_during_warmup(engine, schemas_dir):
    """
    During warmup (< window_size ticks), no detections should fire.
    """
    eng, mock_settings = engine
    mock_pool = _mock_pool()

    with patch("app.anomaly.engine.settings", mock_settings), \
         patch("app.db.get_pool", AsyncMock(return_value=mock_pool)):

        # Feed fewer ticks than window_size
        for _ in range(mock_settings.ANOMALY_Z_WINDOW - 1):
            await eng.on_tick(MARKET_ID, 0.50, best_bid=0.49, best_ask=0.51)

    # No writes should have happened
    assert mock_pool.execute.call_count == 0, (
        f"Expected 0 DB writes during warmup, got {mock_pool.execute.call_count}"
    )
    assert eng._diag["drop_warmup"] == mock_settings.ANOMALY_Z_WINDOW - 1


@pytest.mark.asyncio
async def test_depth_not_required_when_flag_false(engine, schemas_dir):
    """
    With ANOMALY_REQUIRE_DEPTH=False, detections should NOT be blocked
    by orderbook_depth == 0.
    """
    eng, mock_settings = engine
    mock_settings.ANOMALY_REQUIRE_DEPTH = False
    mock_pool = _mock_pool()

    with patch("app.anomaly.engine.settings", mock_settings), \
         patch("app.db.get_pool", AsyncMock(return_value=mock_pool)), \
         patch("app.anomaly.engine.publish_neural_trace_public", new_callable=AsyncMock), \
         patch("app.anomaly.engine.publish_neural_trace_raw", new_callable=AsyncMock):

        # Warm up
        for _ in range(mock_settings.ANOMALY_Z_WINDOW):
            await eng.on_tick(MARKET_ID, 0.50, best_bid=0.49, best_ask=0.51)

        # Spike — depth is 0 (never populated by REST), but flag is False
        await eng.on_tick(MARKET_ID, 0.65, best_bid=0.64, best_ask=0.66)

    # Detection should still fire
    assert eng._diag["detections"] >= 1, "Detection should fire despite depth=0 when REQUIRE_DEPTH=False"
    assert eng._diag["drop_depth_missing"] == 0, "No depth drops should occur with REQUIRE_DEPTH=False"


@pytest.mark.asyncio
async def test_depth_required_blocks_when_flag_true(engine, schemas_dir):
    """
    With ANOMALY_REQUIRE_DEPTH=True, detections with depth=0 should set
    would_trade=False and increment drop_depth_missing.
    """
    eng, mock_settings = engine
    mock_settings.ANOMALY_REQUIRE_DEPTH = True
    mock_pool = _mock_pool()

    with patch("app.anomaly.engine.settings", mock_settings), \
         patch("app.db.get_pool", AsyncMock(return_value=mock_pool)), \
         patch("app.anomaly.engine.publish_neural_trace_public", new_callable=AsyncMock), \
         patch("app.anomaly.engine.publish_neural_trace_raw", new_callable=AsyncMock):

        # Warm up
        for _ in range(mock_settings.ANOMALY_Z_WINDOW):
            await eng.on_tick(MARKET_ID, 0.50, best_bid=0.49, best_ask=0.51)

        # Spike — depth is 0 but flag requires it
        await eng.on_tick(MARKET_ID, 0.65, best_bid=0.64, best_ask=0.66)

    assert eng._diag["detections"] >= 1, "A detection should still be counted"
    assert eng._diag["drop_depth_missing"] >= 1, "Depth drop should fire when REQUIRE_DEPTH=True and depth=0"


@pytest.mark.asyncio
async def test_volume_not_required_when_flag_false(engine, schemas_dir):
    """
    With ANOMALY_REQUIRE_VOLUME=False, detections should fire
    even when volume_24h is 0.
    """
    eng, mock_settings = engine
    mock_settings.ANOMALY_REQUIRE_VOLUME = False
    mock_pool = _mock_pool()

    with patch("app.anomaly.engine.settings", mock_settings), \
         patch("app.db.get_pool", AsyncMock(return_value=mock_pool)), \
         patch("app.anomaly.engine.publish_neural_trace_public", new_callable=AsyncMock), \
         patch("app.anomaly.engine.publish_neural_trace_raw", new_callable=AsyncMock):

        for _ in range(mock_settings.ANOMALY_Z_WINDOW):
            await eng.on_tick(MARKET_ID, 0.50, best_bid=0.49, best_ask=0.51)

        await eng.on_tick(MARKET_ID, 0.65, best_bid=0.64, best_ask=0.66)

    assert eng._diag["drop_volume_missing"] == 0, "No volume drops when REQUIRE_VOLUME=False"


@pytest.mark.asyncio
async def test_disabled_engine_drops_all_ticks(engine, schemas_dir):
    """
    When ANOMALY_ENABLED=False, all ticks should be dropped with drop_disabled.
    """
    eng, mock_settings = engine
    mock_settings.ANOMALY_ENABLED = False

    with patch("app.anomaly.engine.settings", mock_settings):
        await eng.on_tick(MARKET_ID, 0.50, best_bid=0.49, best_ask=0.51)

    assert eng._diag["ticks_received"] == 1
    assert eng._diag["drop_disabled"] == 1


@pytest.mark.asyncio
async def test_unknown_market_dropped(engine, schemas_dir):
    """
    Ticks for an unknown market_id should be dropped.
    """
    eng, mock_settings = engine

    with patch("app.anomaly.engine.settings", mock_settings):
        await eng.on_tick("0xunknown_market", 0.50, best_bid=0.49, best_ask=0.51)

    assert eng._diag["drop_unknown_market"] == 1


@pytest.mark.asyncio
async def test_stats_dump_triggers_after_interval(engine, schemas_dir):
    """
    _maybe_dump_stats should emit a log after ANOMALY_STATS_INTERVAL_SECONDS elapses.
    """
    eng, mock_settings = engine
    mock_settings.ANOMALY_STATS_INTERVAL_SECONDS = 0  # Dump on every call

    with patch("app.anomaly.engine.settings", mock_settings):
        # Force the last dump time far in the past
        eng._last_stats_dump = time.monotonic() - 100

        # Feed one tick to trigger _maybe_dump_stats
        await eng.on_tick(MARKET_ID, 0.50, best_bid=0.49, best_ask=0.51)

    # After dump, counters should be reset
    assert eng._diag["ticks_received"] == 0, "Counters should reset after stats dump"


@pytest.mark.asyncio
async def test_missing_bid_ask_sets_would_trade_false(engine, schemas_dir):
    """
    When best_bid/best_ask are never set and a detection fires, would_trade
    should be False.
    """
    eng, mock_settings = engine
    mock_pool = _mock_pool()

    with patch("app.anomaly.engine.settings", mock_settings), \
         patch("app.db.get_pool", AsyncMock(return_value=mock_pool)), \
         patch("app.anomaly.engine.publish_neural_trace_public", new_callable=AsyncMock), \
         patch("app.anomaly.engine.publish_neural_trace_raw", new_callable=AsyncMock):

        # Warm up with bid/ask so z-score fills, but then spike without bid/ask
        for _ in range(mock_settings.ANOMALY_Z_WINDOW):
            await eng.on_tick(MARKET_ID, 0.50, best_bid=0.49, best_ask=0.51)

        # Clear bid/ask to simulate missing data
        state = eng._markets[MARKET_ID]
        state.best_bid = None
        state.best_ask = None

        await eng.on_tick(MARKET_ID, 0.65, best_bid=None, best_ask=None)

    assert eng._diag["drop_missing_bid_ask"] >= 1, "Missing bid/ask should trigger drop"


@pytest.mark.asyncio
async def test_market_count_property(engine, schemas_dir):
    """market_count should reflect the number of tracked markets."""
    eng, _ = engine
    assert eng.market_count == 1


@pytest.mark.asyncio
async def test_detection_side_direction(engine, schemas_dir):
    """
    z > 0 (price above mean) should produce side=NO (mean reversion down).
    z < 0 (price below mean) should produce side=YES (mean reversion up).
    """
    eng, mock_settings = engine
    mock_pool = _mock_pool()

    with patch("app.anomaly.engine.settings", mock_settings), \
         patch("app.db.get_pool", AsyncMock(return_value=mock_pool)), \
         patch("app.anomaly.engine.publish_neural_trace_public", new_callable=AsyncMock), \
         patch("app.anomaly.engine.publish_neural_trace_raw", new_callable=AsyncMock):

        # Warm up
        for _ in range(mock_settings.ANOMALY_Z_WINDOW):
            await eng.on_tick(MARKET_ID, 0.50, best_bid=0.49, best_ask=0.51)

        # Spike UP → z > 0 → side should be NO
        await eng.on_tick(MARKET_ID, 0.65, best_bid=0.64, best_ask=0.66)

    # Check the last DB write: side argument (index 2, 0-indexed after SQL)
    last_call = mock_pool.execute.call_args_list[-1]
    side_arg = last_call[0][3]  # $3 = side
    assert side_arg == "NO", f"Price spike UP should trade NO for mean reversion, got {side_arg}"
