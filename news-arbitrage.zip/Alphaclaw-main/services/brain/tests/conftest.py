"""
conftest.py — pytest configuration for the brain service test suite.

Sets required environment variables before any app module is imported,
preventing pydantic-settings from raising ValidationError during collection
when a real .env file is absent (CI, local dev without secrets, etc.).
"""
import os

# Provide stub values for all required Settings fields so that
# `from app.config import settings` succeeds during test collection.
# Tests that exercise live infrastructure should use their own fixtures
# to supply real values or mock the relevant clients.
os.environ.setdefault("OPENROUTER_API_KEY", "test-openrouter-key")
os.environ.setdefault("PERPLEXITY_API_KEY", "test-perplexity-key")
os.environ.setdefault("SOCIALDATA_API_KEY", "test-socialdata-key")
