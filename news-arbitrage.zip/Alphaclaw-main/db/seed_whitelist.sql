INSERT INTO whitelist_accounts (handle, category_ids, trust_weight, is_active) VALUES
-- us_election
('@AP',             '["us_election", "geopolitical_ceasefire"]',  0.90, TRUE),
('@Reuters',        '["us_election", "geopolitical_ceasefire", "macro_fed"]', 0.90, TRUE),
('@NickTimiraos',   '["us_election", "macro_fed"]',               0.80, TRUE),
('@FiveThirtyEight','["us_election"]',                            0.80, TRUE),
('@DecisionDeskHQ', '["us_election"]',                            0.80, TRUE),

-- crypto_regulatory
('@SECGov',         '["crypto_regulatory"]',                      0.95, TRUE),
('@CFTCgov',        '["crypto_regulatory"]',                      0.95, TRUE),
('@EricBalchunas',  '["crypto_regulatory"]',                      0.80, TRUE),
('@JSeyff',         '["crypto_regulatory"]',                      0.80, TRUE),
('@CoinDesk',       '["crypto_regulatory"]',                      0.80, TRUE),

-- macro_fed
('@federalreserve', '["macro_fed"]',                              0.95, TRUE),
('@WSJ',            '["macro_fed", "tech_ipo"]',                  0.90, TRUE),
('@business',       '["macro_fed"]',                              0.80, TRUE),
('@ReutersBiz',     '["macro_fed"]',                              0.90, TRUE),

-- geopolitical_ceasefire
('@AFP',            '["geopolitical_ceasefire"]',                 0.90, TRUE),
('@BBCBreaking',    '["geopolitical_ceasefire"]',                 0.90, TRUE),
('@AJEnglish',      '["geopolitical_ceasefire"]',                 0.80, TRUE),

-- tech_ipo
('@SECFilings',     '["tech_ipo", "crypto_regulatory"]',          0.95, TRUE),
('@IPOtweet',       '["tech_ipo"]',                               0.80, TRUE),
('@RenaissanceCap', '["tech_ipo"]',                               0.80, TRUE),

-- sports_championship
('@SportsCenter',   '["sports_championship"]',                    0.80, TRUE),
('@espn',           '["sports_championship"]',                    0.80, TRUE),
('@TheAthletic',    '["sports_championship"]',                    0.80, TRUE);
