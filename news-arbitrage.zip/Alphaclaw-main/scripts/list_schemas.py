#!/usr/bin/env python3
"""
list_schemas.py — AlphaClaw Resolution Schema Lister & Validator

Loads all resolution schema JSON files from data/resolution_schemas/,
validates each against the expected structure, and prints a formatted
summary table.

Usage:
    python scripts/list_schemas.py
    python scripts/list_schemas.py --schemas-dir path/to/schemas
    python scripts/list_schemas.py --verbose
"""

import json
import os
import sys
import argparse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Schema validation
# ---------------------------------------------------------------------------

REQUIRED_TOP_LEVEL_FIELDS: list[tuple[str, type]] = [
    ("market_id", str),
    ("condition_id", str),
    ("title", str),
    ("category_id", str),
    ("resolution_source", str),
    ("resolution_criteria", str),
    ("key_entities", list),
    ("threshold_conditions", list),
    ("oracle_contract", str),
    ("expiry_timestamp", int),
    ("created_at", str),
]

REQUIRED_THRESHOLD_FIELDS: list[tuple[str, type]] = [
    ("condition_id", str),
    ("outcome", str),
    ("required_tokens", list),
    ("forbidden_tokens", list),
    ("authoritative_sources", list),
    ("minimum_sources", int),
]

REQUIRED_ENTITY_FIELDS: list[tuple[str, type]] = [
    ("name", str),
    ("aliases", list),
]

VALID_OUTCOMES = {"YES", "NO"}


def _check_hex(value: str, field: str) -> list[str]:
    """Return a list of validation errors for a hex-prefixed string field."""
    errors = []
    if not isinstance(value, str):
        errors.append(f"  {field}: expected str, got {type(value).__name__}")
        return errors
    if not value.startswith("0x"):
        errors.append(f"  {field}: must start with '0x', got '{value[:10]}...'")
    return errors


def validate_schema(data: dict[str, Any], filename: str) -> list[str]:
    """
    Validate a single schema dict.  Returns a (possibly empty) list of
    human-readable error strings.
    """
    errors: list[str] = []

    # ---- top-level required fields ----
    for field, expected_type in REQUIRED_TOP_LEVEL_FIELDS:
        if field not in data:
            errors.append(f"  Missing required field: '{field}'")
        elif not isinstance(data[field], expected_type):
            errors.append(
                f"  Field '{field}': expected {expected_type.__name__}, "
                f"got {type(data[field]).__name__}"
            )

    # ---- hex fields ----
    for hex_field in ("market_id", "condition_id", "oracle_contract"):
        if hex_field in data:
            errors.extend(_check_hex(data[hex_field], hex_field))

    # ---- expiry_timestamp must be a positive integer ----
    if "expiry_timestamp" in data and isinstance(data["expiry_timestamp"], int):
        if data["expiry_timestamp"] <= 0:
            errors.append("  expiry_timestamp must be a positive integer")

    # ---- created_at must be parseable ISO 8601 ----
    if "created_at" in data and isinstance(data["created_at"], str):
        try:
            datetime.fromisoformat(data["created_at"].replace("Z", "+00:00"))
        except ValueError:
            errors.append(
                f"  created_at: '{data['created_at']}' is not valid ISO 8601"
            )

    # ---- key_entities ----
    if "key_entities" in data and isinstance(data["key_entities"], list):
        if len(data["key_entities"]) == 0:
            errors.append("  key_entities must contain at least one entry")
        for idx, entity in enumerate(data["key_entities"]):
            if not isinstance(entity, dict):
                errors.append(f"  key_entities[{idx}]: expected dict")
                continue
            for ef, et in REQUIRED_ENTITY_FIELDS:
                if ef not in entity:
                    errors.append(f"  key_entities[{idx}]: missing '{ef}'")
                elif not isinstance(entity[ef], et):
                    errors.append(
                        f"  key_entities[{idx}].{ef}: expected "
                        f"{et.__name__}, got {type(entity[ef]).__name__}"
                    )

    # ---- threshold_conditions ----
    if "threshold_conditions" in data and isinstance(
        data["threshold_conditions"], list
    ):
        if len(data["threshold_conditions"]) < 2:
            errors.append(
                "  threshold_conditions must contain at least YES and NO entries"
            )
        outcomes_seen: set[str] = set()
        for idx, tc in enumerate(data["threshold_conditions"]):
            if not isinstance(tc, dict):
                errors.append(f"  threshold_conditions[{idx}]: expected dict")
                continue
            for tf, tt in REQUIRED_THRESHOLD_FIELDS:
                if tf not in tc:
                    errors.append(
                        f"  threshold_conditions[{idx}]: missing '{tf}'"
                    )
                elif not isinstance(tc[tf], tt):
                    errors.append(
                        f"  threshold_conditions[{idx}].{tf}: expected "
                        f"{tt.__name__}, got {type(tc[tf]).__name__}"
                    )
            if "outcome" in tc:
                if tc["outcome"] not in VALID_OUTCOMES:
                    errors.append(
                        f"  threshold_conditions[{idx}].outcome: "
                        f"must be one of {VALID_OUTCOMES}, got '{tc['outcome']}'"
                    )
                outcomes_seen.add(tc["outcome"])
            if "minimum_sources" in tc and isinstance(tc["minimum_sources"], int):
                if tc["minimum_sources"] < 1:
                    errors.append(
                        f"  threshold_conditions[{idx}].minimum_sources: "
                        "must be >= 1"
                    )
        for required_outcome in VALID_OUTCOMES:
            if required_outcome not in outcomes_seen:
                errors.append(
                    f"  threshold_conditions: missing required outcome '{required_outcome}'"
                )

    return errors


# ---------------------------------------------------------------------------
# Table rendering
# ---------------------------------------------------------------------------

def _format_ts(ts: Any) -> str:
    """Convert a Unix timestamp to a human-readable date string."""
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime(
            "%Y-%m-%d"
        )
    except (TypeError, ValueError, OSError):
        return str(ts)


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "…"


def print_table(rows: list[dict[str, Any]]) -> None:
    """Print a formatted summary table of loaded schemas."""
    headers = ["Filename", "Market ID", "Title", "Category", "Expiry Date", "Status"]
    col_widths = [len(h) for h in headers]

    # Pre-format rows and measure column widths
    formatted: list[list[str]] = []
    for row in rows:
        cells = [
            row.get("filename", ""),
            _truncate(row.get("market_id", ""), 20),
            _truncate(row.get("title", ""), 52),
            _truncate(row.get("category_id", ""), 24),
            row.get("expiry_date", ""),
            row.get("status", ""),
        ]
        for i, cell in enumerate(cells):
            col_widths[i] = max(col_widths[i], len(cell))
        formatted.append(cells)

    sep = "+-" + "-+-".join("-" * w for w in col_widths) + "-+"
    header_row = (
        "| "
        + " | ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
        + " |"
    )

    print()
    print(sep)
    print(header_row)
    print(sep)
    for cells in formatted:
        print(
            "| "
            + " | ".join(c.ljust(col_widths[i]) for i, c in enumerate(cells))
            + " |"
        )
    print(sep)
    print()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(
        description="List and validate AlphaClaw resolution schema JSON files."
    )
    parser.add_argument(
        "--schemas-dir",
        default=None,
        help=(
            "Path to the directory containing schema JSON files. "
            "Defaults to data/resolution_schemas/ relative to the script's "
            "parent directory (i.e., the project root)."
        ),
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print detailed validation errors for each file.",
    )
    args = parser.parse_args()

    # Resolve schemas directory
    if args.schemas_dir:
        schemas_dir = Path(args.schemas_dir).resolve()
    else:
        # Default: <project_root>/data/resolution_schemas/
        # __file__ is at <project_root>/scripts/list_schemas.py
        project_root = Path(__file__).resolve().parent.parent
        schemas_dir = project_root / "data" / "resolution_schemas"

    if not schemas_dir.exists():
        print(f"ERROR: schemas directory not found: {schemas_dir}", file=sys.stderr)
        return 1

    json_files = sorted(schemas_dir.glob("*.json"))
    if not json_files:
        print(f"No JSON files found in: {schemas_dir}")
        return 0

    print(f"\nAlphaClaw Resolution Schema Validator")
    print(f"Directory : {schemas_dir}")
    print(f"Files found: {len(json_files)}")

    rows: list[dict[str, Any]] = []
    total_errors = 0

    for json_path in json_files:
        filename = json_path.name
        row: dict[str, Any] = {
            "filename": filename,
            "market_id": "",
            "title": "",
            "category_id": "",
            "expiry_date": "",
            "status": "",
        }

        # ---- load ----
        try:
            with open(json_path, encoding="utf-8") as fh:
                data = json.load(fh)
        except json.JSONDecodeError as exc:
            row["status"] = f"INVALID JSON ({exc})"
            rows.append(row)
            total_errors += 1
            if args.verbose:
                print(f"\n[{filename}] JSON parse error: {exc}")
            continue
        except OSError as exc:
            row["status"] = f"READ ERROR ({exc})"
            rows.append(row)
            total_errors += 1
            continue

        # ---- validate ----
        errors = validate_schema(data, filename)

        # Populate display fields from data (even if partially invalid)
        row["market_id"] = data.get("market_id", "")
        row["title"] = data.get("title", "")
        row["category_id"] = data.get("category_id", "")
        row["expiry_date"] = _format_ts(data.get("expiry_timestamp", ""))
        row["status"] = "OK" if not errors else f"{len(errors)} error(s)"

        if errors:
            total_errors += len(errors)
            if args.verbose:
                print(f"\n[{filename}] Validation errors:")
                for err in errors:
                    print(err)

        rows.append(row)

    # ---- table ----
    print_table(rows)

    # ---- summary ----
    valid_count = sum(1 for r in rows if r["status"] == "OK")
    print(
        f"Summary: {valid_count}/{len(rows)} files valid"
        + (f", {total_errors} total error(s)" if total_errors else "")
    )
    print()

    return 0 if total_errors == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
