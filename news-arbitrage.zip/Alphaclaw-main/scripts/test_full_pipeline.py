#!/usr/bin/env python3
"""
Full pipeline integration test: FastMatch -> Opus -> Kelly -> Broker

Run from Brain venv:
  cd /root/alphaclaw/services/brain && source venv/bin/activate
  python3 /root/alphaclaw/scripts/test_full_pipeline.py

Prerequisites:
  - Brain .env loaded (OPENROUTER_API_KEY, DB, Redis)
  - PostgreSQL + Redis running
  - Broker running via pm2 (to pick up the trade signal)
"""

import asyncio
import os
import sys

# Ensure Brain app is importable and .env is found by pydantic-settings
BRAIN_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "services", "brain"))
sys.path.insert(0, BRAIN_DIR)
os.chdir(BRAIN_DIR)  # pydantic-settings looks for .env in cwd

from datetime import datetime, timezone

from app.db import init_db, close_db
from app.redis_client import init_redis, close_redis
from app.fastmatch.engine import FastMatchEngine, InboundSignal
from app.appeals.opus_client import OpusClient
from app.sizing.kelly import calculate_composite_p, calculate_kelly_fraction, calculate_position
from app.shadow.price_tracker import fetch_mid_price
from app.publisher.redis_pub import (
    publish_trade_signal,
    publish_neural_trace_public,
    publish_neural_trace_raw,
)
from app.config import settings

# Paths to data files (relative to project root)
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
NARRATIVE_DICT = os.path.join(PROJECT_ROOT, "data", "narrative_dict.json")
SCHEMAS_DIR = os.path.join(PROJECT_ROOT, "data", "resolution_schemas")

DIVIDER = "=" * 60
WALLET_TOTAL_USDC = 1000.0


def heading(title: str) -> None:
    print(f"\n{DIVIDER}")
    print(f"  {title}")
    print(DIVIDER)


async def main():
    heading("FULL PIPELINE TEST — CPI Feb 2026")
    print(f"Timestamp : {datetime.now(timezone.utc).isoformat()}")
    print(f"Wallet    : ${WALLET_TOTAL_USDC:.2f} (shadow)")

    # ------------------------------------------------------------------
    # 1. Initialize infrastructure
    # ------------------------------------------------------------------
    heading("STAGE 1: Initialize DB + Redis")
    await init_db()
    print("  DB pool ......... OK")
    await init_redis()
    print("  Redis client .... OK")

    # ------------------------------------------------------------------
    # 2. Initialize engines
    # ------------------------------------------------------------------
    heading("STAGE 2: Initialize FastMatch + Opus")
    engine = FastMatchEngine(NARRATIVE_DICT, SCHEMAS_DIR)
    print(f"  Categories ...... {len(engine._narrative_dict.get('categories', {}))}")
    print(f"  Schemas ......... {len(engine._resolution_schemas)}")

    opus = OpusClient(perplexity_client=None)
    print("  Opus client ..... OK (via OpenRouter)")

    # ------------------------------------------------------------------
    # 3. Create test signal
    # ------------------------------------------------------------------
    heading("STAGE 3: Create Test Signal")

    signal = InboundSignal(
        source_tier=2,
        source_handle="@bls_gov",
        source_domain="bls.gov",
        raw_text=(
            "BLS reports Consumer Price Index rose 0.3 percent in February 2026. "
            "Bureau of Labor Statistics official CPI data confirms monthly increase."
        ),
        zscore=4.0,
        timestamp=datetime.now(timezone.utc),
        trust_weight=0.9,
    )

    print(f"  Tier ............ {signal.source_tier}")
    print(f"  Handle .......... {signal.source_handle}")
    print(f"  Z-score ......... {signal.zscore}")
    print(f"  Raw text ........ {signal.raw_text[:80]}...")

    # ------------------------------------------------------------------
    # 4. FastMatch
    # ------------------------------------------------------------------
    heading("STAGE 4: FastMatch")
    result = await engine.process(signal)

    print(f"  Tokens .......... {result.canonical_tokens}")
    print(f"  Category ........ {result.matched_category_id}")
    print(f"  Market .......... {result.matched_market_id}")
    print(f"  Score ........... {result.fast_match_score}")
    print(f"  Hit ............. {result.fast_match_hit}")
    print(f"  Escalate ........ {result.escalate_to_opus}")
    print(f"  Matched signals . {result.matched_resolution_signals}")
    print(f"  Drop reason ..... {result.drop_reason}")

    if not result.escalate_to_opus:
        print(f"\n  STOPPED: FastMatch did not escalate (reason: {result.drop_reason})")
        await close_redis()
        await close_db()
        return

    # ------------------------------------------------------------------
    # 5. Write signal to DB
    # ------------------------------------------------------------------
    heading("STAGE 5: Write Signal to DB")
    signal_db_id = await engine.write_signal_to_db(result)
    print(f"  Signal ID ....... {signal_db_id}")

    if not signal_db_id:
        print("  WARNING: Failed to write signal to DB — continuing anyway")

    # ------------------------------------------------------------------
    # 6. Opus verdict
    # ------------------------------------------------------------------
    heading("STAGE 6: Opus Verdict (calling OpenRouter...)")
    market_id = result.matched_market_id
    schema = engine.get_resolution_schema(market_id)

    if not schema:
        print(f"  STOPPED: No resolution schema for market {market_id}")
        await close_redis()
        await close_db()
        return

    print(f"  Market title .... {schema.get('title', 'N/A')}")
    print(f"  Calling Opus .... ", end="", flush=True)

    verdict = await opus.invoke(
        signal_raw_text=signal.raw_text,
        signal_source_handle=signal.source_handle,
        signal_source_domain=signal.source_domain,
        signal_id=signal_db_id,
        resolution_schema=schema,
    )

    print(f"done ({verdict.latency_ms}ms)")
    print(f"  Outcome ......... {verdict.outcome}")
    print(f"  Confidence ...... {verdict.confidence}")
    print(f"  Res. match ...... {verdict.resolution_match}")
    print(f"  Reasoning ....... {verdict.reasoning[:200]}...")
    print(f"  Disqualifiers ... {verdict.disqualifying_factors}")
    print(f"  Perp. followup .. {verdict.requires_perplexity_followup}")
    print(f"  Verdict ID ...... {verdict.verdict_id}")
    print(f"  Tokens used ..... {verdict.prompt_tokens} in / {verdict.completion_tokens} out")

    # Gate: AMBIGUOUS or no resolution match
    if verdict.outcome == "AMBIGUOUS" or not verdict.resolution_match:
        reason = "ambiguous_verdict" if verdict.outcome == "AMBIGUOUS" else "no_resolution_match"
        print(f"\n  STOPPED: Opus dropped signal ({reason})")
        await close_redis()
        await close_db()
        return

    # ------------------------------------------------------------------
    # 7. Kelly sizing
    # ------------------------------------------------------------------
    heading("STAGE 7: Kelly Sizing")

    zscore = signal.zscore if signal.zscore is not None else 0.0
    composite_p = calculate_composite_p(verdict.confidence, zscore)
    print(f"  Opus confidence . {verdict.confidence}")
    print(f"  Z-score ......... {zscore}")
    print(f"  Composite P ..... {composite_p:.4f}")
    print(f"  MIN_COMPOSITE_P . {settings.MIN_COMPOSITE_P}")

    if composite_p < settings.MIN_COMPOSITE_P:
        print(f"\n  STOPPED: composite_p {composite_p:.4f} < {settings.MIN_COMPOSITE_P}")
        await close_redis()
        await close_db()
        return

    print(f"  Gate ............ PASSED")

    # ------------------------------------------------------------------
    # 8. Fetch market price
    # ------------------------------------------------------------------
    heading("STAGE 8: CLOB Market Price")

    # Resolve CLOB token_id (decimal) from FastMatch result
    clob_token = (result.matched_clob_token_yes if verdict.outcome == "YES"
                  else result.matched_clob_token_no)
    print(f"  Market ID ....... {market_id[:20]}...")
    print(f"  CLOB token_id ... {(clob_token or 'NONE')[:40]}...")

    if not clob_token:
        print("  STOPPED: No CLOB token_id in resolution schema for this side")
        await close_redis()
        await close_db()
        return

    market_price = await fetch_mid_price(clob_token)
    print(f"  Mid-price ....... {market_price}")

    if market_price is None:
        print("  STOPPED: Could not fetch market price from CLOB API")
        await close_redis()
        await close_db()
        return

    # ------------------------------------------------------------------
    # 9. Position sizing
    # ------------------------------------------------------------------
    heading("STAGE 9: Position Sizing")

    kelly_fraction = calculate_kelly_fraction(composite_p, market_price)
    position_usdc = calculate_position(composite_p, market_price, WALLET_TOTAL_USDC)
    wallet_exposure = position_usdc / WALLET_TOTAL_USDC if WALLET_TOTAL_USDC > 0 else 0
    side = verdict.outcome  # "YES" or "NO"

    print(f"  Side ............ {side}")
    print(f"  Kelly fraction .. {kelly_fraction:.4f}")
    print(f"  Quarter-Kelly ... {kelly_fraction * settings.KELLY_FRACTION:.4f}")
    print(f"  Position ........ ${position_usdc:.2f}")
    print(f"  Wallet exposure . {wallet_exposure:.2%}")
    print(f"  Max exposure .... {settings.MAX_WALLET_EXPOSURE:.0%}")
    print(f"  Min position .... ${settings.MIN_POSITION_USDC:.2f}")

    if position_usdc <= 0:
        print(f"\n  STOPPED: Position size is $0 (Kelly unprofitable at price={market_price:.4f})")
        await close_redis()
        await close_db()
        return

    # ------------------------------------------------------------------
    # 10. Publish trade signal
    # ------------------------------------------------------------------
    heading("STAGE 10: Publish Trade Signal -> Redis -> Broker")

    market_title = schema.get("title", schema.get("question", market_id))

    # Neural trace events (like main.py _escalate_signal)
    await publish_neural_trace_public("HUNT", {
        "market_title": market_title,
        "source_handle": signal.source_handle,
        "source_tier": signal.source_tier,
        "fast_match_score": result.fast_match_score,
        "action": "Evaluating signal...",
        "reasoning_summary": f"Test signal escalated (score={result.fast_match_score:.2f})",
    })

    trade_signal_id = await publish_trade_signal(
        signal_id=signal_db_id or "",
        verdict_id=verdict.verdict_id or "",
        market_id=market_id,
        side=side,
        composite_p=composite_p,
        kelly_fraction=kelly_fraction,
        position_usdc=position_usdc,
        wallet_exposure=wallet_exposure,
        market_price=market_price,
        reasoning_summary=verdict.reasoning[:500],
        source_url="",
        clob_token_id=clob_token,
    )

    print(f"  Trade signal ID . {trade_signal_id}")

    if trade_signal_id:
        await publish_neural_trace_public("STRIKE", {
            "market_title": market_title,
            "side": side,
            "position_usdc": position_usdc,
            "composite_p": composite_p,
            "market_price": market_price,
            "action": f"TRADE: {side} ${position_usdc:.2f}",
            "reasoning_summary": verdict.reasoning[:200],
            "confidence_label": f"{composite_p:.0%}",
        })
        await publish_neural_trace_raw("TRADE_SIGNAL_PUBLISHED", {
            "trade_signal_id": trade_signal_id,
            "signal_id": signal_db_id,
            "verdict_id": verdict.verdict_id,
            "market_id": market_id,
            "market_title": market_title,
            "side": side,
            "composite_p": composite_p,
            "kelly_fraction": kelly_fraction,
            "position_usdc": position_usdc,
            "wallet_exposure": wallet_exposure,
            "market_price": market_price,
            "reasoning": verdict.reasoning,
        })
        print("  Redis publish ... OK (Broker should pick this up)")
    else:
        print("  WARNING: Trade signal DB write failed")

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    heading("PIPELINE COMPLETE")
    print(f"  Market .......... {market_title}")
    print(f"  Side ............ {side}")
    print(f"  Position ........ ${position_usdc:.2f}")
    print(f"  Composite P ..... {composite_p:.4f}")
    print(f"  Market price .... {market_price:.4f}")
    print(f"  Kelly ........... {kelly_fraction:.4f}")
    print()
    print("  Next: Check Broker picked up the signal:")
    print("    pm2 logs Broker --lines 20")
    print()
    print("  Verify DB records:")
    print("    SELECT * FROM shadow_trades ORDER BY created_at DESC LIMIT 1;")
    print()

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------
    await close_redis()
    await close_db()


if __name__ == "__main__":
    asyncio.run(main())
