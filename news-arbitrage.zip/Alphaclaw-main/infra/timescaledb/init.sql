-- Enable TimescaleDB
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- 1. signals table
CREATE TABLE signals (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source_tier     SMALLINT NOT NULL,         -- 1=polymarket, 2=social, 3=hn, 4=perplexity
    source_handle   TEXT,                      -- e.g. twitter handle or HN item id
    raw_text        TEXT NOT NULL,
    canonical_tokens JSONB,                    -- output of normalizer.py
    market_id       TEXT,                      -- polymarket condition_id if matched
    zscore          DOUBLE PRECISION,
    fast_match_hit  BOOLEAN DEFAULT FALSE,
    fast_match_score DOUBLE PRECISION,
    escalated_to_opus BOOLEAN DEFAULT FALSE,
    drop_reason     TEXT                       -- reason signal was dropped (null if not dropped)
);
SELECT create_hypertable('signals', 'created_at');
CREATE INDEX ON signals (market_id, created_at DESC);
CREATE INDEX ON signals (source_tier, created_at DESC);

-- 2. opus_verdicts table
CREATE TABLE opus_verdicts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signal_id       UUID REFERENCES signals(id),
    market_id       TEXT NOT NULL,
    prompt_tokens   INT,
    completion_tokens INT,
    raw_response    TEXT,
    resolution_match BOOLEAN,
    opus_confidence DOUBLE PRECISION,
    reasoning_summary TEXT,
    latency_ms      INT
);
SELECT create_hypertable('opus_verdicts', 'created_at');
CREATE INDEX ON opus_verdicts (market_id, created_at DESC);

-- 3. trade_signals table
CREATE TABLE trade_signals (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signal_id       UUID REFERENCES signals(id),
    verdict_id      UUID REFERENCES opus_verdicts(id),
    market_id       TEXT NOT NULL,
    side            TEXT NOT NULL CHECK (side IN ('YES', 'NO')),
    composite_p     DOUBLE PRECISION NOT NULL,
    kelly_fraction  DOUBLE PRECISION NOT NULL,
    position_usdc   DOUBLE PRECISION NOT NULL,
    wallet_exposure DOUBLE PRECISION NOT NULL,
    status          TEXT NOT NULL DEFAULT 'PENDING'
                    CHECK (status IN ('PENDING','EXECUTED','REJECTED','EXPIRED'))
);
SELECT create_hypertable('trade_signals', 'created_at');

-- 4. trades table
CREATE TABLE trades (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    trade_signal_id UUID REFERENCES trade_signals(id),
    market_id       TEXT NOT NULL,
    order_id        TEXT NOT NULL,
    side            TEXT NOT NULL,
    size_usdc       DOUBLE PRECISION NOT NULL,
    avg_fill_price  DOUBLE PRECISION,
    slippage_bps    INT,
    fee_usdc        DOUBLE PRECISION,
    status          TEXT NOT NULL
                    CHECK (status IN ('FILLED','PARTIAL','FAILED','CANCELLED')),
    raw_clob_response JSONB
);
SELECT create_hypertable('trades', 'created_at');
CREATE INDEX ON trades (market_id, created_at DESC);

-- 5. pnl_snapshots table
CREATE TABLE pnl_snapshots (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    wallet_address  TEXT NOT NULL,
    total_usdc      DOUBLE PRECISION NOT NULL,
    unrealized_pnl  DOUBLE PRECISION,
    realized_pnl_today DOUBLE PRECISION,
    open_positions  JSONB,
    snapshot_source TEXT               -- 'scheduled' | 'post_trade'
);
SELECT create_hypertable('pnl_snapshots', 'created_at', chunk_time_interval => INTERVAL '1 day');

-- 6. oracle_disputes table
CREATE TABLE oracle_disputes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    market_id       TEXT NOT NULL,
    dispute_tx      TEXT,
    dispute_status  TEXT NOT NULL CHECK (dispute_status IN ('ACTIVE','RESOLVED','INVALID')),
    resolved_at     TIMESTAMPTZ,
    notes           TEXT
);
CREATE UNIQUE INDEX ON oracle_disputes (market_id) WHERE dispute_status = 'ACTIVE';

-- 7. circuit_breaker_events table
CREATE TABLE circuit_breaker_events (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    from_state      TEXT NOT NULL,
    to_state        TEXT NOT NULL,
    trigger_reason  TEXT NOT NULL,
    daily_pnl_pct   DOUBLE PRECISION,
    initiated_by    TEXT               -- 'system' | 'manual'
);

-- 8. whitelist_accounts table
CREATE TABLE whitelist_accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    handle          TEXT NOT NULL UNIQUE,
    category_ids    JSONB NOT NULL,      -- array of category_id strings
    trust_weight    DOUBLE PRECISION NOT NULL DEFAULT 0.5,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    notes           TEXT
);

-- Auto-update updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_whitelist_accounts_updated_at
    BEFORE UPDATE ON whitelist_accounts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE INDEX ON whitelist_accounts (handle) WHERE is_active = TRUE;

-- 9. shadow_trades table (Phase 2)
CREATE TABLE shadow_trades (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signal_id       UUID REFERENCES signals(id),
    verdict_id      UUID REFERENCES opus_verdicts(id),
    market_id       TEXT NOT NULL,
    clob_token_id   TEXT,               -- decimal CLOB token_id for price lookups
    side            TEXT NOT NULL CHECK (side IN ('YES', 'NO')),
    entry_price     DOUBLE PRECISION NOT NULL,
    composite_p     DOUBLE PRECISION NOT NULL,
    kelly_fraction  DOUBLE PRECISION NOT NULL,
    position_usdc   DOUBLE PRECISION NOT NULL,
    price_15m       DOUBLE PRECISION,
    price_1h        DOUBLE PRECISION,
    price_24h       DOUBLE PRECISION,
    price_24h_basis TEXT,            -- 'settlement' | 'midprice'
    max_favorable   DOUBLE PRECISION,
    max_adverse     DOUBLE PRECISION,
    resolved_at     TIMESTAMPTZ,
    resolved_price  DOUBLE PRECISION,
    resolved_before_24h BOOLEAN,
    tracking_status TEXT NOT NULL DEFAULT 'PENDING'
                    CHECK (tracking_status IN ('PENDING','TRACKING','COMPLETE'))
);
SELECT create_hypertable('shadow_trades', 'created_at');
CREATE INDEX ON shadow_trades (market_id, created_at DESC);
CREATE INDEX ON shadow_trades (tracking_status) WHERE tracking_status != 'COMPLETE';

-- 10. admin_alerts table
CREATE TABLE admin_alerts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    severity        TEXT NOT NULL CHECK (severity IN ('INFO','WARNING','CRITICAL')),
    message         TEXT NOT NULL
);
