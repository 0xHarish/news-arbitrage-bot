-- Live trades table (Phase 3)
-- Stores real orders placed on Polymarket CLOB when DRY_RUN=false.

CREATE TABLE live_trades (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    signal_id       UUID REFERENCES signals(id),
    verdict_id      UUID REFERENCES opus_verdicts(id),
    market_id       TEXT NOT NULL,
    clob_token_id   TEXT,
    side            TEXT NOT NULL CHECK (side IN ('YES', 'NO')),
    limit_price     DOUBLE PRECISION NOT NULL,
    composite_p     DOUBLE PRECISION NOT NULL,
    kelly_fraction  DOUBLE PRECISION NOT NULL,
    position_usdc   DOUBLE PRECISION NOT NULL,
    order_ids       TEXT[],
    fill_price      DOUBLE PRECISION,
    filled_amount   DOUBLE PRECISION,
    status          TEXT NOT NULL DEFAULT 'PENDING'
                    CHECK (status IN ('PENDING','FILLED','PARTIAL','FAILED','CANCELLED')),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

SELECT create_hypertable('live_trades', 'created_at');

CREATE INDEX ON live_trades (market_id, created_at DESC);
CREATE INDEX ON live_trades (status) WHERE status NOT IN ('FILLED', 'CANCELLED');

CREATE TRIGGER update_live_trades_updated_at
    BEFORE UPDATE ON live_trades
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
