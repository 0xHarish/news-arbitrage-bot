-- 001_anomaly_engine.sql
-- Phase A: anomaly detection log table + Phase B prep columns

-- Anomaly detections table (Phase A: log only)
CREATE TABLE IF NOT EXISTS anomaly_detections (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    market_id       TEXT NOT NULL,
    clob_token_id   TEXT,
    side            TEXT NOT NULL CHECK (side IN ('YES', 'NO')),
    zscore          DOUBLE PRECISION NOT NULL,
    price           DOUBLE PRECISION NOT NULL,
    price_delta     DOUBLE PRECISION NOT NULL,
    mean            DOUBLE PRECISION NOT NULL,
    std             DOUBLE PRECISION NOT NULL,
    limit_price     DOUBLE PRECISION,
    position_usdc   DOUBLE PRECISION,
    best_bid        DOUBLE PRECISION,
    best_ask        DOUBLE PRECISION,
    spread_pct      DOUBLE PRECISION,
    cooldown_active BOOLEAN DEFAULT FALSE,
    would_trade     BOOLEAN DEFAULT FALSE,
    phase           TEXT NOT NULL DEFAULT 'A'
);
SELECT create_hypertable('anomaly_detections', 'created_at', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_anomaly_market ON anomaly_detections (market_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_anomaly_trade ON anomaly_detections (would_trade, created_at DESC);

-- Phase B prep: add signal_type to existing tables
ALTER TABLE trade_signals ADD COLUMN IF NOT EXISTS signal_type TEXT NOT NULL DEFAULT 'NARRATIVE'
    CHECK (signal_type IN ('NARRATIVE', 'ANOMALY'));
ALTER TABLE shadow_trades ADD COLUMN IF NOT EXISTS signal_type TEXT NOT NULL DEFAULT 'NARRATIVE'
    CHECK (signal_type IN ('NARRATIVE', 'ANOMALY'));
